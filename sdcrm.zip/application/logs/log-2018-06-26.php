<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-26 09:42:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-26 10:25:13 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 60
ERROR - 2018-06-26 10:26:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 60
ERROR - 2018-06-26 10:27:19 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 160
ERROR - 2018-06-26 15:57:39 --> Severity: Notice --> Undefined index: phonenumber /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 52
ERROR - 2018-06-26 15:57:46 --> Severity: Notice --> Undefined index: phonenumber /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 52
ERROR - 2018-06-26 15:58:23 --> Severity: Notice --> Undefined index: phonenumber /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 52
ERROR - 2018-06-26 15:58:38 --> Severity: Notice --> Undefined index: phonenumber /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 52
ERROR - 2018-06-26 16:09:30 --> Severity: Error --> Call to undefined function bcrypt() /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 59
ERROR - 2018-06-26 16:09:46 --> Severity: Error --> Call to undefined function BCRYPT() /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 59
ERROR - 2018-06-26 16:11:17 --> Severity: Notice --> crypt(): No salt parameter was specified. You must use a randomly generated salt and a strong hash function to produce a secure hash. /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 59
ERROR - 2018-06-26 16:12:59 --> Severity: Error --> Call to undefined function checkpassword() /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 59
ERROR - 2018-06-26 10:49:05 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 58
ERROR - 2018-06-26 16:20:00 --> Severity: Notice --> Undefined variable: inserId /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 136
ERROR - 2018-06-26 16:20:00 --> Query error: Column 'relid' cannot be null - Invalid query: INSERT INTO `tblcustomfieldsvalues` (`relid`, `fieldid`, `fieldto`, `value`) VALUES (NULL, '1', 'proposal', 'pro6757656654655')
ERROR - 2018-06-26 16:39:12 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:40:38 --> Severity: Error --> Call to undefined function rpitn_r() /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 60
ERROR - 2018-06-26 16:42:33 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:42:33 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:43:28 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:43:46 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:43:47 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:46:05 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:49:15 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:49:29 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:49:43 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 16:50:06 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 17:13:03 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 17:13:03 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 19:00:10 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 19:00:10 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-26 19:05:13 --> Severity: Error --> Class 'PasswordHash' not found /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 49
ERROR - 2018-06-26 19:26:02 --> Severity: Notice --> Undefined variable: email /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 49
ERROR - 2018-06-26 19:26:02 --> Severity: Notice --> Undefined variable: table /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 50
ERROR - 2018-06-26 19:26:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `email` IS NULL' at line 2 - Invalid query: SELECT *
WHERE `email` IS NULL
ERROR - 2018-06-26 19:26:21 --> Severity: Notice --> Undefined variable: table /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 50
ERROR - 2018-06-26 19:26:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `email` = 'admin@test.com'' at line 2 - Invalid query: SELECT *
WHERE `email` = 'admin@test.com'
ERROR - 2018-06-26 19:26:46 --> Severity: Notice --> Undefined variable: password /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 54
ERROR - 2018-06-26 19:26:46 --> Severity: Notice --> Undefined variable: authData /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 62
ERROR - 2018-06-26 19:28:29 --> Severity: Notice --> Undefined variable: authData /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 60
ERROR - 2018-06-26 19:28:37 --> Severity: Notice --> Undefined variable: authData /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 60
ERROR - 2018-06-26 14:01:57 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 56
ERROR - 2018-06-26 14:04:29 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 58
ERROR - 2018-06-26 14:04:51 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 58
ERROR - 2018-06-26 14:05:11 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 58
ERROR - 2018-06-26 19:35:50 --> Severity: Notice --> Undefined variable: response /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 58
ERROR - 2018-06-26 19:36:15 --> Severity: Notice --> Undefined variable: response /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 58
ERROR - 2018-06-26 19:38:14 --> Severity: Notice --> Undefined variable: response /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 58
ERROR - 2018-06-26 19:39:03 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 166
ERROR - 2018-06-26 19:39:03 --> Severity: Notice --> Undefined variable: response /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 58
ERROR - 2018-06-26 19:40:06 --> Severity: Notice --> Undefined variable: response /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 58
ERROR - 2018-06-26 14:11:09 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 56
ERROR - 2018-06-26 14:11:26 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 56
ERROR - 2018-06-26 14:11:38 --> Severity: Parsing Error --> syntax error, unexpected ',' /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 56
ERROR - 2018-06-26 20:07:24 --> Severity: Notice --> Undefined variable: checkinLeads /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 164
ERROR - 2018-06-26 20:07:24 --> Severity: Notice --> Undefined index: rel_type /var/www/html/sdcrm/application/models/Proposals_model.php 199
ERROR - 2018-06-26 20:08:20 --> Severity: Warning --> Missing argument 4 for Enquiry_api::createNewEnquirywithExistingLead(), called in /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php on line 97 and defined /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 159
