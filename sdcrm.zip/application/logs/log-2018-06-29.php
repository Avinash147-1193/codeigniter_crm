<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-29 11:39:05 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-29 06:10:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 06:10:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 06:11:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 06:12:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 06:13:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 06:18:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 06:26:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:57:06 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-29 11:57:06 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-29 06:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 06:53:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 12:27:33 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 777
ERROR - 2018-06-29 12:27:35 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 777
ERROR - 2018-06-29 12:27:36 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 777
ERROR - 2018-06-29 07:01:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 07:02:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 07:03:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 12:33:13 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-29 12:33:14 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-29 12:33:19 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-29 12:33:22 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-29 07:06:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 07:08:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 07:14:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 07:15:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 07:16:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 12:46:13 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-29 12:46:14 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-29 07:17:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 12:47:33 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 779
ERROR - 2018-06-29 12:47:33 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 779
ERROR - 2018-06-29 07:18:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 07:18:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 12:49:01 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 779
ERROR - 2018-06-29 12:49:01 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 779
ERROR - 2018-06-29 07:20:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 07:22:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 12:52:59 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-29 12:52:59 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-29 07:23:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 07:25:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 09:12:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 09:27:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 09:30:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 09:31:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 09:31:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 09:36:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 09:40:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 09:41:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 15:13:18 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 780
ERROR - 2018-06-29 09:49:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 09:50:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:16 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:16 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:16 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:16 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:17 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:17 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:17 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:17 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:22:18 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:18 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:18 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:18 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:18 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:18 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:19 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:19 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:22:19 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-29 15:22:20 --> Severity: Notice --> Undefined index: tax /var/www/html/sdcrm/application/controllers/admin/Proposals.php 830
ERROR - 2018-06-29 15:22:20 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 800
ERROR - 2018-06-29 15:22:20 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 801
ERROR - 2018-06-29 15:22:20 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 802
ERROR - 2018-06-29 15:22:20 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 09:52:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 15:25:01 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:25:01 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:25:02 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:25:02 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:25:02 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:25:03 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:25:03 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:25:03 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:25:04 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 15:25:04 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 809
ERROR - 2018-06-29 09:57:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 15:27:51 --> Severity: Notice --> Undefined variable: response /var/www/html/sdcrm/application/controllers/admin/Proposals.php 786
ERROR - 2018-06-29 09:58:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:06:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 15:36:11 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 15:36:11 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 15:36:11 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 15:36:12 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 15:36:12 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 15:36:12 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 15:36:13 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 15:36:13 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 15:36:14 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 15:36:14 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 784
ERROR - 2018-06-29 10:07:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:12:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 15:43:25 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-29 10:28:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:29:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:29:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:39:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 16:09:58 --> Severity: Notice --> Undefined index: term /var/www/html/sdcrm/application/controllers/admin/Proposals.php 764
ERROR - 2018-06-29 16:10:06 --> Severity: Notice --> Undefined index: term /var/www/html/sdcrm/application/controllers/admin/Proposals.php 764
ERROR - 2018-06-29 10:41:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:44:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:44:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:45:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:52:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:56:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 10:58:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:08:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:10:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:11:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:12:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:13:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:13:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:16:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:17:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:17:42 --> 404 Page Not Found: admin/Proposals/undefined
ERROR - 2018-06-29 11:19:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:21:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-29 11:22:08 --> 404 Page Not Found: Assets/plugins
