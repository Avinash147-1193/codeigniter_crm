<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:10:12 --> Severity: 4096 --> Object of class stdClass could not be converted to string /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 33
ERROR - 2018-06-07 15:36:15 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/sdcrm/application/views/admin/utilities/main_menu.php 35
ERROR - 2018-06-07 10:28:15 --> 404 Page Not Found: admin/Wwwshakedealcom/index
ERROR - 2018-06-07 10:28:15 --> 404 Page Not Found: admin/Wwwshakedealcom/index
ERROR - 2018-06-07 10:38:42 --> 404 Page Not Found: admin/Admin/estimates
ERROR - 2018-06-07 10:38:42 --> 404 Page Not Found: admin/Admin/estimates
ERROR - 2018-06-07 10:40:59 --> 404 Page Not Found: admin/Estimates/estimates
ERROR - 2018-06-07 10:41:16 --> 404 Page Not Found: admin/Estimates/estimates
ERROR - 2018-06-07 10:41:40 --> 404 Page Not Found: admin/Estimates/estimates
ERROR - 2018-06-07 10:42:33 --> 404 Page Not Found: admin/Proposals/estimates
ERROR - 2018-06-07 11:04:45 --> 404 Page Not Found: admin/Estimates/estimates
ERROR - 2018-06-07 11:04:55 --> 404 Page Not Found: AdmiN/estimates
ERROR - 2018-06-07 11:05:20 --> 404 Page Not Found: AdmiN/estimates
ERROR - 2018-06-07 11:07:30 --> 404 Page Not Found: admin/Proposals/estimates
ERROR - 2018-06-07 11:16:24 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) /var/www/html/sdcrm/application/config/routes.php 88
ERROR - 2018-06-07 11:16:38 --> 404 Page Not Found: admin/Enquiry/index
ERROR - 2018-06-07 11:16:48 --> 404 Page Not Found: Proposals/proposal
ERROR - 2018-06-07 11:16:52 --> 404 Page Not Found: Proposals/proposal
ERROR - 2018-06-07 11:17:50 --> 404 Page Not Found: Proposals/proposal
ERROR - 2018-06-07 12:13:12 --> 404 Page Not Found: admin/Proposals/proposals
ERROR - 2018-06-07 12:13:22 --> 404 Page Not Found: Proposals/proposal
ERROR - 2018-06-07 12:13:22 --> 404 Page Not Found: Proposals/proposal
ERROR - 2018-06-07 12:48:51 --> 404 Page Not Found: admin/Enquiry/index
ERROR - 2018-06-07 12:49:20 --> 404 Page Not Found: Proposal/enquiry
ERROR - 2018-06-07 12:49:44 --> 404 Page Not Found: Proposals/enquiry
ERROR - 2018-06-07 12:50:34 --> 404 Page Not Found: admin/Enquiry/index
ERROR - 2018-06-07 12:50:41 --> 404 Page Not Found: admin/Enquiryphp/index
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: currencies /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 78
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 78
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: currencies /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 111
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/helpers/fields_helper.php 331
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: statuses /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 154
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 154
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: staff /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 164
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 164
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: staff /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 172
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/helpers/fields_helper.php 331
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: ajaxItems /var/www/html/sdcrm/application/views/admin/estimates/_add_edit_items.php 5
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: items /var/www/html/sdcrm/application/views/admin/estimates/_add_edit_items.php 7
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/views/admin/estimates/_add_edit_items.php 7
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: taxes /var/www/html/sdcrm/application/views/admin/estimates/_add_edit_items.php 89
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/views/admin/estimates/_add_edit_items.php 89
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: base_currency /var/www/html/sdcrm/application/views/admin/invoice_items/item.php 23
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/invoice_items/item.php 23
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: currencies /var/www/html/sdcrm/application/views/admin/invoice_items/item.php 27
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/views/admin/invoice_items/item.php 27
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: taxes /var/www/html/sdcrm/application/views/admin/invoice_items/item.php 43
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/views/admin/invoice_items/item.php 43
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: taxes /var/www/html/sdcrm/application/views/admin/invoice_items/item.php 54
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/views/admin/invoice_items/item.php 54
ERROR - 2018-06-07 18:26:29 --> Severity: Notice --> Undefined variable: items_groups /var/www/html/sdcrm/application/views/admin/invoice_items/item.php 66
ERROR - 2018-06-07 18:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/helpers/fields_helper.php 331
ERROR - 2018-06-07 12:59:35 --> 404 Page Not Found: admin/Proposals/admin
ERROR - 2018-06-07 12:59:54 --> 404 Page Not Found: admin/Admin/enquiry
ERROR - 2018-06-07 13:01:50 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/sdcrm/application/helpers/my_functions_helper.php 17
ERROR - 2018-06-07 13:01:56 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/sdcrm/application/helpers/my_functions_helper.php 17
ERROR - 2018-06-07 13:02:08 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ',' or ';' /var/www/html/sdcrm/application/helpers/my_functions_helper.php 17
ERROR - 2018-06-07 13:02:27 --> Severity: Parsing Error --> syntax error, unexpected 'base_url' (T_STRING), expecting ',' or ';' /var/www/html/sdcrm/application/helpers/my_functions_helper.php 17
ERROR - 2018-06-07 13:05:35 --> Severity: Notice --> Undefined property: CRM_Loader::$load /var/www/html/sdcrm/application/helpers/my_functions_helper.php 3
ERROR - 2018-06-07 13:05:35 --> Severity: Error --> Call to a member function helper() on null /var/www/html/sdcrm/application/helpers/my_functions_helper.php 3
ERROR - 2018-06-07 13:05:39 --> Severity: Notice --> Undefined property: CRM_Loader::$load /var/www/html/sdcrm/application/helpers/my_functions_helper.php 3
ERROR - 2018-06-07 13:05:39 --> Severity: Error --> Call to a member function helper() on null /var/www/html/sdcrm/application/helpers/my_functions_helper.php 3
ERROR - 2018-06-07 13:14:34 --> 404 Page Not Found: admin/Admin/enquiry
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Clients.php 205
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Clients.php 223
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 6
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 10
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 13
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 49
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 56
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 63
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/tabs.php 2
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/tabs.php 28
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 75
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 32
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 58
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 60
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 65
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 69
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 72
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 75
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 105
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 110
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 110
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 139
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 141
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 143
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 145
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 149
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 159
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 159
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 164
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 219
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 221
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 223
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 225
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 227
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 236
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 238
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 240
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 242
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 244
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 248
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 248
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 248
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 280
ERROR - 2018-06-07 18:45:44 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 96
ERROR - 2018-06-07 18:45:45 --> Query error: Unknown column 'undefined' in 'where clause' - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, lastname, email, title, phonenumber, active, last_login ,tblcontacts.id as id,userid,is_primary
    FROM tblcontacts
    
    
    WHERE  userid=undefined
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
ERROR - 2018-06-07 13:28:21 --> 404 Page Not Found: admin/Proposals/proposals
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 16
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 22
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 28
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 31
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 42
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 42
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 51
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 52
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 53
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 54
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 55
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 56
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 57
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 58
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 59
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 60
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 61
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 62
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 63
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 64
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 65
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 69
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 73
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 73
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 75
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 76
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 77
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 78
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 79
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 80
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 81
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 82
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 83
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 84
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 84
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 88
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 88
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 88
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 90
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 93
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 99
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 103
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 106
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 107
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 111
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 111
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 111
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 114
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 115
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 115
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 115
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 119
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 119
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 124
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 124
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 124
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 127
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 128
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 128
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 128
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 131
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 132
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 132
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 132
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 136
ERROR - 2018-06-07 19:33:36 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 137
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 16
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 22
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 28
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 31
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 42
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 42
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 51
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 52
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 53
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 54
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 55
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 56
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 57
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 58
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 59
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 60
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 61
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 62
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 63
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 64
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 65
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 69
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 73
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 73
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 75
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 76
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 77
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 78
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 79
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 80
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 81
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 82
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 83
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 84
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 84
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 88
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 88
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 88
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 90
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 93
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 99
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 103
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 106
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 107
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 111
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 111
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 111
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 114
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 115
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 115
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 115
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 119
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 119
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 124
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 124
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 124
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 127
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 128
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 128
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 128
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 131
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 132
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 132
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 132
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 136
ERROR - 2018-06-07 19:33:56 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/custom_fields/customfield.php 137
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Clients.php 205
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Clients.php 223
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 6
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 10
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 13
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 49
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 56
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 63
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/tabs.php 2
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/tabs.php 28
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 75
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 32
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 58
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 60
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 65
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 69
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 72
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 75
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 105
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 110
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 110
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 126
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 139
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 141
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 143
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 145
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 149
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 159
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 159
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 164
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 219
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 221
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 223
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 225
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 227
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 236
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 238
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 240
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 242
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 244
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 248
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 248
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 248
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/groups/profile.php 280
ERROR - 2018-06-07 19:35:13 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/views/admin/clients/client.php 96
ERROR - 2018-06-07 19:35:15 --> Query error: Unknown column 'undefined' in 'where clause' - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS firstname, lastname, email, title, phonenumber, active, last_login ,tblcontacts.id as id,userid,is_primary
    FROM tblcontacts
    
    
    WHERE  userid=undefined
    
    ORDER BY firstname ASC
    LIMIT 0, 25
    
