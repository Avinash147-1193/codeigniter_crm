<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-08 05:57:29 --> 404 Page Not Found: admin/Estimates/proposals
ERROR - 2018-06-08 11:47:15 --> Severity: Notice --> Undefined property: Proposals::$proposals_modal /var/www/html/sdcrm/application/controllers/admin/Proposals.php 567
ERROR - 2018-06-08 11:47:15 --> Severity: Error --> Call to a member function check_on_leads_and_clients() on null /var/www/html/sdcrm/application/controllers/admin/Proposals.php 567
ERROR - 2018-06-08 11:56:45 --> Severity: Warning --> Missing argument 1 for Proposals::search_enqiry_lead_customer() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 565
ERROR - 2018-06-08 11:56:45 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 567
ERROR - 2018-06-08 11:56:45 --> Severity: Notice --> Undefined variable: result /var/www/html/sdcrm/application/controllers/admin/Proposals.php 568
ERROR - 2018-06-08 11:56:45 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 571
ERROR - 2018-06-08 11:57:03 --> Severity: Notice --> Undefined variable: result /var/www/html/sdcrm/application/controllers/admin/Proposals.php 568
ERROR - 2018-06-08 11:57:06 --> Severity: Notice --> Undefined variable: result /var/www/html/sdcrm/application/controllers/admin/Proposals.php 568
ERROR - 2018-06-08 06:37:55 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/sdcrm/application/controllers/admin/Proposals.php 575
ERROR - 2018-06-08 06:38:29 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 575
ERROR - 2018-06-08 06:39:25 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 575
ERROR - 2018-06-08 06:42:29 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 577
ERROR - 2018-06-08 06:42:40 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 577
ERROR - 2018-06-08 12:17:01 --> Severity: Warning --> Missing argument 1 for Proposals::search_enqiry_lead_customer() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 565
ERROR - 2018-06-08 12:17:01 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 567
ERROR - 2018-06-08 12:17:01 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 575
ERROR - 2018-06-08 12:20:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 931
ERROR - 2018-06-08 12:20:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 936
ERROR - 2018-06-08 12:20:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 942
ERROR - 2018-06-08 12:20:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 943
ERROR - 2018-06-08 12:20:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 944
ERROR - 2018-06-08 12:20:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 945
ERROR - 2018-06-08 12:20:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 946
ERROR - 2018-06-08 12:20:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 947
ERROR - 2018-06-08 12:20:52 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 948
ERROR - 2018-06-08 06:52:25 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 574
ERROR - 2018-06-08 12:22:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 931
ERROR - 2018-06-08 12:22:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 936
ERROR - 2018-06-08 12:22:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 942
ERROR - 2018-06-08 12:22:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 943
ERROR - 2018-06-08 12:22:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 944
ERROR - 2018-06-08 12:22:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 945
ERROR - 2018-06-08 12:22:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 946
ERROR - 2018-06-08 12:22:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 947
ERROR - 2018-06-08 12:22:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 948
ERROR - 2018-06-08 12:32:04 --> Query error: Unknown column 'id' in 'field list' - Invalid query: SELECT `id`, `company`
FROM `tblclients`
WHERE `company` = 'customer'
ERROR - 2018-06-08 13:02:16 --> Could not find the language line "create lead"
ERROR - 2018-06-08 07:46:45 --> 404 Page Not Found: admin/Proposals/proposals
ERROR - 2018-06-08 15:07:39 --> Severity: Warning --> Missing argument 1 for Proposals::search_enqiry_lead_customer() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 566
ERROR - 2018-06-08 15:07:39 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 568
ERROR - 2018-06-08 15:07:39 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 577
ERROR - 2018-06-08 09:47:38 --> 404 Page Not Found: admin/Proposals/leads
ERROR - 2018-06-08 10:10:24 --> 404 Page Not Found: admin/Proposals/leads
ERROR - 2018-06-08 10:10:24 --> 404 Page Not Found: admin/Proposals/leads
ERROR - 2018-06-08 10:12:46 --> 404 Page Not Found: admin/Estimates/proposals
ERROR - 2018-06-08 10:16:49 --> 404 Page Not Found: admin/Estimates/proposals
ERROR - 2018-06-08 10:16:49 --> 404 Page Not Found: admin/Estimates/proposals
ERROR - 2018-06-08 10:24:00 --> 404 Page Not Found: Proposals/proposal
ERROR - 2018-06-08 18:52:41 --> Severity: Warning --> Missing argument 1 for Proposals::search_enqiry_lead_customer() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 566
ERROR - 2018-06-08 18:52:41 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 568
ERROR - 2018-06-08 18:52:41 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 577
ERROR - 2018-06-08 19:31:15 --> Severity: Parsing Error --> syntax error, unexpected '$rel_val' (T_VARIABLE) /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 67
