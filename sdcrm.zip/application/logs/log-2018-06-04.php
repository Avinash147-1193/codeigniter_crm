<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-04 13:58:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 13:58:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'sdcrm'@'localhost' (using password: YES) /var/www/html/sdcrm/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2018-06-04 13:58:00 --> Unable to connect to the database
ERROR - 2018-06-04 13:58:31 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 19:28:31 --> Severity: Error --> Class 'ForceUTF8\Encoding' not found /var/www/html/sdcrm/application/helpers/general_helper.php 467
ERROR - 2018-06-04 13:58:47 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 19:28:47 --> Severity: Error --> Class 'ForceUTF8\Encoding' not found /var/www/html/sdcrm/application/helpers/general_helper.php 467
ERROR - 2018-06-04 14:02:08 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:02:08 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:02:57 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:02:57 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:03:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:03:49 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:04:26 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:04:26 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:06:38 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:06:38 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:06:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:06:59 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:06:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:06:59 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:06:59 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:06:59 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:07:00 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:07:00 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:07:00 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:07:00 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:07:00 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:07:00 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:07:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:07:01 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:07:01 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:07:01 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:07:10 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:07:10 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:08:45 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:08:45 --> 404 Page Not Found: Install/index
ERROR - 2018-06-04 14:10:35 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 19:40:35 --> Severity: Error --> Class 'ForceUTF8\Encoding' not found /var/www/html/sdcrm/application/helpers/general_helper.php 467
ERROR - 2018-06-04 14:14:51 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 19:44:51 --> Severity: Error --> Class 'ForceUTF8\Encoding' not found /var/www/html/sdcrm/application/helpers/general_helper.php 467
ERROR - 2018-06-04 14:15:36 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:15:48 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:16:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:16:14 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:16:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:16:19 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:16:37 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:16:41 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:16:42 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:16:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:16:46 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:17:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:17:05 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:18:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:18:23 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:20:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:20:49 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:20:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:20:52 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:20:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:20:53 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 14:22:03 --> $config['composer_autoload'] is set to TRUE but /var/www/html/sdcrm/application/vendor/autoload.php was not found.
ERROR - 2018-06-04 19:52:03 --> Severity: Error --> Class 'ForceUTF8\Encoding' not found /var/www/html/sdcrm/application/helpers/general_helper.php 467
