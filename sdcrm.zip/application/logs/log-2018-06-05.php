<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-05 17:23:53 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/views/admin/tables/leads.php 7
ERROR - 2018-06-05 17:27:06 --> Severity: Parsing Error --> syntax error, unexpected ''lastcontact'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /var/www/html/sdcrm/application/views/admin/tables/leads.php 19
ERROR - 2018-06-05 17:27:23 --> Query error: Unknown column 'dummy' in 'field list' - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS 1, tblleads.id as id, tblleads.name as name, company, tblleads.email as email, tblleads.phonenumber as phonenumber, (SELECT GROUP_CONCAT(name SEPARATOR ",") FROM tbltags_in JOIN tbltags ON tbltags_in.tag_id = tbltags.id WHERE rel_id = tblleads.id and rel_type="lead" ORDER by tag_order ASC) as tags, CONCAT(firstname, ' ', lastname) as assigned_name, tblleadsstatus.name as status_name, tblleadssources.name as source_name, dummy cloumn, lastcontact, dateadded ,junk,lost,color,assigned,tblleads.addedfrom as addedfrom,zip
    FROM tblleads
    LEFT JOIN tblstaff ON tblstaff.staffid = tblleads.assigned LEFT JOIN tblleadsstatus ON tblleadsstatus.id = tblleads.status LEFT JOIN tblleadssources ON tblleadssources.id = tblleads.source
    
    WHERE  lost = 0 AND junk = 0
    
    ORDER BY lastcontact DESC
    LIMIT 0, 25
    
ERROR - 2018-06-05 17:27:42 --> Query error: Unknown column 'dummy_cloumn' in 'field list' - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS 1, tblleads.id as id, tblleads.name as name, company, tblleads.email as email, tblleads.phonenumber as phonenumber, (SELECT GROUP_CONCAT(name SEPARATOR ",") FROM tbltags_in JOIN tbltags ON tbltags_in.tag_id = tbltags.id WHERE rel_id = tblleads.id and rel_type="lead" ORDER by tag_order ASC) as tags, CONCAT(firstname, ' ', lastname) as assigned_name, tblleadsstatus.name as status_name, tblleadssources.name as source_name, dummy_cloumn, lastcontact, dateadded ,junk,lost,color,assigned,tblleads.addedfrom as addedfrom,zip
    FROM tblleads
    LEFT JOIN tblstaff ON tblstaff.staffid = tblleads.assigned LEFT JOIN tblleadsstatus ON tblleadsstatus.id = tblleads.status LEFT JOIN tblleadssources ON tblleadssources.id = tblleads.source
    
    WHERE  lost = 0 AND junk = 0
    
    ORDER BY lastcontact DESC
    LIMIT 0, 25
    
ERROR - 2018-06-05 17:28:06 --> Query error: Unknown column 'dummycloumn' in 'field list' - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS 1, tblleads.id as id, tblleads.name as name, company, tblleads.email as email, tblleads.phonenumber as phonenumber, (SELECT GROUP_CONCAT(name SEPARATOR ",") FROM tbltags_in JOIN tbltags ON tbltags_in.tag_id = tbltags.id WHERE rel_id = tblleads.id and rel_type="lead" ORDER by tag_order ASC) as tags, CONCAT(firstname, ' ', lastname) as assigned_name, tblleadsstatus.name as status_name, tblleadssources.name as source_name, dummycloumn, lastcontact, dateadded ,junk,lost,color,assigned,tblleads.addedfrom as addedfrom,zip
    FROM tblleads
    LEFT JOIN tblstaff ON tblstaff.staffid = tblleads.assigned LEFT JOIN tblleadsstatus ON tblleadsstatus.id = tblleads.status LEFT JOIN tblleadssources ON tblleadssources.id = tblleads.source
    
    WHERE  lost = 0 AND junk = 0
    
    ORDER BY lastcontact DESC
    LIMIT 0, 25
    
ERROR - 2018-06-05 17:29:17 --> Query error: Unknown column 'links' in 'field list' - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS 1, tblleads.id as id, tblleads.name as name, company, tblleads.email as email, tblleads.phonenumber as phonenumber, (SELECT GROUP_CONCAT(name SEPARATOR ",") FROM tbltags_in JOIN tbltags ON tbltags_in.tag_id = tbltags.id WHERE rel_id = tblleads.id and rel_type="lead" ORDER by tag_order ASC) as tags, CONCAT(firstname, ' ', lastname) as assigned_name, tblleadsstatus.name as status_name, tblleadssources.name as source_name, links, lastcontact, dateadded ,junk,lost,color,assigned,tblleads.addedfrom as addedfrom,zip
    FROM tblleads
    LEFT JOIN tblstaff ON tblstaff.staffid = tblleads.assigned LEFT JOIN tblleadsstatus ON tblleadsstatus.id = tblleads.status LEFT JOIN tblleadssources ON tblleadssources.id = tblleads.source
    
    WHERE  lost = 0 AND junk = 0
    
    ORDER BY lastcontact DESC
    LIMIT 0, 25
    
ERROR - 2018-06-05 17:32:48 --> Severity: Parsing Error --> syntax error, unexpected ''tblleads.phonenumber as phone' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /var/www/html/sdcrm/application/views/admin/tables/leads.php 14
ERROR - 2018-06-05 17:35:12 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:35:12 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:35:12 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:35:44 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:35:44 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:35:44 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:35:53 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:35:53 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:35:53 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:36:00 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:36:00 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:36:00 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:36:07 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:36:07 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:36:07 --> Severity: Notice --> Undefined index: tags /var/www/html/sdcrm/application/views/admin/tables/leads.php 115
ERROR - 2018-06-05 17:46:47 --> Severity: Parsing Error --> syntax error, unexpected ''CONCAT(firstname, \' \', last' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /var/www/html/sdcrm/application/views/admin/tables/leads.php 16
ERROR - 2018-06-05 17:47:28 --> Query error: Unknown column 'action' in 'field list' - Invalid query: 
    SELECT SQL_CALC_FOUND_ROWS 1, tblleads.id as id, tblleads.name as name, company, tblleads.email as email, (SELECT GROUP_CONCAT(name SEPARATOR ",") FROM tbltags_in JOIN tbltags ON tbltags_in.tag_id = tbltags.id WHERE rel_id = tblleads.id and rel_type="lead" ORDER by tag_order ASC) as Links, tblleads.phonenumber as phonenumber, action, CONCAT(firstname, ' ', lastname) as assigned_name, tblleadsstatus.name as status_name, tblleadssources.name as source_name, lastcontact, dateadded ,junk,lost,color,assigned,tblleads.addedfrom as addedfrom,zip
    FROM tblleads
    LEFT JOIN tblstaff ON tblstaff.staffid = tblleads.assigned LEFT JOIN tblleadsstatus ON tblleadsstatus.id = tblleads.status LEFT JOIN tblleadssources ON tblleadssources.id = tblleads.source
    
    WHERE  lost = 0 AND junk = 0
    
    ORDER BY lastcontact DESC
    LIMIT 0, 25
    
