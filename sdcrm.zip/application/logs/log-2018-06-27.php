<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-27 12:44:03 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-27 07:20:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 07:22:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 07:22:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 07:25:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 07:40:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 07:41:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:14:07 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-27 08:19:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 08:52:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:27:47 --> Severity: Notice --> Undefined variable: items /var/www/html/sdcrm/application/controllers/admin/Proposals.php 186
ERROR - 2018-06-27 09:01:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:35:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 140
ERROR - 2018-06-27 14:35:31 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 140
ERROR - 2018-06-27 14:35:31 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 141
ERROR - 2018-06-27 14:35:31 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 142
ERROR - 2018-06-27 09:05:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:35:48 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 140
ERROR - 2018-06-27 14:35:48 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 140
ERROR - 2018-06-27 14:35:48 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 141
ERROR - 2018-06-27 14:35:48 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 142
ERROR - 2018-06-27 09:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:40:28 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 140
ERROR - 2018-06-27 14:40:28 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 140
ERROR - 2018-06-27 14:40:28 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 141
ERROR - 2018-06-27 14:40:28 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 142
ERROR - 2018-06-27 09:10:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 09:13:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 09:16:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 09:23:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 09:24:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:54:43 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 140
ERROR - 2018-06-27 14:54:43 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 140
ERROR - 2018-06-27 14:54:43 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 141
ERROR - 2018-06-27 14:54:43 --> Severity: Warning --> Attempt to assign property of non-object /var/www/html/sdcrm/application/controllers/admin/Invoice_items.php 142
ERROR - 2018-06-27 09:26:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 09:27:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 09:30:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 09:31:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 09:31:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 09:34:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 15:14:34 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-27 15:14:34 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-27 16:01:59 --> Severity: Notice --> Undefined index: product /var/www/html/sdcrm/application/controllers/admin/Proposals.php 204
ERROR - 2018-06-27 11:28:46 --> 404 Page Not Found: api/Simtech/1
ERROR - 2018-06-27 11:29:00 --> 404 Page Not Found: api/Simtech/1
ERROR - 2018-06-27 11:29:12 --> 404 Page Not Found: api/Simtech/1
ERROR - 2018-06-27 11:29:21 --> 404 Page Not Found: api/Simtech/1
ERROR - 2018-06-27 12:06:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:06:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 17:37:12 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-27 12:07:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:07:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:08:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:09:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:10:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:12:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:12:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:18:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:27:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:30:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:33:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:36:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:38:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:38:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:39:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:40:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 18:15:23 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/sdcrm/application/views/admin/estimates/_add_edit_items.php 13
ERROR - 2018-06-27 12:45:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:46:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:47:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:47:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:49:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 12:51:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:21:46 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-27 13:22:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:22:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:33:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:36:59 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/sdcrm/application/controllers/admin/Proposals.php 783
ERROR - 2018-06-27 13:37:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:42:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:43:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:50:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:51:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:52:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:53:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 13:54:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:05:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:05:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:06:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:07:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 14:37:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 15:10:39 --> Severity: Parsing Error --> syntax error, unexpected ';' /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-27 15:11:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 15:13:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 15:18:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-27 15:20:51 --> 404 Page Not Found: Assets/plugins
