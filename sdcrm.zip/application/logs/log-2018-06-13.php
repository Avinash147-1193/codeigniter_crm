<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-13 05:51:08 --> 404 Page Not Found: admin/Proposals/suggest_name.php
ERROR - 2018-06-13 11:24:13 --> Severity: Parsing Error --> syntax error, unexpected '$rel_val' (T_VARIABLE) /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 59
ERROR - 2018-06-13 11:24:40 --> Severity: Parsing Error --> syntax error, unexpected '$rel_val' (T_VARIABLE) /var/www/html/sdcrm/application/views/admin/proposals/proposal.php 59
ERROR - 2018-06-13 11:34:32 --> Severity: Warning --> Missing argument 1 for Proposals::search_enqiry_lead_customer() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 566
ERROR - 2018-06-13 11:34:32 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 568
ERROR - 2018-06-13 11:34:32 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 577
ERROR - 2018-06-13 12:00:50 --> Severity: Notice --> Undefined index: name /var/www/html/sdcrm/application/controllers/admin/Proposals.php 597
ERROR - 2018-06-13 12:00:50 --> Severity: Notice --> Undefined index: name /var/www/html/sdcrm/application/controllers/admin/Proposals.php 597
ERROR - 2018-06-13 12:02:33 --> Severity: Warning --> Missing argument 1 for Proposals::search_enqiry_lead_customer() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 566
ERROR - 2018-06-13 12:02:33 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 568
ERROR - 2018-06-13 12:02:33 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 577
ERROR - 2018-06-13 12:07:40 --> Severity: Warning --> Missing argument 1 for Proposals::search_enqiry_lead_customer() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 566
ERROR - 2018-06-13 12:07:40 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 568
ERROR - 2018-06-13 12:07:40 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 577
ERROR - 2018-06-13 12:14:40 --> Severity: Notice --> Undefined index: name /var/www/html/sdcrm/application/controllers/admin/Proposals.php 598
ERROR - 2018-06-13 12:50:41 --> Severity: Warning --> Missing argument 1 for Proposals::search_enqiry_lead_customer() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 566
ERROR - 2018-06-13 12:50:41 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 568
ERROR - 2018-06-13 12:50:41 --> Severity: Notice --> Undefined variable: value /var/www/html/sdcrm/application/controllers/admin/Proposals.php 577
ERROR - 2018-06-13 07:35:25 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 614
ERROR - 2018-06-13 07:39:50 --> Severity: Parsing Error --> syntax error, unexpected 'array_push' (T_STRING) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 615
ERROR - 2018-06-13 14:22:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 932
ERROR - 2018-06-13 14:22:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 937
ERROR - 2018-06-13 14:22:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 943
ERROR - 2018-06-13 14:22:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 944
ERROR - 2018-06-13 14:22:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 945
ERROR - 2018-06-13 14:22:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 946
ERROR - 2018-06-13 14:22:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 947
ERROR - 2018-06-13 14:22:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 948
ERROR - 2018-06-13 14:22:16 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 949
ERROR - 2018-06-13 14:22:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 932
ERROR - 2018-06-13 14:22:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 937
ERROR - 2018-06-13 14:22:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 943
ERROR - 2018-06-13 14:22:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 944
ERROR - 2018-06-13 14:22:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 945
ERROR - 2018-06-13 14:22:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 946
ERROR - 2018-06-13 14:22:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 947
ERROR - 2018-06-13 14:22:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 948
ERROR - 2018-06-13 14:22:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/models/Proposals_model.php 949
ERROR - 2018-06-13 14:42:38 --> Query error: Unknown column 'enquiry' in 'field list' - Invalid query: INSERT INTO `tblproposals` (`enquiry`, `date`, `open_till`, `currency`, `discount_type`, `status`, `assigned`, `proposal_to`, `address`, `city`, `state`, `country`, `zip`, `email`, `phone`, `show_quantity_as`, `subtotal`, `discount_percent`, `discount_total`, `adjustment`, `total`, `allow_comments`, `datecreated`, `addedfrom`, `hash`, `content`) VALUES ('test -- Found in Leads', '2018-06-13', '2018-06-20', '1', '', '6', '1', 'test', 'test', 'test', 'test', '102', '560001', 'admin@email.com', '7894561230', '1', '25.00', '0', '0.00', '0.00', '25.00', 0, '2018-06-13 14:42:38', '1', '204719a99951c02d34a2e2a4c917493e', '{proposal_items}')
ERROR - 2018-06-13 14:48:17 --> Severity: Notice --> Undefined index: rel_type /var/www/html/sdcrm/application/models/Proposals_model.php 198
ERROR - 2018-06-13 14:48:18 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:48:48 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:48:55 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:49:14 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:49:25 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:49:40 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:49:52 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:50:24 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:50:31 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:50:39 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:51:01 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:52:23 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:52:54 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:55:18 --> Severity: Notice --> Undefined index: rel_type /var/www/html/sdcrm/application/models/Proposals_model.php 198
ERROR - 2018-06-13 14:55:19 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:55:19 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:55:36 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:55:36 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:56:16 --> Severity: Notice --> Undefined index: rel_type /var/www/html/sdcrm/application/models/Proposals_model.php 198
ERROR - 2018-06-13 14:56:17 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:56:17 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 14:56:17 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 15:00:35 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 15:00:35 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 15:00:35 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 15:20:29 --> Severity: Notice --> Undefined variable: toOutput /var/www/html/sdcrm/application/views/admin/tables/proposals.php 128
ERROR - 2018-06-13 17:08:09 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:09:17 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:09:35 --> Could not find the language line "IndiaMart"
ERROR - 2018-06-13 17:09:42 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:10:41 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:12:21 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:12:51 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:13:18 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:13:49 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:14:46 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:15:23 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:15:29 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:15:36 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:15:42 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:15:48 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:17:04 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:23:52 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:25:23 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:25:24 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:25:24 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:25:24 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:25:24 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:25:24 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:30:02 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:34:08 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:46:24 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:47:45 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:52:00 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:52:01 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:55:56 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:57:05 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 17:57:56 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:01:02 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:01:02 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:01:18 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:01:19 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:01:42 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:02:19 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:03:12 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:04:38 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:06:21 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:11:41 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:11:42 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:18:40 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:18:40 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:19:47 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:19:47 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:20:34 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:22:53 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:23:07 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:24:01 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:24:23 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:24:50 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 12:55:04 --> Severity: Error --> Cannot redeclare array_flatten() (previously declared in /var/www/html/sdcrm/application/vendor/illuminate/support/helpers.php:125) /var/www/html/sdcrm/application/helpers/func_helper.php 297
ERROR - 2018-06-13 12:55:36 --> Severity: Error --> Cannot redeclare array_flatten() (previously declared in /var/www/html/sdcrm/application/vendor/illuminate/support/helpers.php:125) /var/www/html/sdcrm/application/helpers/func_helper.php 297
ERROR - 2018-06-13 12:55:42 --> Severity: Error --> Cannot redeclare array_flatten() (previously declared in /var/www/html/sdcrm/application/vendor/illuminate/support/helpers.php:125) /var/www/html/sdcrm/application/helpers/func_helper.php 297
ERROR - 2018-06-13 12:57:52 --> Severity: Error --> Cannot redeclare array_flatten() (previously declared in /var/www/html/sdcrm/application/vendor/illuminate/support/helpers.php:125) /var/www/html/sdcrm/application/helpers/func_helper.php 297
ERROR - 2018-06-13 12:58:25 --> Severity: Error --> Cannot redeclare array_flatten() (previously declared in /var/www/html/sdcrm/application/vendor/illuminate/support/helpers.php:125) /var/www/html/sdcrm/application/helpers/func_helper.php 297
ERROR - 2018-06-13 18:29:17 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:29:46 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:30:19 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:31:33 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:34:10 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:34:10 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:36:40 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:37:39 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-13 18:37:39 --> Could not find the language line "Pull Leads from IndiaMart"
