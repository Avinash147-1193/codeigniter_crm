<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-28 11:38:18 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-28 06:17:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:18:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:18:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:19:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:20:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:20:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:21:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:23:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:25:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:48:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 12:20:01 --> Could not find the language line "Search Product SDSTORE"
ERROR - 2018-06-28 12:20:59 --> Could not find the language line "Search Product SDSTORE"
ERROR - 2018-06-28 12:21:14 --> Could not find the language line "Search Product SDSTORE"
ERROR - 2018-06-28 12:21:30 --> Could not find the language line "Search Product SDSTORE"
ERROR - 2018-06-28 12:21:40 --> Could not find the language line "Search Product SDSTORE"
ERROR - 2018-06-28 12:22:25 --> Could not find the language line "Search Product SDSTORE"
ERROR - 2018-06-28 06:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 12:22:51 --> Could not find the language line "Search Product SDSTORE"
ERROR - 2018-06-28 06:52:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 12:23:12 --> Could not find the language line "Search Product SDSTORE"
ERROR - 2018-06-28 06:54:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:56:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:58:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 06:58:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 12:35:35 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-28 12:35:35 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-28 07:05:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 12:35:56 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 781
ERROR - 2018-06-28 12:35:58 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 781
ERROR - 2018-06-28 12:36:00 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 781
ERROR - 2018-06-28 12:36:03 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 781
ERROR - 2018-06-28 12:36:04 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 781
ERROR - 2018-06-28 12:36:07 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given /var/www/html/sdcrm/application/controllers/admin/Proposals.php 781
ERROR - 2018-06-28 07:10:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:11:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:15:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:16:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:20:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 12:53:43 --> Could not find the language line "Pull Enquiry from IndiaMart"
ERROR - 2018-06-28 07:24:50 --> Severity: Parsing Error --> syntax error, unexpected 'exit' (T_EXIT), expecting ',' or ';' /var/www/html/sdcrm/application/controllers/api/Enquiry_api.php 187
ERROR - 2018-06-28 07:34:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:34:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:37:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:44:53 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 790
ERROR - 2018-06-28 07:45:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:45:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:15:58 --> Severity: Error --> Call to undefined function CURLOPT_HTTPHEADER() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 790
ERROR - 2018-06-28 07:47:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:17:13 --> Severity: Error --> Call to undefined function CURLOPT_HTTPHEADER() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 790
ERROR - 2018-06-28 07:47:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:18:04 --> Severity: Warning --> curl_setopt(): You must pass either an object or an array with the CURLOPT_HTTPHEADER argument /var/www/html/sdcrm/application/controllers/admin/Proposals.php 790
ERROR - 2018-06-28 07:48:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:51:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 07:57:06 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/sdcrm/application/controllers/admin/Proposals.php 787
ERROR - 2018-06-28 07:57:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 08:00:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 08:01:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 08:03:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 08:39:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 08:43:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 08:46:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 08:48:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:23:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:34:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:34:18 --> 404 Page Not Found: admin/Proposal/getProductStore
ERROR - 2018-06-28 09:34:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:37:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:38:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:38:46 --> 404 Page Not Found: admin/Proposals/undefined
ERROR - 2018-06-28 09:39:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:39:31 --> 404 Page Not Found: admin/Proposals/undefined
ERROR - 2018-06-28 09:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:41:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:49:09 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 792
ERROR - 2018-06-28 09:49:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:50:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:50:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:51:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:53:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:55:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:56:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 09:58:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:06:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 15:38:12 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:12 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:12 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:13 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:13 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:13 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:13 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:14 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:14 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:14 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:15 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:15 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:15 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:16 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:16 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:16 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:16 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:16 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:17 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:17 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:17 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:18 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:18 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:18 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:18 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:19 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:19 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:19 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:19 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:38:20 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 10:09:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 15:39:10 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:39:10 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:39:10 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:39:11 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:39:11 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:39:11 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:39:11 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:39:12 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:39:12 --> Severity: Notice --> Undefined index: company /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 10:09:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 15:39:44 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 10:10:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:11:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:12:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 15:43:09 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:43:09 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 10:13:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 15:43:27 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 10:13:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:14:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 15:44:34 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 15:44:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 10:15:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 15:45:35 --> Severity: Warning --> Illegal string offset 'users' /var/www/html/sdcrm/application/controllers/admin/Proposals.php 819
ERROR - 2018-06-28 10:16:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:17:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:17:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:18:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:18:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:20:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:25:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:28:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:29:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 16:00:14 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 10:30:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:30:52 --> Severity: Parsing Error --> syntax error, unexpected '$storeProducts' (T_VARIABLE) /var/www/html/sdcrm/application/controllers/admin/Proposals.php 792
ERROR - 2018-06-28 10:31:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:31:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:34:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:38:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:52:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:53:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:53:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:53:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:54:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:55:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:55:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:56:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:58:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 10:59:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:00:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:04:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:10:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:10:59 --> 404 Page Not Found: admin/Proposals/undefined
ERROR - 2018-06-28 11:12:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 16:43:06 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 795
ERROR - 2018-06-28 16:43:07 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 795
ERROR - 2018-06-28 11:15:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:17:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 16:47:08 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 16:47:20 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 11:17:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 16:47:49 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 16:47:50 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 11:19:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 16:50:04 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-28 16:50:05 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 789
ERROR - 2018-06-28 11:20:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 16:50:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 11:21:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:21:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:22:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:22:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 16:52:28 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 11:22:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:28:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 16:58:19 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 11:30:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:30:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 17:00:51 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 11:31:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:32:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:32:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 17:02:41 --> Severity: Notice --> Undefined offset: 0 /var/www/html/sdcrm/application/controllers/admin/Proposals.php 788
ERROR - 2018-06-28 11:32:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:33:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 17:03:48 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-28 17:03:48 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 796
ERROR - 2018-06-28 11:37:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:37:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:38:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:38:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:40:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:41:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 17:11:32 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 797
ERROR - 2018-06-28 17:11:33 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 797
ERROR - 2018-06-28 11:42:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:42:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 11:43:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 12:03:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 12:04:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 17:37:56 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 798
ERROR - 2018-06-28 17:37:57 --> Severity: Notice --> Undefined index: main_pair /var/www/html/sdcrm/application/controllers/admin/Proposals.php 798
ERROR - 2018-06-28 12:09:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:11:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:12:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:14:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:31:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:35:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:36:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:37:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-06-28 13:54:11 --> 404 Page Not Found: Assets/plugins
