<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-14 11:28:28 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 11:29:44 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 11:31:38 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 11:36:15 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 11:36:42 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 11:36:43 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 11:45:11 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 11:56:42 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:09:39 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:09:40 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:13:19 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:17:38 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:23:56 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:24:25 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:34:22 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:34:22 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:34:22 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:34:30 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:34:30 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:59:54 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 12:59:54 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:00:16 --> Severity: Notice --> Use of undefined constant length - assumed 'length' /var/www/html/sdcrm/application/controllers/admin/Leads.php 1346
ERROR - 2018-06-14 13:00:46 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:02:38 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:02:48 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/controllers/admin/Leads.php 1346
ERROR - 2018-06-14 13:03:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/controllers/admin/Leads.php 1346
ERROR - 2018-06-14 13:03:33 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:03:33 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:03:38 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/controllers/admin/Leads.php 1346
ERROR - 2018-06-14 13:08:53 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:11:06 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:21:47 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:21:47 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:34:39 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 13:34:39 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 15:47:44 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 15:53:17 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 15:53:17 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 15:53:19 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (tblsessions) Unknown 0
ERROR - 2018-06-14 15:53:23 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (tblsessions) Unknown 0
ERROR - 2018-06-14 15:53:37 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (tblsessions) Unknown 0
ERROR - 2018-06-14 15:53:41 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (tblsessions) Unknown 0
ERROR - 2018-06-14 15:54:38 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (tblsessions) Unknown 0
ERROR - 2018-06-14 15:56:05 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (tblsessions) Unknown 0
ERROR - 2018-06-14 15:56:14 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 15:56:35 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (tblsessions) Unknown 0
ERROR - 2018-06-14 15:57:50 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 15:58:02 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/admin/Leads.php 1347
ERROR - 2018-06-14 15:58:02 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 15:58:18 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/admin/Leads.php 1347
ERROR - 2018-06-14 15:58:39 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 15:58:55 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/admin/Leads.php 1347
ERROR - 2018-06-14 15:59:09 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 15:59:19 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/admin/Leads.php 1347
ERROR - 2018-06-14 16:01:54 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (tblsessions) Unknown 0
ERROR - 2018-06-14 16:01:58 --> Severity: Warning --> Unknown: Failed to write session data (user). Please verify that the current setting of session.save_path is correct (tblsessions) Unknown 0
ERROR - 2018-06-14 16:04:25 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:06:46 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:08:00 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:08:09 --> Severity: Notice --> Trying to get property of non-object /var/www/html/sdcrm/application/controllers/admin/Leads.php 1345
ERROR - 2018-06-14 16:12:04 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:12:11 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/admin/Leads.php 1347
ERROR - 2018-06-14 16:12:35 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:13:46 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:13:59 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/sdcrm/application/controllers/admin/Leads.php 1348
ERROR - 2018-06-14 16:14:24 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:14:25 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:15:45 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:15:48 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:15:56 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/sdcrm/application/controllers/admin/Leads.php 1348
ERROR - 2018-06-14 16:16:03 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/sdcrm/application/controllers/admin/Leads.php 1348
ERROR - 2018-06-14 16:16:26 --> Severity: Error --> Cannot use object of type stdClass as array /var/www/html/sdcrm/application/controllers/admin/Leads.php 1348
ERROR - 2018-06-14 16:17:43 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:19:23 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:19:55 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:19:58 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:19:58 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:20:08 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/admin/Leads.php 1350
ERROR - 2018-06-14 16:21:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/sdcrm/application/controllers/admin/Leads.php 1346
ERROR - 2018-06-14 16:21:31 --> Severity: Notice --> Undefined variable: data /var/www/html/sdcrm/application/controllers/admin/Leads.php 1350
ERROR - 2018-06-14 16:21:48 --> Severity: Notice --> Array to string conversion /var/www/html/sdcrm/application/controllers/admin/Leads.php 1350
ERROR - 2018-06-14 16:32:26 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 16:58:45 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: vlaue /var/www/html/sdcrm/application/controllers/admin/Leads.php 1360
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:00:32 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:04 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1167
ERROR - 2018-06-14 17:02:20 --> Severity: Notice --> Undefined variable: term /var/www/html/sdcrm/application/models/Leads_model.php 1168
ERROR - 2018-06-14 17:02:52 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:14:30 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:15:20 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:18:02 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:18:56 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:19:53 --> Severity: Notice --> Undefined index: title /var/www/html/sdcrm/application/models/Leads_model.php 1176
ERROR - 2018-06-14 17:19:53 --> Severity: Notice --> Undefined index: country /var/www/html/sdcrm/application/models/Leads_model.php 1183
ERROR - 2018-06-14 17:19:53 --> Query error: Column 'country' cannot be null - Invalid query: INSERT INTO `tblleads` (`name`, `email`, `description`, `title`, `status`, `source`, `phonenumber`, `address`, `city`, `state`, `country`) VALUES ('Praveen Kumar', 'info@shreyasentp.com', NULL, NULL, 2, 2, '+919986275091', NULL, NULL, NULL, NULL)
ERROR - 2018-06-14 17:21:28 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:21:28 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:22:14 --> Severity: Notice --> Undefined index: title /var/www/html/sdcrm/application/models/Leads_model.php 1176
ERROR - 2018-06-14 17:22:14 --> Severity: Notice --> Undefined index: country /var/www/html/sdcrm/application/models/Leads_model.php 1183
ERROR - 2018-06-14 17:22:14 --> Query error: Column 'country' cannot be null - Invalid query: INSERT INTO `tblleads` (`name`, `email`, `description`, `title`, `status`, `source`, `phonenumber`, `address`, `city`, `state`, `country`) VALUES ('Praveen Kumar', 'info@shreyasentp.com', NULL, NULL, 2, 2, '+919986275091', NULL, NULL, NULL, NULL)
ERROR - 2018-06-14 17:23:31 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:23:31 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:27:08 --> Severity: Notice --> Undefined index: title /var/www/html/sdcrm/application/models/Leads_model.php 1182
ERROR - 2018-06-14 17:27:08 --> Severity: Notice --> Undefined index: country /var/www/html/sdcrm/application/models/Leads_model.php 1183
ERROR - 2018-06-14 17:27:08 --> Query error: Column 'country' cannot be null - Invalid query: INSERT INTO `tblleads` (`name`, `email`, `description`, `status`, `source`, `phonenumber`, `address`, `city`, `state`, `title`, `country`) VALUES ('Praveen Kumar', 'info@shreyasentp.com', NULL, 2, 2, '+919986275091', NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-06-14 17:28:54 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:28:54 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:29:05 --> Severity: Notice --> Undefined index: country /var/www/html/sdcrm/application/models/Leads_model.php 1182
ERROR - 2018-06-14 17:29:05 --> Query error: Column 'country' cannot be null - Invalid query: INSERT INTO `tblleads` (`name`, `email`, `description`, `status`, `source`, `phonenumber`, `address`, `city`, `state`, `country`) VALUES ('Praveen Kumar', 'info@shreyasentp.com', NULL, 2, 2, '+919986275091', NULL, NULL, NULL, NULL)
ERROR - 2018-06-14 17:29:29 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:35:40 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:36:39 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:36:40 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:38:33 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:38:34 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:39:20 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:39:55 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:39:56 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:41:34 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:43:35 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:43:36 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:49:59 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:59:16 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 17:59:16 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 18:00:32 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 18:01:47 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 18:01:58 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 18:02:18 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 18:04:23 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 18:04:23 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 18:05:22 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 18:05:22 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 18:05:22 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 14:01:39 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/html/sdcrm/application/controllers/admin/Leads.php 1375
ERROR - 2018-06-14 14:02:08 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/sdcrm/application/controllers/admin/Leads.php 1416
ERROR - 2018-06-14 19:32:38 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) /var/www/html/sdcrm/application/models/Leads_model.php 1176
ERROR - 2018-06-14 19:32:56 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:34:17 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:34:31 --> Severity: Notice --> Undefined index: SUBJECT /var/www/html/sdcrm/application/controllers/admin/Leads.php 1372
ERROR - 2018-06-14 19:34:31 --> Query error: Unknown column 'description' in 'field list' - Invalid query: INSERT INTO `tblproposals` (`subject`, `rel_id`, `rel_type`, `date`, `currency`, `status`, `proposal_to`, `address`, `city`, `state`, `email`, `phone`, `description`, `allow_comments`, `datecreated`, `addedfrom`, `hash`, `content`, `adjustment`) VALUES (NULL, 611, 'lead', '2018-06-14', 1, 1, 'Narayanachari', '', NULL, NULL, 'kesarihan@gmail.com', '+919606597631', NULL, 0, '2018-06-14 19:34:31', '1', '38c9881f109e9ddee18098014ff3f0a8', '{proposal_items}', 0)
ERROR - 2018-06-14 19:35:09 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:35:09 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:35:25 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:35:38 --> Query error: Unknown column 'description' in 'field list' - Invalid query: INSERT INTO `tblproposals` (`subject`, `rel_id`, `rel_type`, `date`, `currency`, `status`, `proposal_to`, `address`, `city`, `state`, `email`, `phone`, `description`, `allow_comments`, `datecreated`, `addedfrom`, `hash`, `content`, `adjustment`) VALUES ('Buyer Call', 612, 'lead', '2018-06-14', 1, 1, 'Narayanachari', '', NULL, NULL, 'kesarihan@gmail.com', '+919606597631', NULL, 0, '2018-06-14 19:35:38', '1', '9edc263bc40c5e0f6e117a467a794963', '{proposal_items}', 0)
ERROR - 2018-06-14 19:38:11 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:38:11 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:38:20 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:38:48 --> Severity: Notice --> Undefined index: SUBJECT /var/www/html/sdcrm/application/controllers/admin/Leads.php 1422
ERROR - 2018-06-14 19:38:48 --> Severity: Notice --> Undefined variable: checkinCustomers /var/www/html/sdcrm/application/controllers/admin/Leads.php 1423
ERROR - 2018-06-14 19:38:48 --> Severity: Notice --> Undefined variable: customerEnquiry /var/www/html/sdcrm/application/controllers/admin/Leads.php 1436
ERROR - 2018-06-14 19:38:48 --> Severity: Notice --> Undefined index: address /var/www/html/sdcrm/application/models/Proposals_model.php 129
ERROR - 2018-06-14 19:38:48 --> Severity: Notice --> Undefined index: rel_type /var/www/html/sdcrm/application/models/Proposals_model.php 198
ERROR - 2018-06-14 19:38:48 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:40:37 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:44:02 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:44:13 --> Could not find the language line "Pull Leads from IndiaMart"
ERROR - 2018-06-14 19:46:02 --> Could not find the language line "Pull Leads from IndiaMart"
