<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . '/vendor/autoload.php';

use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

/**
 * Check estimate restrictions - hash, clientid
 * @param  mixed $id   estimate id
 * @param  string $hash estimate hash
 */
function check_estimate_restrictions($id, $hash)
{
    $CI =& get_instance();
    $CI->load->model('estimates_model');
    if (!$hash || !$id) {
        show_404();
    }
    if (!is_client_logged_in() && !is_staff_logged_in()) {
        if (get_option('view_estimate_only_logged_in') == 1) {
            redirect_after_login_to_current_url();
            redirect(site_url('clients/login'));
        }
    }
    $estimate = $CI->estimates_model->get($id);
    if (!$estimate || ($estimate->hash != $hash)) {
        show_404();
    }
    // Do one more check
    if (!is_staff_logged_in()) {
        if (get_option('view_estimate_only_logged_in') == 1) {
            if ($estimate->clientid != get_client_user_id()) {
                show_404();
            }
        }
    }
}

/**
 * Check if estimate email template for expiry reminders is enabled
 * @return boolean
 */
function is_estimates_email_expiry_reminder_enabled(){
    return total_rows('tblemailtemplates',array('slug'=>'estimate-expiry-reminder','active'=>1)) > 0;
}

/**
 * Check if there are sources for sending estimate expiry reminders
 * Will be either email or SMS
 * @return boolean
 */
function is_estimates_expiry_reminders_enabled(){
    return is_estimates_email_expiry_reminder_enabled() || is_sms_trigger_active(SMS_TRIGGER_ESTIMATE_EXP_REMINDER);
}

/**
 * Return RGBa estimate status color for PDF documents
 * @param  mixed $status_id current estimate status
 * @return string
 */
function estimate_status_color_pdf($status_id)
{
    if ($status_id == 1) {
        $statusColor = '119, 119, 119';
    } elseif ($status_id == 2) {
        // Sent
        $statusColor = '3, 169, 244';
    } elseif ($status_id == 3) {
        //Declines
        $statusColor = '252, 45, 66';
    } elseif ($status_id == 4) {
        //Accepted
        $statusColor = '0, 191, 54';
    } else {
        // Expired
        $statusColor = '255, 111, 0';
    }

    return $statusColor;
}

/**
 * Format estimate status
 * @param  integer  $status
 * @param  string  $classes additional classes
 * @param  boolean $label   To include in html label or not
 * @return mixed
 */
function format_estimate_status($status, $classes = '', $label = true)
{
    $id          = $status;
    $label_class = estimate_status_color_class($status);
    $status      = estimate_status_by_id($status);
    if ($label == true) {
        return '<span class="label label-' . $label_class . ' ' . $classes . ' s-status estimate-status-' . $id . ' estimate-status-' . $label_class . '">' . $status . '</span>';
    } else {
        return $status;
    }
}

/**
 * Return estimate status translated by passed status id
 * @param  mixed $id estimate status id
 * @return string
 */
function estimate_status_by_id($id)
{
    $status = '';
    if ($id == 1) {
        $status = _l('estimate_status_draft');
    } elseif ($id == 2) {
        $status = _l('estimate_status_sent');
    } elseif ($id == 3) {
        $status = _l('estimate_status_declined');
    } elseif ($id == 4) {
        $status = _l('estimate_status_accepted');
    } elseif ($id == 5) {
        // status 5
        $status = _l('estimate_status_expired');
    } else {
        if (!is_numeric($id)) {
            if ($id == 'not_sent') {
                $status = _l('not_sent_indicator');
            }
        }
    }

    $hook_data = do_action('estimate_status_label', array(
        'id' => $id,
        'label' => $status,
    ));
    $status    = $hook_data['label'];

    return $status;
}

/**
 * Return estimate status color class based on twitter bootstrap
 * @param  mixed  $id
 * @param  boolean $replace_default_by_muted
 * @return string
 */
function estimate_status_color_class($id, $replace_default_by_muted = false)
{
    $class = '';
    if ($id == 1) {
        $class = 'default';
        if ($replace_default_by_muted == true) {
            $class = 'muted';
        }
    } elseif ($id == 2) {
        $class = 'info';
    } elseif ($id == 3) {
        $class = 'danger';
    } elseif ($id == 4) {
        $class = 'success';
    } elseif ($id == 5) {
        // status 5
        $class = 'warning';
    } else {
        if (!is_numeric($id)) {
            if ($id == 'not_sent') {
                $class = 'default';
                if ($replace_default_by_muted == true) {
                    $class = 'muted';
                }
            }
        }
    }

    $hook_data = do_action('estimate_status_color_class', array(
        'id' => $id,
        'class' => $class,
    ));
    $class     = $hook_data['class'];

    return $class;
}

/**
 * Check if the estimate id is last invoice
 * @param  mixed  $id estimateid
 * @return boolean
 */
function is_last_estimate($id)
{
    $CI =& get_instance();
    $CI->db->select('id')->from('tblestimates')->order_by('id', 'desc')->limit(1);
    $query            = $CI->db->get();
    $last_estimate_id = $query->row()->id;
    if ($last_estimate_id == $id) {
        return true;
    }

    return false;
}

/**
 * Format estimate number based on description
 * @param  mixed $id
 * @return string
 */
function format_estimate_number($id)
{
    $CI =& get_instance();
    $CI->db->select('date,number,prefix,number_format')->from('tblestimates')->where('id', $id);
    $estimate = $CI->db->get()->row();

    if (!$estimate) {
        return '';
    }

    $format = $estimate->number_format;
    $prefix = $estimate->prefix;
    $number = $estimate->number;
    $date = $estimate->date;
    $prefixPadding = get_option('number_padding_prefixes');


    if ($format == 1) {
        // Number based
        return $prefix . str_pad($number, $prefixPadding, '0', STR_PAD_LEFT);
    } elseif ($format == 2) {
        // Year based
        return $prefix . date('Y', strtotime($date)) . '/' . str_pad($number, $prefixPadding, '0', STR_PAD_LEFT);
    } else if($format == 3) {
        // Number-yy based
        return $prefix . str_pad($number, $prefixPadding, '0', STR_PAD_LEFT)  . '-' . date('y', strtotime($date));
    } else if($format == 4) {
        // Number-mm-yyyy based
        return $prefix . str_pad($number, $prefixPadding, '0', STR_PAD_LEFT)  . '/' . date('m', strtotime($date)) . '/' . date('Y', strtotime($date));
    }

    $hook_data['id'] = $id;
    $hook_data['estimate'] = $estimate;
    $hook_data['formatted_number'] = $number;
    $hook_data = do_action('format_estimate_number',$hook_data);
    $number = $hook_data['formatted_number'];

    return $number;
}


/**
 * Function that return estimate item taxes based on passed item id
 * @param  mixed $itemid
 * @return array
 */
function get_estimate_item_taxes($itemid, $description = '')
{
    $CI =& get_instance();
    $CI->db->where('id', $itemid);
    if(!empty($description)){
        $CI->db->where('description', $description);
    }
    $tblitemsinData = $CI->db->get('tblitems_in')->row_array();
    if(!empty($tblitemsinData)){
        $CI->db->where('itemid', $itemid);
        $CI->db->where('rel_type', 'estimate');
        $taxes = $CI->db->get('tblitemstax')->result_array();
        $i     = 0;
        foreach ($taxes as $tax) {
            $taxes[$i]['taxname'] = $tax['taxname'] . '|' . $tax['taxrate'];
            $i++;
        }        
    }else{
        $taxes = array();

        $CI->db->select('tblitems.description, tbltaxes.name as taxname, tbltaxes.taxrate');
        $CI->db->from('tblitems');
        $CI->db->join('tbltaxes', 'tbltaxes.id = tblitems.tax', 'left');
        $CI->db->where('tblitems.description', $description);
        $tblitemsData = $CI->db->get()->row_array();
        if(is_array($tblitemsData) && isset($tblitemsData['description'])){
            $taxes[0]['taxname'] = $tblitemsData['taxname'] . '|' . $tblitemsData['taxrate'];
        }
    }
    return $taxes;
}

/**
 * Calculate estimates percent by status
 * @param  mixed $status          estimate status
 * @param  mixed $total_estimates in case the total is calculated in other place
 * @return array
 */
function get_estimates_percent_by_status($status, $total_estimates = '')
{
    $has_permission_view = has_permission('estimates', '', 'view');

    if (!is_numeric($total_estimates)) {
        $where_total = array();
        if (!$has_permission_view) {
            $where_total['addedfrom'] = get_staff_user_id();
        }
        $total_estimates = total_rows('tblestimates', $where_total);
    }

    $data            = array();
    $total_by_status = 0;

    if (!is_numeric($status)) {
        if ($status == 'not_sent') {
            $total_by_status = total_rows('tblestimates', 'sent=0 AND status NOT IN(2,3,4)' . (!$has_permission_view ? ' AND addedfrom=' . get_staff_user_id() : ''));
        }
    } else {
        $where = array(
            'status' => $status,
        );
        if (!$has_permission_view) {
            $where = array_merge($where, array(
                'addedfrom' => get_staff_user_id(),
            ));
        }
        $total_by_status = total_rows('tblestimates', $where);
    }

    $percent                 = ($total_estimates > 0 ? number_format(($total_by_status * 100) / $total_estimates, 2) : 0);
    $data['total_by_status'] = $total_by_status;
    $data['percent']         = $percent;
    $data['total']           = $total_estimates;

    return $data;
}
//calculating the offerprice with gst for sd store format
function get_offer_price_with_gst($data){
    $CI =& get_instance();
    /*Changing the offerprice with gst for sdstore custom order format*/
    $tax = $CI->estimates_model->get_tax($data);
    $crmTaxRate = !empty($tax->taxrate) ? $tax->taxrate : 0; 
    $gstRate = $crmTaxRate/100;
    $offerPriceGst = $data['offer_price'] * $gstRate;
    $offerPricewitheGst = $data['offer_price'] + $offerPriceGst;
   // $offerPricewitheGst = $data['offer_price'];
    return $offerPricewitheGst;
}

// Converting Customer
function convert_to_customer($data)
{    
    $CI =& get_instance();
    if ($data) {

        $default_country              = get_option('customer_default_country');
        $data                         = $data;
        $data['password'] = $data['password'];

        $original_lead_email          = $data['original_lead_email'];
        unset($data['original_lead_email']);

        if (isset($data['transfer_notes'])) {
            $notes = $CI->misc_model->get_notes($data['leadid'], 'lead');
            unset($data['transfer_notes']);
        }

        if (isset($data['merge_db_fields'])) {
            $merge_db_fields = $data['merge_db_fields'];
            unset($data['merge_db_fields']);
        }

        if (isset($data['merge_db_contact_fields'])) {
            $merge_db_contact_fields = $data['merge_db_contact_fields'];
            unset($data['merge_db_contact_fields']);
        }

        if (isset($data['include_leads_custom_fields'])) {
            $include_leads_custom_fields = $data['include_leads_custom_fields'];
            unset($data['include_leads_custom_fields']);
        }

        if ($data['country'] == '' && $default_country != '') {
            $data['country'] = $default_country;
        }

        $data['billing_street'] = $data['address'];
        $data['billing_city'] = $data['city'];
        $data['billing_state'] = $data['state'];
        $data['billing_zip'] = $data['zip'];
        $data['billing_country'] = $data['country'];

        $data['is_primary'] = 1;
        $id = $CI->clients_model->add($data, false); 
        if ($id) {
            if (isset($notes)) {
                foreach ($notes as $note) {
                    $CI->db->insert('tblnotes', array(
                        'rel_id'=>$id,
                        'rel_type'=>'customer',
                        'dateadded'=>$note['dateadded'],
                        'addedfrom'=>$note['addedfrom'],
                        'description'=>$note['description'],
                        'date_contacted'=>$note['date_contacted'],
                        ));
                }
            }
            if (!has_permission('customers', '', 'view') && get_option('auto_assign_customer_admin_after_lead_convert') == 1) {
                $CI->db->insert('tblcustomeradmins', array(
                    'date_assigned' => date('Y-m-d H:i:s'),
                    'customer_id' => $id,
                    'staff_id' => get_staff_user_id(),
                ));
            }
            $CI->leads_model->log_lead_activity($data['leadid'], 'not_lead_activity_converted', false, serialize(array(
                get_staff_full_name(),
            )));
            $default_status = $CI->leads_model->get_status('', array(
                'isdefault' => 1,
            ));
            $CI->db->where('id', $data['leadid']);
            $CI->db->update('tblleads', array(
                'date_converted' => date('Y-m-d H:i:s'),
                'status' => $default_status[0]['id'],
                'junk' => 0,
                'lost' => 0,
            ));
            // Check if lead email is different then client email
            $contact = $CI->clients_model->get_contact(get_primary_contact_user_id($id));
            if(!empty($contact)){
                if ($contact->email != $original_lead_email) {
                    if ($original_lead_email != '') {
                        $CI->leads_model->log_lead_activity($data['leadid'], 'not_lead_activity_converted_email', false, serialize(array(
                            $original_lead_email,
                            $contact->email,
                        )));
                    }
                }
            }
            if (isset($include_leads_custom_fields)) {
                foreach ($include_leads_custom_fields as $fieldid => $value) {
                    // checked don't merge
                    if ($value == 5) {
                        continue;
                    }
                    // get the value of CI leads custom fiel
                    $CI->db->where('relid', $data['leadid']);
                    $CI->db->where('fieldto', 'leads');
                    $CI->db->where('fieldid', $fieldid);
                    $lead_custom_field_value = $CI->db->get('tblcustomfieldsvalues')->row()->value;
                    // Is custom field for contact ot customer
                    if ($value == 1 || $value == 4) {
                        if ($value == 4) {
                            $field_to = 'contacts';
                        } else {
                            $field_to = 'customers';
                        }
                        $CI->db->where('id', $fieldid);
                        $field = $CI->db->get('tblcustomfields')->row();
                        // check if CI field exists for custom fields
                        $CI->db->where('fieldto', $field_to);
                        $CI->db->where('name', $field->name);
                        $exists               = $CI->db->get('tblcustomfields')->row();
                        $copy_custom_field_id = null;
                        if ($exists) {
                            $copy_custom_field_id = $exists->id;
                        } else {
                            // there is no name with the same custom field for leads at the custom side create the custom field now
                            $CI->db->insert('tblcustomfields', array(
                                'fieldto' => $field_to,
                                'name' => $field->name,
                                'required' => $field->required,
                                'type' => $field->type,
                                'options' => $field->options,
                                'display_inline' => $field->display_inline,
                                'field_order' => $field->field_order,
                                'slug' => slug_it($field_to . '_' . $field->name, array(
                                    'separator' => '_',
                                )),
                                'active' => $field->active,
                                'only_admin' => $field->only_admin,
                                'show_on_table' => $field->show_on_table,
                                'bs_column' => $field->bs_column,
                            ));
                            $new_customer_field_id = $CI->db->insert_id();
                            if ($new_customer_field_id) {
                                $copy_custom_field_id = $new_customer_field_id;
                            }
                        }
                        if ($copy_custom_field_id != null) {
                            $insert_to_custom_field_id = $id;
                            if ($value == 4) {
                                $insert_to_custom_field_id = get_primary_contact_user_id($id);
                            }
                            $CI->db->insert('tblcustomfieldsvalues', array(
                                'relid' => $insert_to_custom_field_id,
                                'fieldid' => $copy_custom_field_id,
                                'fieldto' => $field_to,
                                'value' => $lead_custom_field_value,
                            ));
                        }
                    } elseif ($value == 2) {
                        if (isset($merge_db_fields)) {
                            $db_field = $merge_db_fields[$fieldid];
                            // in case user don't select anything from the db fields
                            if ($db_field == '') {
                                continue;
                            }
                            if ($db_field == 'country' || $db_field == 'shipping_country' || $db_field == 'billing_country') {
                                $CI->db->where('iso2', $lead_custom_field_value);
                                $CI->db->or_where('short_name', $lead_custom_field_value);
                                $CI->db->or_like('long_name', $lead_custom_field_value);
                                $country = $CI->db->get('tblcountries')->row();
                                if ($country) {
                                    $lead_custom_field_value = $country->country_id;
                                } else {
                                    $lead_custom_field_value = 0;
                                }
                            }
                            $CI->db->where('userid', $id);
                            $CI->db->update('tblclients', array(
                                $db_field => $lead_custom_field_value,
                            ));
                        }
                    } elseif ($value == 3) {
                        if (isset($merge_db_contact_fields)) {
                            $db_field = $merge_db_contact_fields[$fieldid];
                            if ($db_field == '') {
                                continue;
                            }
                            $primary_contact_id = get_primary_contact_user_id($id);
                            $CI->db->where('id', $primary_contact_id);
                            $CI->db->update('tblcontacts', array(
                                $db_field => $lead_custom_field_value,
                            ));
                        }
                    }
                }
            }
            // set the lead to status client in case is not status client
            $CI->db->where('isdefault', 1);
            $status_client_id = $CI->db->get('tblleadsstatus')->row()->id;
            $CI->db->where('id', $data['leadid']);
            $CI->db->update('tblleads', array(
                'status' => $status_client_id,
            ));
            //set_alert('success', _l('lead_to_client_base_converted_success'));
            logActivity('Created Lead Client Profile [LeadID: ' . $data['leadid'] . ', ClientID: ' . $id . ']');
            do_action('lead_converted_to_customer', array('lead_id'=>$data['leadid'], 'customer_id'=>$id));
            //redirect(admin_url('clients/client/' . $id));
            return $id;
        }
    }
}



//Preparing curl functionality for API calls returning only objects
function commanCurl($url,$method){
    /*check customer in store curl*/
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch,CURLOPT_HTTPHEADER,array("authorization:".apiToken));
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $responseArray = array('statusCode' => $httpcode,'result' => $result);
    return $responseArray;
}

//Preparing curl functionality for API calls returning objects ad a combination of objects and arrays.
function elasticSearchAPICurl($url){

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($ch, CURLOPT_ENCODING, '');
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close ($ch);        
    return $result;
}
//Creating Curl
function createCurl($url,$payload,$method){
    /*create customer in store curl*/
    $ch = curl_init( $url );
    # Setup request to send json via POST.
    curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Accept:application/json',"authorization:".apiToken));
    # Return response instead of printing.
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
    # Send request.
    $result = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $responseArray = array('statusCode' => $httpcode,'result' => $result);
    return $responseArray;
}

function convertCustomOrderAndCreateCustomer($estimate, $invoiceId){
    if($estimate->is_from_leads == 1){
        $CI =& get_instance();
        $status = pushOrder($estimate, $invoiceId);
        return $status;  
    }
    else{
        $CI =& get_instance();
        $orderId = $CI->estimates_model->get_order_id($invoiceId);
        if(!empty($orderId->project_id)){
            $status = array('message' => 'order placed already', 'status' => 2);
            return $status;
        }else{
            $status = pushOrder($estimate, $invoiceId);
            return $status;  
        }
    }
}

function getSdstoreTax($taxId) {
    $CI =& get_instance();
    $result = $CI->estimates_model->get_storetax_id($taxId);
    return $result['store_tax_id'];
}

function getSdstoreTaxViaApi($sku) {
     $CI =& get_instance();
     $productLevelTaxId = '';
     $url = elasticUrl."_search?q=code:".$sku;
     $apiData = elasticSearchAPICurl($url,'GET');
     $jsonArray = json_decode($apiData,true);
     if(!empty($jsonArray['hits']['hits'])){
        $products = $jsonArray['hits']['hits'];
        foreach($products as $product){
            $productLevelTaxId = $product['_source']['taxid']; 
        }
    } else {
        $url = apiUrl.'products?fliter='.$CI->config->item('filterStatus').'&pcode='.$sku.'&company_id='.$CI->config->item('shakedealCompanyId');
        $apiData = commanCurl($url,'GET');
        $jsonArray = json_decode($apiData['result'],true);
        if(!empty($jsonArray['products'])){
            $products = $jsonArray['products'];
            foreach($products as $product){
                $productLevelTaxId = $product['tax_ids']; 
            }
        }
    }
    return !empty($productLevelTaxId) ? $productLevelTaxId : '';
} 

function pushOrder($estimate, $invoiceId){
    $CI =& get_instance();
    /*start of custom order code*/
    $productLists = array(); //generate product list
    $notAvailableProducts = array(); //products from crm
    $pivotData = $CI->estimates_model->get_pivot_data($estimate); // to get the order details for CI quote
    $count = 0;
    if(!empty($pivotData)){
        foreach($estimate->items as $item){
            $isStoreProduct = false;
            foreach($pivotData as $key => $data){
                if($item['long_description'] == $data['product_code']){
                    $productLevelTaxId = getSdstoreTaxViaApi($item['long_description']);
                    //checking is there any difference
                    !empty($productLevelTaxId) 
                    ?(
                        $item['tax_id'] != $productLevelTaxId 
                        ? $count++ 
                        : ''
                    ) 
                    : '';
                    $offerPrice = get_offer_price_with_gst($item); //using crm standard for helper function
                    $finalArray = array(
                                        'transferprice' => $item['rate'],
                                        'qty' => $item['qty'],
                                        'vendor' => $item['vendor'],
                                        'price' => $offerPrice,
                                        'tax_id' => $item['tax_id'] != 0 ? $item['tax_id'] : $productLevelTaxId, 
                                        'productcode' => $item['long_description']
                                        );
                       
                    /*Generating productlist for orderData*/
                    $productLists[] = array_merge($pivotData[$key],$finalArray);
                    $isStoreProduct = true;
                }
            }
            if(!$isStoreProduct){
                array_push($notAvailableProducts,$item);
            }
        }
    } else {
        foreach($estimate->items as $item){
            //checking tax updates for non-sdstore product i.e crm products(adhoc+existing)
            $productList = $CI->estimates_model->get_item_by_sku($item['long_description']);
            //to get order level tax id
            $taxId = $item['tax_id']; 
            //to get product level tax
            $productLevelTaxId = $productList['sd_store_status'] == $CI->config->item('adhocProductStatus') ? getSdstoreTax($productList['tax']) : getSdstoreTaxViaApi($item['long_description']);
            //checking is there any difference
            !empty($productLevelTaxId) 
            ?(
                $taxId != $productLevelTaxId 
                ? $count++ 
                : ''
             ) 
            : '';
            array_push($notAvailableProducts,$item);
        }
    }

    $finalProducts = array();
    //pushing sdproducts into products object
    $sdProducts = !empty($productLists) ? sdStoreJson($productLists, $estimate) : '' ;
    //pushing adhocproducts into products object
    $adhocProducts = !empty($notAvailableProducts) ? adhocJson($notAvailableProducts, $estimate) : '';
    //finalProducts data as per format
    $finalProducts = (!empty($notAvailableProducts) && !empty($productLists)) 
                     ? array_merge($sdProducts, $adhocProducts) 
                     : (!empty($sdProducts) 
                        ? $sdProducts 
                        : (!empty($notAvailableProducts)
                           ? $adhocProducts 
                           : ''
                          )
                        ) ;
    //user data
    $userData = userJson($estimate);
    $referenceNumber = bin2hex(random_bytes(16)); //reference number for api.
    $isTaxUpdatedOrder = $count > 0 ? 1 : 0;
    //getting sd-store sales-agent id to pass in order
    $salesAgentId = $CI->estimates_model->get_sd_store_sales_id($CI->session->userdata('staff_user_id'));
    $sdStoreSalesAgentId = !empty($salesAgentId) ? $salesAgentId['sdstore_staff_id'] : 17;
    //crm sales agent id
    $crmSalesAgentId = $CI->session->userdata('staff_user_id');
    //final order data
    $orderData = orderJson($finalProducts, $userData, $estimate,$referenceNumber, $sdStoreSalesAgentId, $isTaxUpdatedOrder);
    
    sendDataToQueue($orderData);
    //saving orderId in crm db
    $insertId = $CI->estimates_model->store_refid($estimate,$referenceNumber,$invoiceId,$crmSalesAgentId); 
    logActivity('Data sent to queue reference number is -'.$referenceNumber.' Related queue DB id -'.$insertId);
    
    $status = array(
                    'message' => 'success', 
                    'status' => 1 ,
                    'referenceNumber' => $referenceNumber
                   );
    return $status;

}

function sendDataToQueue($orderData){
    $CI =& get_instance();
    $queueDetails = $CI->config->item('queueDetails');

    $connection = new AMQPStreamConnection($queueDetails['ip'], $queueDetails['port'], $queueDetails['username'], $queueDetails['password']);
    $channel = $connection->channel();

    $channel->queue_declare($queueDetails['queuename'], false, false, false, false);

    $msg = new AMQPMessage(json_encode($orderData));

    $channel->basic_publish($msg, '', $queueDetails['queuename']);

    $channel->close();
    $connection->close();
}

function userJson($estimate){
    $CI =& get_instance();
    $userdata = array(
                     'companydata' => array(
                        'company' => !empty($estimate->client->name) ? $estimate->client->name : '',
                         'vendor_name' => !empty($estimate->client->company) ? $estimate->client->company : '',
                         'company_description' => $CI->config->item('companyDescription'),
                         'storefront' => 'api',
                         'status' => 'A',
                         'lang_code' => 'en',
                         'email' => $estimate->client->email,
                         'phone' => $estimate->client->phonenumber,
                         'url' => 'api',
                         'address' => !empty($estimate->client->address) ? strip_tags($estimate->client->address) : '',
                         'city' => !empty($estimate->client->city) ? strip_tags($estimate->client->city) : '',
                         'state' => !empty($estimate->client->state) ? $estimate->client->state : '',
                         'country' => 'IN',
                         'zipcode' => !empty($estimate->client->zip) ? $estimate->client->zip : '',
                         'terms' => $CI->config->item('terms')
                        ),
                        'vat_number' => $estimate->vat,
                        'email' => $estimate->client->email,
                        'user_type' => $CI->config->item('sdStoreUserType'),
                        'status'=> $CI->config->item('activeStatus'),
                        'firstname' => $estimate->client->name,
                        'lastname' => '',
                        's_firstname'=> $estimate->client->name,
                        'company' =>  !empty($estimate->client->company) ? $estimate->client->company : '',
                        'company_name' => !empty($estimate->client->company) ? $estimate->client->company : '' ,
                        's_lastname' => '',
                        's_country' => $CI->config->item('sdCountryCode'),
                        's_phone' => !empty($estimate->client->phonenumber) ? strip_tags($estimate->client->phonenumber) : '',
                        's_city' => !empty($estimate->shipping_city) ? strip_tags($estimate->shipping_city): strip_tags($estimate->client->city),
                        's_state' => !empty($estimate->shipping_state) ? $estimate->shipping_state : $estimate->client->state,
                        's_zipcode' => !empty($estimate->shipping_zip) ? $estimate->shipping_zip : '',
                        's_address' => !empty($estimate->shipping_street) ? strip_tags($estimate->shipping_street) : strip_tags($estimate->client->address),
                        'b_firstname' => $estimate->client->name,
                        'b_lastname' => '',
                        'b_country'=> $CI->config->item('sdCountryCode'),
                        'b_city' => strip_tags($estimate->billing_city),
                        'b_state' => strip_tags($estimate->billing_state),
                        'b_zipcode' => !empty($estimate->billing_zip) ? $estimate->billing_zip : '',
                        'b_address' => strip_tags($estimate->billing_street),
                        'b_phone' => !empty($estimate->billing_phone) ? $estimate->billing_phone : '',
                        'profile_type' => $CI->config->item('sdStoreUserProfileType'),
                        'buyer_register_status' => $CI->config->item('sdStoreBuyerRegisterStatus')
                     );
    return $userdata;

}

function orderJson($products,$user, $estimate,$referenceNumber,$sdStoreSalesAgentId,$isTaxUpdatedOrder){
    $CI =&get_instance();
    /*end*/
    $orderData = array(
                       'userdata' => $user,
                       'products' => $products,
                       'payment_id' => $estimate->paymentMethod,
                       'status' => $CI->config->item('sdStoreOrderStatus'),
                       'shipping_id' => $CI->config->item('sdStoreShippingId'),
                       'order_type' => $CI->config->item('sdStoreOrderType'),
                       'sales_person_id' => $sdStoreSalesAgentId ,
                       'purchase_order_no' => $estimate->poNumber,
                       'payment_terms' => $estimate->paymentTerms,
                       'details'=> $estimate->adminnote,
                       'po_date' => $estimate->poDate,
                       's_city' => strip_tags($estimate->shipping_city),
                       's_state' => $estimate->shipping_state,
                       's_zipcode' => strip_tags($estimate->shipping_zip) ,
                       's_address' => strip_tags($estimate->shipping_street),
                       's_country' => $CI->config->item('sdCountryCode'),
                       's_phone' => $estimate->shipping_phone,
                       'b_city' => strip_tags($estimate->billing_city),
                       'b_state' => $estimate->billing_state,
                       'b_zipcode' => $estimate->billing_zip,
                       'b_address' => strip_tags($estimate->billing_street),
                       'b_country' => $CI->config->item('sdCountryCode'),
                       'b_phone' => $estimate->billing_phone,
                       'ref_number' => $referenceNumber, // this is ref number send with json using for webhook.
                       'is_tax_updated_order' => $isTaxUpdatedOrder
                      );
    return $orderData;
}

function sdStoreJson($productLists, $estimate){
    $CI =& get_instance();
    $finalSdProducts = array();
    foreach ($productLists as $key => $productList) {   
        // default vendor get
        $defaultVendor = $CI->estimates_model->get_vendor($productList['product_id']);
        // check on pivot if mapping already exist or not 
        $checkSdVendorExists = $CI->estimates_model->check_sdstore_product_vendor_mapping($defaultVendor->vendor_id,$productList['productcode'],$defaultVendor->vendor_type); 
        //check the vendor created on sd-store or not
        $vendorCreationCheck = $defaultVendor->vendor_type != 1 ? $CI->estimates_model->check_vendor_status($defaultVendor->vendor_id) : ''; 
        //vendor 
        if(empty($vendorCreationCheck) && $defaultVendor->vendor_type != 1){
            //adhoc-vendor 
            $vendordata = adhocVendor($defaultVendor, $estimate);
        } else {
            //crm vendor created but not have product-vendor relationship
            $vendordata = empty($checkSdVendorExists) && !empty($vendorCreationCheck) ? existingCrmVendor($defaultVendor, $estimate, $vendorCreationCheck) : sdVendor($defaultVendor) ; 
        }
        //sd-store tax id if tax is changes order level
        $taxId = $productList['tax_id'];
        //sd-store products data
        $sdProductsData = sdproductsData($productList, $vendordata, $taxId);
        //pushing into array list
        array_push($finalSdProducts, $sdProductsData);
    }
    return $finalSdProducts;

}

function sdproductsData($productList, $companyData, $taxId){
    $data = array(
                    'product_id' => $productList['product_id'],
                    'crm_product_id' => '',
                    'vendorData' => $companyData,
                    'amount' => $productList['qty'],
                    'price' => $productList['price'],
                    'tax_ids' => $taxId,
                    'vendor_commission' => $productList['transferprice']
                );

    return $data;

}

function adhocJson($adhocProducts, $estimate){
    $CI =& get_instance();
    $finaladhocProducts = array();
    foreach ($adhocProducts as $key => $productList) { 
        //get the product data from crm using skucode
        $item = $CI->estimates_model->get_item_by_sku($productList['long_description']);
        //checking on pivot product is created on sd-store or not
        $checkProductExists = $CI->estimates_model->check_product_existsin_pivot($item['id'],$productList['description']);
        // default vendor get
        $defaultVendor = $CI->estimates_model->get_vendor($item['id']);
        //checking product-vendor mapping is exist or not 

        /*
            oldcode for checking the pivot
        $checkVendorExists = $CI->estimates_model->check_crm_product_vendor_mapping($defaultVendor->vendor_id,$item['id'],$defaultVendor->vendor_type);
        */

        $checkVendorExists = $defaultVendor->is_pushed == 1 || $defaultVendor->is_pushed == 2 ? $defaultVendor : '';

        //check the vendor created on sd-store or not
        $vendorCreationCheck = $defaultVendor->vendor_type != 1 ? $CI->estimates_model->check_vendor_status($defaultVendor->vendor_id) : '';
        //to get store tax id
        $orderLevelTaxId = $productList['tax_id'];
        $productLevelTaxId = $CI->estimates_model->get_storetax_id($item['tax']);
        $taxId = ($orderLevelTaxId == 0) ? $productLevelTaxId['store_tax_id'] : $orderLevelTaxId;
        
        //vendor data
        if(empty($vendorCreationCheck) && $defaultVendor->vendor_type != 1){
            //adhoc-vendor 
            $vendordata = adhocVendor($defaultVendor, $estimate);
        } else {
            //crm vendor created but not have product-vendor relationship
            $vendordata = empty($checkVendorExists) && !empty($vendorCreationCheck) 
                            ? existingCrmVendor($defaultVendor, $estimate, $vendorCreationCheck) 
                            : (!empty($checkVendorExists) && !empty($vendorCreationCheck) 
                                ? existingCrmVendor($defaultVendor, $estimate, $vendorCreationCheck) 
                                : sdVendor($defaultVendor)
                              ); 
        }
        //adhoc products data
        $sdProductsData = empty($checkProductExists) ? adhocProductData($productList, $vendordata, $item, $taxId) : existingCrmProductData($productList, $vendordata, $item, $taxId);
        //pushing into array list
        array_push($finaladhocProducts, $sdProductsData);
    }
    return $finaladhocProducts;

}

function adhocProductData($product, $companyData, $crmProductData, $taxId){
    $CI =& get_instance(); 
    $data = array(
                    'product_id' => '',
                    'product' => $product['description'],
                    'category_ids' => $CI->config->item('sdCategoryIds'),
                    'main_category' => $CI->config->item('sdMainCategoryForadhocProducts'),
                    'vendor_commission' => $product['rate'],
                    'quick_quote_check' => $CI->config->item('sdStoreQuoteCheck'),
                    'hsn_code' => $crmProductData['hsn_code'],
                    'product_code' => $product['long_description'],
                    'status' => $CI->config->item('sdStoreAdhocProductStatus'),
                    'tax_ids' => $taxId,
                    'amount' => $product['qty'] + $CI->config->item('adhocProductDefaultQty'),
                    'box_height'=> $CI->config->item('sdStoreQuoteCheck'),
                    'box_length'=> $CI->config->item('sdStoreQuoteCheck'),
                    'box_width'=> $CI->config->item('sdStoreQuoteCheck'),
                    'details_layout' => 'default',
                    'crm_product_id' => $crmProductData['id'],
                    'vendorData' => $companyData,
                    'amount' => $product['qty'],
                    'price' => $product['offer_price']
                );

    return $data;
}

function existingCrmProductData($productList, $companyData, $crmProductData,$taxId){
    $CI =&get_instance();
    $productVendor = $CI->estimates_model->get_shakedeal_team_child_product_id($crmProductData['id']);
    $inclusiveofGstPrice = get_offer_price_with_gst($productList);
    $productId = $productVendor->sdstore_vendor_child_product_id;
    $data = array(
                    'product_id' => $productId, //sd-store 98(sd-team) chlid product id
                    'crm_product_id' => $crmProductData['id'], //crm product id
                    'vendorData' => $companyData,
                    'amount' => $productList['qty'],
                    'price' => $inclusiveofGstPrice,
                    'tax_ids' => $taxId,
                    'vendor_commission' => $productList['rate']
                );

    return $data;
}

function existingCrmVendor($defaultVendor, $estimate, $vendorCreationCheck){
        $companyData = array(
                            "company_id" => $vendorCreationCheck->sdstore_company_id,
                            "vendor_id" => $vendorCreationCheck->sdstore_vendor_id,
                            "crm_vendor_id" => $defaultVendor->vendor_id 
                            );  
        return $companyData;     
}

function sdVendor($defaultVendor){
        $companyData = array(
                            "company_id" => $defaultVendor->vendor_id,
                            "vendor_id" => "",
                            "crm_vendor_id" => ""
                            );
        return $companyData;

}

function adhocVendor($vendor, $estimate){
        $CI =&get_instance();
        $vendordata = array(
                                'company_id' => "",
                                'vendor_id' =>  "",
                                'crm_vendor_id' => $vendor->vendor_id,
                                'companydata' => array(
                                                        'company' => !empty($vendor->companyname) ? $vendor->companyname : '',
                                                        'vendor_name' => !empty($vendor->companyname) ? $vendor->companyname : '',
                                                        'company_description' => $CI->config->item('companyDescription'),
                                                        'storefront' => $CI->config->item('sdStoreStoreFrontType'),
                                                        'status' => $CI->config->item('hiddenStatus'),
                                                        'lang_code' => $CI->config->item('sdLang'),
                                                        'email' => $vendor->email,
                                                        'fulfill_by' => $CI->config->item('sdStoreStoreFrontType'),
                                                        'phone' => $vendor->phone,
                                                        'sd_entity' => $vendor->sd_entity,
                                                        'shipment_type' => $vendor->shipment_type,
                                                        'url' => $CI->config->item('sdStoreStoreFrontType'),
                                                        'address' => !empty($vendor->address) ? strip_tags($vendor->address) : '',
                                                        'city' => !empty($vendor->city) ? strip_tags($vendor->city) : '',
                                                        'state' => !empty($vendor->state) ? $vendor->state : '',
                                                        'country' => $CI->config->item('sdCountryCode'),
                                                        'zipcode' => !empty($vendor->zip_postal_code) ? $vendor->zip_postal_code : '',
                                                        'terms' => $CI->config->item('terms')
                                                      ),

                                'user_type' => $CI->config->item('sdStoreUserType'),
                                'vat_number' => $vendor->gstin,
                                'email' => $vendor->email,
                                'status'=> $CI->config->item('hiddenStatus'),
                                'firstname' => $vendor->firstname,
                                'lastname' => '',
                                's_firstname'=> $vendor->firstname,
                                'company' =>  !empty($vendor->companyname) ? $vendor->companyname : '',
                                'company_name' => !empty($vendor->companyname) ? $vendor->companyname : '' ,
                                's_lastname' => '',
                                's_country' => $CI->config->item('sdCountryCode'),
                                's_phone' => !empty($vendor->phone) ? $vendor->phone : '',
                                's_city' => !empty($vendor->city) ? strip_tags($vendor->city): $vendor->city,
                                's_state' => !empty($vendor->state) ? $vendor->state : $vendor->state,
                                's_zipcode' => !empty($vendor->zip_postal_code) ? strip_tags($vendor->zip_postal_code) : '',
                                's_address' => !empty($vendor->address) ? strip_tags($vendor->address) : $vendor->address,
                                'b_firstname' => $vendor->firstname,
                                'b_lastname' => '',
                                'b_country'=> $CI->config->item('sdCountryCode'),
                                'b_city' => strip_tags($vendor->city),
                                'b_state' => $vendor->state,
                                'b_zipcode' => !empty($vendor->zip_postal_code) ? strip_tags($vendor->zip_postal_code) : '',
                                'b_address' => strip_tags($vendor->address),
                                'b_phone' => !empty($vendor->phone) ? $vendor->phone : '',
                                'profile_type' => $CI->config->item('sdStoreVendorProfileType')
                            );
        return $vendordata;

}

function send_order_email($orderId, $estimate, $invoiceId,$staffId){
        $CI =& get_instance();
        $detailsQuery = "SELECT description, long_description as sku, (select vendor_id from tblvendorproductmapping where product_code = sku and is_default_vendor = 1 limit 1) as vendor, qty, rate, (select unit from tblitems where long_description = sku limit 1) as unit, offer_price FROM tblitems_in WHERE rel_id='".$estimate->id."' and rel_type='estimate'";
        $detailsResult = $CI->db->query($detailsQuery)->result_array();

        $productDetails = array( );
        $vendors = array();
        
        foreach ($detailsResult as $details) {
            array_push($productDetails, $details);
            if(is_numeric($details['vendor'])){
                $vendorQuery = "SELECT * FROM tblvendor WHERE id='".$details['vendor']."'";
                $vendorResult = $CI->db->query($vendorQuery)->result_array();
                array_push($vendors,$vendorResult);
            }
        }
        
        $staffQuery = "SELECT firstname, lastname FROM tblstaff WHERE staffid='".$staffId."'";
        $staffResult = $CI->db->query($staffQuery)->row_array();
        $vendorInvoice = "SELECT * FROM tbl_invoice_vendor WHERE invoice_id=".$invoiceId;
        $vendorInvoiceResult = $CI->db->query($vendorInvoice)->result_array();
        $staffName = $staffResult['firstname'].' '.$staffResult['lastname'];
        $CI->load->helper('email_templates_helper');
        $CI->load->helper('constant_helper');
        $to = sd_store_team_order_email;
        $orderId = $orderId;
        if(!empty($vendorInvoiceResult)){
            foreach($vendorInvoiceResult as $key => $file){    
                $location = !empty($file['filepath']) ? $file['filepath'] : ''; 
                //$pdf = array();
                $pdf[] = '<hr /><h4> Please click the <a href="'.base_url($location).'">link</a> to download vendor invoice </h4>';
            }
        } else {
            $pdf[] = '';
        }

        $mail = sd_store_order_email($vendors,$staffName,$productDetails,$to,$orderId,$pdf,$CI,$vendorInvoiceResult);
        
}

