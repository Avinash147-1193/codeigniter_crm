<?php
    function getChartStaffCondition($staffarray){
        $staff_ids = '';

        if(is_array($staffarray)){
            if(count($staffarray) > 0){
                foreach ($staffarray as $key => $staff) {
                    $staff_ids .= $staff.",";
                }
                $staff_ids = rtrim($staff_ids, ',');
            }else{
                if($GLOBALS['current_user']->role == 1 || $GLOBALS['current_user']->role == 2 || $GLOBALS['current_user']->role == 3){
                    $staff_ids = $GLOBALS['current_user']->staffid;
                }
            }
        }else{
            if($GLOBALS['current_user']->role == 1 || $GLOBALS['current_user']->role == 2 || $GLOBALS['current_user']->role == 3){
                $staff_ids = $GLOBALS['current_user']->staffid;
            }
        }

        //Staff Condition
        $proposal_where = '';
        $quotes_where = '';
        $invoice_where = '';
        $tasks_where = '';
        if($staff_ids){
            $proposal_where .= "AND TP.assigned IN (".$staff_ids.")";
            $quotes_where .= "AND TE.sale_agent IN (".$staff_ids.")";
            $invoice_where .= "AND TI.sale_agent IN (".$staff_ids.")";
            $tasks_where .= "INNER JOIN tblstafftaskassignees TSTA ON TSTA.taskid=TST.id AND TSTA.staffid IN (".$staff_ids.")";
        }

        return array('proposal_where' => $proposal_where, 'quotes_where' => $quotes_where, 'invoice_where' => $invoice_where, 'tasks_where' => $tasks_where);
    }

    function getPieChartData($data = array()){
        return array('labels' => array_keys($data), 'values' => array_values($data));
    }
