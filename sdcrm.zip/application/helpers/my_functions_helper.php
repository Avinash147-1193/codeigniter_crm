<?php

add_action('after_render_single_aside_menu','my_custom_menu_items');

function my_custom_menu_items($order){
    if($order == 13 && ENVIRONMENT == 'development'){

       echo '<li class="menu-item-pi">';
       echo '<a href="'.base_url().'pi"><i class="fa fa-file-text-o menu-icon"></i>
            PI</span>
            </a>';

        echo '</li>';
    }
    
}

?>
