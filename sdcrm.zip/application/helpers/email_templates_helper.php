<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * All email client templates slugs used for sending the emails
 * If you create new email template you can and must add the slug here with action hook.
 * Those are used to identify in what language should the email template to be sent
 * @return array
 */
function get_client_email_templates_slugs()
{
    $client_email_templates_slugs = array(
        'new-client-created',
        'client-statement',
        'invoice-send-to-client',
        'new-ticket-opened-admin',
        'ticket-reply',
        'ticket-autoresponse',
        'assigned-to-project',
        'credit-note-send-to-client',
        'invoice-payment-recorded',
        'invoice-overdue-notice',
        'invoice-already-send',
        'estimate-send-to-client',
        'contact-forgot-password',
        'contact-password-reseted',
        'contact-set-password',
        'estimate-already-send',
        'contract-expiration',
        'proposal-send-to-customer',
        'proposal-client-thank-you',
        'proposal-comment-to-client',
        'estimate-thank-you-to-customer',
        'send-contract',
        'auto-close-ticket',
        'new-project-discussion-created-to-customer',
        'new-project-file-uploaded-to-customer',
        'new-project-discussion-comment-to-customer',
        'project-finished-to-customer',
        'estimate-expiry-reminder',
        'estimate-expiry-reminder',
        'task-status-change-to-contacts',
        'task-added-attachment-to-contacts',
        'task-commented-to-contacts',
    );

    return do_action('client_email_templates', $client_email_templates_slugs);
}
/**
 * All email staff templates slugs used for sending the emails
 * If you create new email template you can and must add the slug here with action hook.
 * Those are used to identify in what language should the email template to be sent
 * @return array
 */
function get_staff_email_templates_slugs()
{
    $staff_email_templates_slugs = array(
        'reminder-email-staff',
        'new-ticket-created-staff',
        'two-factor-authentication',
        'ticket-reply-to-admin',
        'ticket-assigned-to-admin',
        'task-assigned',
        'task-added-as-follower',
        'task-commented',
        'staff-password-reseted',
        'staff-forgot-password',
        'task-status-change-to-staff',
        'task-added-attachment',
        'estimate-declined-to-staff',
        'estimate-accepted-to-staff',
        'proposal-client-accepted',
        'proposal-client-declined',
        'proposal-comment-to-admin',
        'task-deadline-notification',
        'invoice-payment-recorded-to-staff',
        'new-project-discussion-created-to-staff',
        'new-project-file-uploaded-to-staff',
        'new-project-discussion-comment-to-staff',
        'staff-added-as-project-member',
        'new-staff-created',
        'new-client-registered-to-admin',
        'new-lead-assigned',
    );

    return do_action('staff_email_templates', $staff_email_templates_slugs);
}
/**
 * Function that will return in what language the email template should be sent
 * @param  string $template_slug the template slug
 * @param  string $email         email that this template will be sent
 * @return string
 */
function get_email_template_language($template_slug, $email)
{
    $CI =& get_instance();
    $language = get_option('active_language');

    if (total_rows('tblcontacts', array(
        'email' => $email,
    )) > 0 && in_array($template_slug, get_client_email_templates_slugs())) {
        $CI->db->where('email', $email);

        $contact = $CI->db->get('tblcontacts')->row();
        $lang    = get_client_default_language($contact->userid);
        if ($lang != '') {
            $language = $lang;
        }
    } elseif (total_rows('tblstaff', array(
            'email' => $email,
        )) > 0 && in_array($template_slug, get_staff_email_templates_slugs())) {
        $CI->db->where('email', $email);
        $staff = $CI->db->get('tblstaff')->row();

        $lang = get_staff_default_language($staff->staffid);
        if ($lang != '') {
            $language = $lang;
        }
    } elseif (class_exists('Emails_model') || defined('EMAIL_TEMPLATE_PROPOSAL_ID_HELP')) {
        if (defined('EMAIL_TEMPLATE_PROPOSAL_ID_HELP')) {
            $CI->db->select('rel_type,rel_id')
            ->where('id', EMAIL_TEMPLATE_PROPOSAL_ID_HELP);
            $proposal = $CI->db->get('tblproposals')->row();
        } else {
            // check for leads default language
            if ($CI->emails_model->get_rel_type() == 'proposal') {
                $CI->db->select('rel_type,rel_id')
            ->where('id', $CI->emails_model->get_rel_id());
                $proposal = $CI->db->get('tblproposals')->row();
            }
            if (isset($proposal) && $proposal && $proposal->rel_type == 'lead') {
                $CI->db->select('default_language')
                ->where('id', $proposal->rel_id);

                $lead = $CI->db->get('tblleads')->row();

                if ($lead && !empty($lead->default_language)) {
                    $language = $lead->default_language;
                }
            }
        }
    }

    $hook_data['language'] = $language;
    $hook_data['template_slug'] = $template_slug;
    $hook_data['email'] = $email;

    $hook_data = do_action('email_template_language', $hook_data);
    $language = $hook_data['language'];

    return $language;
}

/**
 * Based on the template slug and email the function will fetch a template from database
 * The template will be fetched on the language that should be sent
 * @param  string $template_slug
 * @param  string $email
 * @return object
 */
function get_email_template_for_sending($template_slug, $email)
{
    $CI =& get_instance();

    $language = get_email_template_language($template_slug, $email);

    if (!is_dir(APPPATH . 'language/' . $language)) {
        $language = 'english';
    }

    $CI->db->where('language', $language);
    $CI->db->where('slug', $template_slug);
    $template = $CI->db->get('tblemailtemplates')->row();

    // Template languages not yet inserted
    // Users needs to visit Setup->Email Templates->Any template to initialize all languages
    if (!$template) {
        $CI->db->where('language', 'english');
        $CI->db->where('slug', $template_slug);
        $template = $CI->db->get('tblemailtemplates')->row();
    } else {
        if ($template && $template->message == '') {
            // Template message blank use the active language default template
            $CI->db->where('language', get_option('active_language'));
            $CI->db->where('slug', $template_slug);
            $template = $CI->db->get('tblemailtemplates')->row();

            if ($template->message == '') {
                $CI->db->where('language', 'english');
                $CI->db->where('slug', $template_slug);
                $template = $CI->db->get('tblemailtemplates')->row();
            }
        }
    }

    return $template;
}

/**
 * Parse email template with the merge fields
 * @param  mixed $template     template
 * @param  array  $merge_fields
 * @return object
 */
function parse_email_template($template, $merge_fields = array())
{
    $CI =& get_instance();
    if (!is_object($template) || $CI->input->post('template_name')) {
        $original_template = $template;
        if ($CI->input->post('template_name')) {
            $template = $CI->input->post('template_name');
        }
        $CI->db->where('slug', $template);
        $template = $CI->db->get('tblemailtemplates')->row();

        if ($CI->input->post('email_template_custom')) {
            $template->message = $CI->input->post('email_template_custom', false);
            // Replace the subject too
            $template->subject = $original_template->subject;
        }
    }
    $template = _parse_email_template_merge_fields($template, $merge_fields);


    return do_action('email_template_parsed', $template);
}

/**
 * This function will parse email template merge fields and replace with the corresponding merge fields passed before sending email
 * @param  object $template     template from database
 * @param  array $merge_fields available merge fields
 * @return object
 */
function _parse_email_template_merge_fields($template, $merge_fields)
{
    $merge_fields = array_merge($merge_fields, get_other_merge_fields());
    foreach ($merge_fields as $key => $val) {
        if (stripos($template->message, $key) !== false) {
            $template->message = str_ireplace($key, $val, $template->message);
        } else {
            $template->message = str_ireplace($key, '', $template->message);
        }
        if (stripos($template->fromname, $key) !== false) {
            $template->fromname = str_ireplace($key, $val, $template->fromname);
        } else {
            $template->fromname = str_ireplace($key, '', $template->fromname);
        }
        if (stripos($template->subject, $key) !== false) {
            $template->subject = str_ireplace($key, $val, $template->subject);
        } else {
            $template->subject = str_ireplace($key, '', $template->subject);
        }
    }

    return $template;
}


 function sd_store_order_email($vendors, $staffName, $productDetails, $to, $orderid,$pdf, $CI, $vendorInvoiceResult)
    {       
            $CI =& get_instance();
            $CI->load->helper('common_helper');
            $sd_store_vendor = load_sd_store_vendors();
            
            $subject = "A new order has been placed on SD-STORE!";
            $message = '<!doctype html>
                            <html>
                            <head>
                              <meta name="viewport" content="width=device-width" />
                              <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
                              <style>
                                body {
                                 background-color: #f6f6f6;
                                 font-family: sans-serif;
                                 -webkit-font-smoothing: antialiased;
                                 font-size: 14px;
                                 line-height: 1.4;
                                 margin: 0;
                                 padding: 0;
                                 -ms-text-size-adjust: 100%;
                                 -webkit-text-size-adjust: 100%;
                               }
                               table {
                                 border-collapse: separate;
                                 mso-table-lspace: 0pt;
                                 mso-table-rspace: 0pt;
                                 width: 100%;
                               }
                               table td {
                                 font-family: sans-serif;
                                 font-size: 14px;
                                 vertical-align: top;
                               }
                                   /* -------------------------------------
                                     BODY & CONTAINER
                                     ------------------------------------- */
                                     .body {
                                       background-color: #f6f6f6;
                                       width: 100%;
                                     }
                                     /* Set a max-width, and make it display as block so it will automatically stretch to that width, but will also shrink down on a phone or something */

                                     .container {
                                       display: block;
                                       margin: 0 auto !important;
                                       /* makes it centered */
                                       max-width: 680px;
                                       padding: 10px;
                                       width: 680px;
                                     }
                                     /* This should also be a block element, so that it will fill 100% of the .container */

                                     .content {
                                       box-sizing: border-box;
                                       display: block;
                                       margin: 0 auto;
                                       max-width: 680px;
                                       padding: 10px;
                                     }
                                   /* -------------------------------------
                                     HEADER, FOOTER, MAIN
                                     ------------------------------------- */

                                     .main {
                                       background: #fff;
                                       border-radius: 3px;
                                       width: 100%;
                                     }
                                     .wrapper {
                                       box-sizing: border-box;
                                       padding: 20px;
                                     }
                                     .footer {
                                       clear: both;
                                       padding-top: 10px;
                                       text-align: center;
                                       width: 100%;
                                     }
                                     .footer td,
                                     .footer p,
                                     .footer span,
                                     .footer a {
                                       color: #999999;
                                       font-size: 12px;
                                       text-align: center;
                                     }
                                     hr {
                                       border: 0;
                                       border-bottom: 1px solid #f6f6f6;
                                       margin: 20px 0;
                                     }
                                   /* -------------------------------------
                                     RESPONSIVE AND MOBILE FRIENDLY STYLES
                                     ------------------------------------- */

                                     @media only screen and (max-width: 620px) {
                                       table[class=body] .content {
                                         padding: 0 !important;
                                       }
                                       table[class=body] .container {
                                         padding: 0 !important;
                                         width: 100% !important;
                                       }
                                     }
                                   </style>
                                 </head>
                                 <body class="">
                                  <table  class="body">
                                    <tr>
                                     <td>&nbsp;</td>
                                     <td class="container">
                                      <div class="content">
                                        <!-- START CENTERED WHITE CONTAINER -->
                                        <table class="main">
                                          <!-- START MAIN CONTENT AREA -->
                                          <tr>
                                           <td class="wrapper">
                                            <table  >
                                              <tr>
                                               <td>
                            <span style="font-size: 12pt;"><span style="font-size: 10pt;"><img src="https://cdn.shakedeal.com/images/logos/2/ShakeDealLogo.png?t=1542723379" alt="" width="132" height="35" />
                            <h4> A new order has been placed on SD-STORE. Please go through the details in the below table.</h4>
                            <strong>Order ID:OD'.$orderid.'</strong>
                            <h4> Regards <br/> Sales Agent: '.$staffName.'<br /><table style="width:100%; border-collapse:collapse;"><br />
                              <caption>Order details</caption>
                              <tr>
                                <th style="border:1px solid black;">Product name</th>
                                <th style="border:1px solid black;">Price</th>
                                <th style="border:1px solid black;">T.P</th>
                                <th style="border:1px solid black;">Unit</th>
                                <th style="border:1px solid black;">Vendor Details</th>
                                <th style="border:1px solid black;">Quantity</th>
                              </tr>
                              ';
                               
                           foreach ($productDetails as $productDetails) {

                                    $message .=  '<tr><td style="border:1px solid black;">'.$productDetails['description'].'</td>';
                                    $message .=  '<td style="border:1px solid black;">'.$productDetails['offer_price'].'</td>';
                                    $message .=  '<td style="border:1px solid black;">'.$productDetails['rate'].'</td>';
                                    $message .=  '<td style="border:1px solid black;">'.$productDetails['unit'].'</td>';
                                    $count = 0;
                                    if(is_numeric($productDetails['vendor'])){
                                        $CI =& get_instance();
                                        $sql = "select vendor_type, is_pushed from tblvendorproductmapping where vendor_id=".$productDetails['vendor']." AND product_code = '".$productDetails['sku']."' ";
                                        $res = $CI->db->query($sql)->row_array();
                                        
                                        if($res['vendor_type'] == 0 && $res['is_pushed'] == 0){ 
                                            foreach ($vendors as $vendor) {
                                                foreach ($vendor as $vendo){
                                                    $vendo['firstname']     = !empty($vendo['firstname']) ? $vendo['firstname'] : 'N/A';
                                                    $vendo['companyname']   = !empty($vendo['companyname']) ? $vendo['companyname'] : 'N/A';
                                                    $vendo['phone']         = !empty($vendo['phone']) ? $vendo['phone'] : 'N/A';
                                                    $vendo['address']       = !empty($vendo['address']) ? $vendo['address'] : 'N/A';
                                                    $vendo['gstin']         = !empty($vendo['gstin']) ? $vendo['gstin'] : 'N/A';
                                                    $vendo['sd_entity']     = !empty($vendo['sd_entity']) ? $vendo['sd_entity'] : 'N/A';
                                                    $vendo['shipment_type'] = !empty($vendo['shipment_type']) ? $vendo['shipment_type'] : 'N/A';
                                                    
                                                    if($vendo['id'] == $productDetails['vendor'] && $count == 0){
                                                        $message .= '<td style="border:1px solid black;">Name: '.$vendo['firstname'].'<br/> Company: '.$vendo['companyname'].'<br/>  Mobile: '.$vendo['phone'].'<br/>  Address: '.$vendo['address'].'<br/> GSTIN: '.$vendo['gstin'].'<br/>  SD-Entity: '.$vendo['sd_entity'].'<br/>  Shipment Type: '.$vendo['shipment_type'].'</td>';
                                                        $count++;
                                                    }
                                                }
                                            }
                                        } 
                                        elseif($res['vendor_type'] == 1 ){
                                            foreach ($sd_store_vendor as $keyTemp => $valueTemp) {
                                                if($valueTemp['company_id'] == $productDetails['vendor'] && $count == 0 ){
                                                    $vendo['firstname']     = !empty($valueTemp['firstname']) ? $valueTemp['firstname'] : 'N/A';
                                                    $vendo['companyname']   = !empty($valueTemp['company']) ? $valueTemp['company'] : 'N/A';
                                                    $vendo['phone']         = !empty($valueTemp['phone']) ? $valueTemp['phone'] : 'N/A';
                                                    $vendo['address']       = !empty($valueTemp['address']) ? $valueTemp['address'] : 'N/A';
                                                    $vendo['gstin']         = !empty($valueTemp['GSTIN']) ? $valueTemp['GSTIN'] : 'N/A';
                                                    $vendo['sd_entity']     = !empty($valueTemp['sd_entity']) ? $valueTemp['sd_entity'] : 'N/A';
                                                    $vendo['shipment_type'] = !empty($valueTemp['shipment_type']) ? $valueTemp['shipment_type'] : 'N/A';
                                                }
                                            }
                                            $message .= '<td style="border:1px solid black;">Name: '.$vendo['firstname'].'<br/> Company: '.$vendo['companyname'].'<br/>  Mobile: '.$vendo['phone'].'<br/>  Address: '.$vendo['address'].'<br/> GSTIN: '.$vendo['gstin'].'<br/>  SD-Entity: '.$vendo['sd_entity'].'<br/>  Shipment Type: '.$vendo['shipment_type'].'</td>';
                                            $count++;
                                        }
                                        elseif($res['vendor_type'] == 0 && $res['is_pushed'] == 1){
                                            $getvendorquery = "SELECT tblcrmstore_vendor.sdstore_company_id as vendor_id FROM tblcrmstore_vendor WHERE tblcrmstore_vendor.crm_vendor_id=".$productDetails['vendor'];
                                            $vendorname = $CI->db->query($getvendorquery)->row_array();
                                            
                                            foreach ($sd_store_vendor as $keyTemp => $valueTemp) {
                                                if($valueTemp['company_id'] == $vendorname['vendor_id']  && $count == 0){
                                                    $vendo['firstname']     = !empty($valueTemp['firstname']) ? $valueTemp['firstname'] : 'N/A';
                                                    $vendo['companyname']   = !empty($valueTemp['company']) ? $valueTemp['company'] : 'N/A';
                                                    $vendo['phone']         = !empty($valueTemp['phone']) ? $valueTemp['phone'] : 'N/A';
                                                    $vendo['address']       = !empty($valueTemp['address']) ? $valueTemp['address'] : 'N/A';
                                                    $vendo['gstin']         = !empty($valueTemp['GSTIN']) ? $valueTemp['GSTIN'] : 'N/A';
                                                    $vendo['sd_entity']     = !empty($valueTemp['sd_entity']) ? $valueTemp['sd_entity'] : 'N/A';
                                                    $vendo['shipment_type'] = !empty($valueTemp['shipment_type']) ? $valueTemp['shipment_type'] : 'N/A';
                                                }
                                            }
                                            $message .= '<td style="border:1px solid black;">Name: '.$vendo['firstname'].'<br/> Company: '.$vendo['companyname'].'<br/>  Mobile: '.$vendo['phone'].'<br/>  Address: '.$vendo['address'].'<br/> GSTIN: '.$vendo['gstin'].'<br/>  SD-Entity: '.$vendo['sd_entity'].'<br/>  Shipment Type: '.$vendo['shipment_type'].'</td>';
                                            $count++;
                                        }
                                    }
                                    else{
                                        $vendorName = !empty($productDetails['vendor']) ? $productDetails['vendor'] : 'SD-STORE VENDOR' ;   
                                        $message .=  '<td style="border:1px solid black;">'.$vendorName.'</td>';
                                    }

                                    $message .=  '<td style="border:1px solid black;">'.$productDetails['qty'].'</td> </tr>';
                                }
                             
                              
                           $message .= '</table>';
                            if(!empty($vendorInvoiceResult)){
                                foreach($pdf as $file){
                                    $message .= !empty($file) ? $file : '';
                                }
                            }
                           $message .= '<hr /><a href="https://www.shakedeal.com/all-categories" target="_blank"><img src="https://crm.shakedeal.com/media/public/Emailer.jpg"  alt="Shakedeal Categories" title="Shakedeal Categories" style="display:block"  width="700px" height="170px" /></a></span><span style="font-size: 12pt;"></span>
                            <hr />
                           
                            
                            <hr />
                           
                            <div style="text-align: center;"><a href="https://www.facebook.com/shakedeal" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/facebook.png" height="30px" width="30px" /></a> <a href="https://www.linkedin.com/company/shakedeal" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/Linkedin.png" height="30px" width="30px" /></a> <a href="https://twitter.com/shakedeal" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/Twitter.png" height="30px" width="30px" /></a> <a href="https://www.instagram.com/shakedeal/" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/instagram-icon.png" height="30px" width="30px" /></a> <a href="https://www.pinterest.com/shakedeal1591/" target="_blank" rel="noopener"><img src="https://crm.shakedeal.com/media/public/pinterest.png" height="30px" width="30px" /></a> <a href="https://www.youtube.com/channel/UCjkHdn9RBKxmgFQ1vNGfxgw" target="_blank"><img src="https://crm.shakedeal.com/media/public/youtube.png"  height="30px" width="30px"></a>&nbsp;</div>
                            </td>
                             </tr>
                           </table>
                         </td>
                       </tr>
                       <!-- END MAIN CONTENT AREA -->
                     </table>
                     <!-- START FOOTER -->
                     <div class="footer">
                      <table border="0" cellpadding="0" cellspacing="0">
                        <tr>
                          <td class="content-block">
                            <span></span>
                          </td>
                        </tr>
                      </table>
                    </div>
                    <!-- END FOOTER -->
                    <!-- END CENTERED WHITE CONTAINER -->
                  </div>
                </td>
                <td>&nbsp;</td>
              </tr>
            </table>
            </body>
            </html>';
            // Always set content-type when sending HTML email
            $CI->load->model('emails_model');
            $CI->load->library('email');
            $template = new StdClass();
            $template->message = $message;
            $template->fromname = get_option('companyname');
            $template->subject = $subject;

            $template = parse_email_template($template);

            do_action('before_send_test_smtp_email');
            $CI->email->initialize();
            $CI->email->set_newline("\r\n");
            $CI->email->from(get_option('smtp_email'), $template->fromname);
            $CI->email->to($to);

            $systemBCC = get_option('bcc_emails');

            if($systemBCC != ""){
                $CI->email->bcc($systemBCC);
            }

            $CI->email->subject($template->subject);
            $CI->email->message($template->message);
            if($CI->email->send(true)){
                return 1;
                logActivity('automated email generated');
            }
            else{
                logActivity('automated email failed to generate');
                return 0;
            }
    }


