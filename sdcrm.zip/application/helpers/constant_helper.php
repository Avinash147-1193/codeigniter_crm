<?php
defined('BASEPATH') or exit('No direct script access allowed');

define('devElasticUrl','http://159.89.160.137:9489/crmindex/');
define('qaElasticUrl', 'http:/159.89.160.137:9489/crmindex_qa/');
define('prodElasticUrl','http://139.59.149.72:9200/crmindex/');
define('devImageUrl','http://sddev.shakedeal.com/images/detailed/');
define('prodImageUrl','https://www.shakedeal.com/images/detailed/');
$sdstoreApi =  ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? (ENVIRONMENT == 'development' ? 'https://sddev.shakedeal.com/api/' : 'https://sdqa.shakedeal.com/api/') : 'https://www.shakedeal.com/api/';
//emailConfig
//elasticUrl
$elasticUrl = (ENVIRONMENT == 'development' || ENVIRONMENT == 'testing')
                ? (ENVIRONMENT == 'development') 
                    ? devElasticUrl 
                    : qaElasticUrl 
                : prodElasticUrl;
define('elasticUrl', $elasticUrl);

$trackOrder =  ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? (ENVIRONMENT == 'development' ? 'http://sddev.shakedeal.com/track-order' : 'https://sdqa.shakedeal.com/track-order') : 'https://www.shakedeal.com/track-order';
define('trackOrder',$trackOrder );

define('trackOrderColumnId', 'Track Order' );
define('trackOrderColumnElementId', 11 );
define('referenceNumberColumnId', 'Reference Number' );
define('referenceNumberColumnElementId', 12 );
$emailConfig = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? 'vinay.kumar@shakedeal.com,jaganath@shakedeal.com,avinash.dwivedi@shakedeal.com' : 'operations@shakedeal.com,pankaj@shakedeal.com';
//mailchimp api keys
$mailChimpApiKey = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? '9c3e27c46de23fa58a6028b9e11b1071-us5' : 'a3fae4e65322638f616072ebf2c00a71-us12';
$mailChimpUniqueKey = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? '890d391828' : 'd7c053b7f2';

$sdstoreApiToken = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? (ENVIRONMENT == 'development' ? 'Basic YWRtaW5Ac2hha2VkZWFsLmNvbTpQNEs1SnRlODI0MDJENUhCOTA0NzhIRTQwUFU5MEVHOQ==' : 'Basic YWRtaW5Ac2hha2VkZWFsLmNvbTpQNEs1SnRlODI0MDJENUhCOTA0NzhIRTQwUFU5MEVHOQ==') : 'Basic YWRtaW5Ac2hha2VkZWFsLmNvbTpQNEs1SnRlODI0MDJENUhCOTA0NzhIRTQwUFU5MEVHOQ==';


define('sdstoreApi', $sdstoreApi."Bulkenquiryapi&timestamp=");
define('update_vendor_api', $sdstoreApi."Vendor/");
define('sdstoreApiToken', $sdstoreApiToken);
define('piApiUrl', 'localhost:3000/');
define('countryCode', 102);
define('enqOpenStatus', 1);
define('defaultAddedFrom', 1);
define('currencyINR', 1);
define('sdBulkEnquiryDocs', 'bulk_enquiry_docs/');
define('sdBulkEnqtitle', 'Bulk Enquiry from sd-store');
define('successCode', 200);
define('createdCode', 201);
define('mailChimpApiKey', $mailChimpApiKey);
define('mailChimpUniqueKey', $mailChimpUniqueKey);
define('sd_store_team_order_email', $emailConfig); //email
define('is_default_vendor', 1);
define('is_not_default_vendor', 0);
define('is_crm_product', 'CRMPRO');
define('vendor_source_crm', 'CRM');
define('vendor_source_sd_store', 'SD-STORE');
function curl($url,$method){
    /*curl*/
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch,CURLOPT_HTTPHEADER,array("authorization:".sdstoreApiToken));
    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close ($ch);
    $responseArray = array('statusCode' => $httpcode,'result' => $result);
    return $responseArray;
}

