<?php
/**
 * Check if Item is disabled or discontinued and unset that item from itemlist
 * @param  array  $items
 * @return array
 */

function unsetInactiveItems($items = array()){    
    $CI =& get_instance();
    $i = 0;
    $newItemList = array();
    foreach ($items as $key => $item) {
        if(isset($item['status'])){
           if($item['status'] == '1'){
                array_push($newItemList, $item);
           }
        }else{
            $CI->db->where('description',$item['description']);
            $itemCheck = $CI->db->get('tblitems')->row_array();
            if((is_array($itemCheck) && isset($itemCheck['status']) && $itemCheck['status'] == 1) || (!isset($itemCheck['status']))){
                array_push($newItemList, $item);
            }
        }
    }
    return $newItemList;
}

/**
 * Change item status
 * @param  array  $items
 * @return boolean
 */
function changeItemStatus($items = array(), $checkedItems = array(), $rel_type = '', $rel_id = ''){
    $CI =& get_instance();
    foreach($items as $key => $item) {
        if(in_array($item['itemid'], $checkedItems)){
            $items[$key]['status'] = '1';
        }else{
            $items[$key]['status'] = '2';

            $CI->db->select('id');
            $CI->db->from('tblitems_in');
            $CI->db->where('description', $item['description']);
            $CI->db->where('rel_id', $rel_id);
            $CI->db->where('rel_type', $rel_type);
            $query = $CI->db->get();
            $checkItem = $query->row_array();

            if(is_array($checkItem) && isset($checkItem['id'])){
                $CI->db->where('id', $item['itemid']);
                $CI->db->where('rel_id', $rel_id);
                $CI->db->where('rel_type', $rel_type);
                $CI->db->delete('tblitems_in');
            }
        }
        if($rel_type == 'proposal'){
            $CI->db->where('description', $item['description']);
            $CI->db->update('tblitems', array('status' => $items[$key]['status'])); 
        }
    }
    return true;
}

function find_text_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function get_sdstore_product_data($field_name, $product_code){
    get_instance()->load->helper('constant_helper');
    $elasticUrl = elasticUrl;
    $imgurl = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? devImageUrl : prodImageUrl ;
    $url = $elasticUrl."_search?q=code:".$product_code;
    $data = 'Not Available';
    $result = comman_curl_function($url); 
    $jsonArray = json_decode($result,true);
    $shiftArray = array(); //temp variable
    $shiftArray = !empty($jsonArray['hits']['hits']) ? $jsonArray['hits']['hits'] : "" ;
    if(!empty($shiftArray)){
        foreach ($shiftArray as $value) {
            $data = rtrim($value['_source'][$field_name]);
        }
    }
    return $data;
}

function comman_curl_function($url){

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
    curl_setopt($ch, CURLOPT_ENCODING, '');
    $result = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close ($ch);        
    return $result;
}

function load_sd_store_vendors() {
    $url = apiUrl."Orderassign";
    $result = commanCurl($url,'GET');
    $result_array = array();
    $jsonArray = json_decode($result['result'],true);
    return $jsonArray;
}

function return_allowed_charactres($string){
    $string = preg_replace("/[^a-zA-Z0-9%&*-|:().,_ '+'\"\/]+/", '', $string);
    return $string;
}

function load_sd_store_vendor_by_id($id) {
    $url = apiUrl."Orderassign/".$id;
    $result = commanCurl($url,'GET');
    $result_array = array();
    $jsonArray = json_decode($result['result'],true);
    return $jsonArray;
}