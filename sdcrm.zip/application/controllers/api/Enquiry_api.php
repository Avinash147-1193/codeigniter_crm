<?php
    require (APPPATH.'/libraries/REST_Controller.php');
    
    defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
//require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Enquiry_api extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['enquiry_post']['limit'] = 500; // 500 requests per hour per user/key
        $this->methods['enquiry_get']['limit'] = 100; // 100 requests per hour per user/key
        $this->methods['users_delete']['limit'] = 50; // 50 requests per hour per user/key
        $this->load->model('leads_model');
        $this->load->model('proposals_model');
    }

        public function enquiry_get()
    {
      $response = array('status'=>0, 'message'=> 'Unauthorized');
      echo json_encode($response);
    }

    public function enquiry_post()
    {
        $enquiryValue = array();
        $input = $this->post();
        $this->db->where('email', $input['username']);
        $user = $this->db->get('tblstaff')->row();
        $this->load->helper('phpass');
        $hasher = new PasswordHash(PHPASS_HASH_STRENGTH, PHPASS_HASH_PORTABLE);
        //checking the api call usercredentials if correct or not        
        if($hasher->CheckPassword($input['password'], $user->password)){
            //to add lead/customer enquiry
              echo $this->api_call($input);
        }   
        else{
            //unautorized error
            $response = array('status'=>0, 'message'=> 'Unauthorized Access');
            echo json_encode($response);

        }
        


    }

    public function users_delete()
    {
    }

    public function api_call($input){

            $enquiryValue['name'] = $input['name'];
            $indiamartApiData = array();
            $enquiryValue['title'] = 'Requirement for '.$input['quantity'].' quantity '.$input['product'];
            $enquiryValue['email'] = $input['email'];
            $enquiryValue['phonenumber'] = $input['phonenumber'];
            $enquiryValue['name'] = $input['name'];
            $enquiryValue['address'] = $input['address'];
            $enquiryValue['city'] = $input['city'];
            $enquiryValue['state'] = $input['state'];
            $enquiryValue['company'] = $input['company'];
            $enquiryValue['status'] = $this->leads_model->get_status_id();
            $enquiryValue['source'] = $this->leads_model->get_others_source_id();
            $enquiryValue['description'] = $input['product'].$input['quantity'].$input['pincode'];
            $enquiryValue['fakeemailstatus'] = 1;
            $descriptionEnquiry = $this->leads_model->get_customfields_details('Description');
            $source = $this->leads_model->get_customfields_details('Source');
            $urgency = $this->leads_model->get_customfields_details('Urgency');

            $checkinCustomers = $this->leads_model->check_enquiry_on_clients($enquiryValue);
            if(empty($checkinCustomers)){
                $checkinLeads = $this->leads_model->check_enquiry_on_leads($enquiryValue);
                    if(empty($checkinLeads)){
                        $this->creatNewLeadenquiry($enquiryValue,$descriptionEnquiry,$input,$source,$urgency);
                    }
                    else{
                        //need to add enquiry with lead as rel_type 
                        $this->createNewEnquirywithExistingLead($enquiryValue,$descriptionEnquiry,$input,$checkinLeads,$source,$urgency);
                    }
            }
            else{
                // need to add enquiry with customer as rel_type and rel_id
                $this->createNewEnquirywithCustomer($enquiryValue,$descriptionEnquiry,$checkinCustomers,$source,$urgency,$checkinLeads);
            }
    }

    public function creatNewLeadenquiry($enquiryValue,$descriptionEnquiry,$input,$source,$urgency){

        $newleadData = $this->leads_model->add_enquiry_from_indiamart($enquiryValue);    
                    //add enquiry too 
                    // need customize this into one function for code-optimization
        $isenquiryExist = $this->leads_model->check_enquiry_on_proposals($enquiryValue);
        if(empty($isenquiryExist)){
            $newEnquiry = array('subject' => $enquiryValue['title'],
                                'rel_id' => $newleadData,
                                'rel_type' => 'lead',
                                'date' => date('Y-m-d H:i:s'),
                                'currency' => currencyINR,
                                'status' => enqOpenStatus,
                                'addedfrom' => defaultAddedFrom,
                                'country' => countryCode,
                                'proposal_to'=> !empty($enquiryValue['name']) ? $enquiryValue['name'] : '',
                                'address' => !empty($enquiryValue['address']) ? $enquiryValue['address'] : '',
                                'city' => !empty($enquiryValue['city']) ? $enquiryValue['city'] : '',
                                'state' => !empty($enquiryValue['state']) ? $enquiryValue['state'] : '',
                                'email' => !empty($enquiryValue['email']) ? $enquiryValue['email'] : '',
                                'phone' => !empty($enquiryValue['phonenumber']) ? $enquiryValue['phonenumber'] : '',
                                'is_buyleads' => 0
                               );
            $proposalId = $this->proposals_model->add($newEnquiry);
            $indiamartApiData=array();
            $indiamartApiDataId = $this->proposals_model->addIndiamartApiData($proposalId, $indiamartApiData);
                        // Adding description manually here by crm way
            if($enquiryValue['description'] != ''){
                /*This is to create custom field value*/
                createCustomFieldValue($proposalId,$descriptionEnquiry['id'],'proposal',$enquiryValue['description']);
            } 
            /*This is to create custom field value*/
            $sourcetype = 'Others';
            createCustomFieldValue($proposalId,$source['id'],'proposal',$sourcetype);
            /*This is to create custom field value*/
            createCustomFieldValue($proposalId,$urgency['id'],'proposal','8 hrs');

            $response = array('status'=>1, 'message'=> 'New Enquiry And New Lead Created '.$proposalId);
            echo json_encode($response);
      } else{
            $response = array('status' => 1, 'message' => 'Already enquiry added');
            echo json_encode($response);
      }

    }

    public function createNewEnquirywithCustomer($enquiryValue,$descriptionEnquiry,$checkinCustomers,$input,$source,$urgency){

        $isenquiryExist = $this->leads_model->check_enquiry_on_proposals($enquiryValue);
        if(empty($isenquiryExist)){

            $customerEnquiry = array('subject' => $enquiryValue['title'],
                                     'rel_id' => $checkinCustomers['userid'],
                                     'rel_type' => 'customer',
                                     'date' => date('Y-m-d H:i:s'),
                                     'currency' => currencyINR,
                                     'status' => enqOpenStatus,
                                     'addedfrom' => defaultAddedFrom,
                                     'country' => countryCode,
                                     'proposal_to'=> !empty($enquiryValue['name']) ? $enquiryValue['name'] : '',
                                     'address' => !empty($enquiryValue['address']) ? $enquiryValue['address'] : '',
                                     'city' => !empty($enquiryValue['city']) ? $enquiryValue['city'] : '',
                                     'state' => !empty($enquiryValue['state']) ? $enquiryValue['state'] : '',
                                     'email' => !empty($enquiryValue['email']) ? $enquiryValue['email'] : '',
                                     'phone' => !empty($enquiryValue['phonenumber']) ? $enquiryValue['phonenumber'] : '',
                                     'is_buyleads' => 0
                                    );
            $proposalId = $this->proposals_model->add($customerEnquiry);
            $indiamartApiData = array();
            $indiamartApiDataId = $this->proposals_model->addIndiamartApiData($proposalId, $indiamartApiData);
                        // Adding description manually here by crm way
                if($enquiryValue['description'] != ''){
                    /*This is to create custom field value*/
                    createCustomFieldValue($proposalId,$descriptionEnquiry['id'],'proposal',$enquiryValue['description']);
                }   
                /*This is to create custom field value*/

                $sourcetype = 'Others';
                createCustomFieldValue($proposalId,$source['id'],'proposal',$sourcetype);
                /*This is to create custom field value*/
                createCustomFieldValue($proposalId,$urgency['id'],'proposal','8 hrs');

         $response = array('status'=>1, 'message'=> 'Enquiry created with existing customer '.$proposalId);
         echo json_encode($response);
        } else{
                $response = array('status' => 1, 'message' => 'Already enquiry added');
                echo json_encode($response);
        }
    }

    public function createNewEnquirywithExistingLead($enquiryValue,$descriptionEnquiry,$input,$checkinLeads,$source,$urgency){
        
        $isenquiryExist = $this->leads_model->check_enquiry_on_proposals($enquiryValue);
        if(empty($isenquiryExist)){
                    $leadEnquiry = array('subject' => $enquiryValue['title'],
                                         'rel_id' => $checkinLeads['id'],
                                         'rel_type' => 'lead',
                                         'date' => date('Y-m-d H:i:s'),
                                         'currency' => currencyINR,
                                         'status' => enqOpenStatus,
                                         'addedfrom' => defaultAddedFrom,
                                         'country' => countryCode,      
                                         'proposal_to'=> !empty($enquiryValue['name']) ? $enquiryValue['name'] : '',
                                         'address' => !empty($enquiryValue['address']) ? $enquiryValue['address'] : '',
                                         'city' => !empty($enquiryValue['city']) ? $enquiryValue['city'] : '',
                                         'state' => !empty($enquiryValue['state']) ? $enquiryValue['state'] : '',
                                         'email' => !empty($enquiryValue['email']) ? $enquiryValue['email'] : '',
                                         'phone' => !empty($enquiryValue['phonenumber']) ? $enquiryValue['phonenumber'] : '',
                                         'is_buyleads' => 0 
                                         );
                    $proposalId = $this->proposals_model->add($leadEnquiry);  
                    $indiamartApiData = array(); 
                    $indiamartApiDataId = $this->proposals_model->addIndiamartApiData($proposalId, $indiamartApiData);
                        // Adding description manually here by crm way
                    if($enquiryValue['description'] != ''){
                        /*This is to create custom field value*/
                        createCustomFieldValue($proposalId,$descriptionEnquiry['id'],'proposal',$enquiryValue['description']);
                    }   
                    /*This is to create custom field value*/
                    $sourcetype = 'Others';
                    createCustomFieldValue($proposalId,$source['id'],'proposal',$sourcetype);
                    /*This is to create custom field value*/
                    createCustomFieldValue($proposalId,$urgency['id'],'proposal','8 hrs');

            $response = array('status'=>1, 'message'=> 'Enquiry created with existing lead '. $proposalId);
            echo json_encode($response);
        } else{
                $response = array('status' => 1, 'message' => 'Already enquiry added');
                echo json_encode($response);
          }
    }
   
}
            