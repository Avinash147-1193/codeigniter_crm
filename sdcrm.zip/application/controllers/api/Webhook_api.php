<?php
    require (APPPATH.'/libraries/REST_Controller.php');
    
    defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Webhook_api extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['orders_post']['limit'] = $this->config->item('apiRequestLimit'); // 500 requests per hour per user/key
        $this->methods['orders_get']['limit'] = $this->config->item('apiRequestLimit'); 
        $this->methods['orders_delete']['limit'] = $this->config->item('apiRequestLimit'); 
        $this->load->model('estimates_model');
        $this->load->model('invoices_model');
        $this->load->model('leads_model');
        $this->load->helper('estimates_helper');
    }

    public function orders_get()
    {
      $response = array('status'=>0, 'message'=> 'Unauthorized');
      echo json_encode($response);
    }

    public function orders_post()
    {
        $enquiryValue = array();
        $input = $this->post();
        $refernceNumber = !empty($input['ref_number']) ? $input['ref_number'] : '';
        //checking refnumber in db and get other details related to ref number
        $checkRefNumber = $this->estimates_model->check_ref_number($refernceNumber);
        if(empty($input['error'])){
            //get the order realted data using quote id
            $estimate = $this->estimates_model->get($checkRefNumber->crm_estimate_id);
            //get the invoice data 
            $invoice = $this->invoices_model->get($checkRefNumber->crm_invoice_id);

            $clientVat = isset($invoice->client->vat)? $invoice->client->vat : ''; 
            //here adding the gst in estimate to push the order.
            $estimate->vat = !empty($invoice->acceptance_gstin) ? $invoice->acceptance_gstin : $clientVat;
            if(!empty($checkRefNumber)){
                $this->db->trans_start();
                        //saving orderId in crm db
                    $updateOrderPivot = $this->estimates_model->store_orderid($estimate->id, $input['order_id']);
                        //saving orderId in reference table
                    $updateRefPivot = $this->estimates_model->update_reference_table($checkRefNumber->queue_reference_number, $input['order_id']);
                        //save the orderId in sales table
                    $status = 1;
                    $updateSalesAgentPivot = $this->estimates_model->update_salesagent_table($input['order_id'], $checkRefNumber->sales_agent_id,$status,$checkRefNumber->queue_reference_number);
                    logActivity('Order created in SD-STORE [EstimateId: ' . $estimate->id . ', orderId: ' .$input['order_id']. ']');
                        //saving orderid in invoice table
                    $updateInovice = $this->estimates_model->update_storeid_on_invoice($checkRefNumber->crm_invoice_id, $input['order_id']);
                        //convert them into customer if from leads 
                    $clientId = $this->convertCustomer($estimate, $invoice);
                        //send email to ops 
                    send_order_email($input['order_id'], $estimate, $checkRefNumber->crm_invoice_id, $checkRefNumber->sales_agent_id);
                        //product response
                    foreach($input['product_response'] as $key => $product){
                            //checking adhoc or sd-store product
                        $productResponse = !empty($product['crm_product_id']) ? $this->adhoc($product) : $this->sdStore($product); 
                            //checking if vendor is adhoc 
                        $vendorResponse = (!empty($product['crm_vendor_id']) && !empty($product['actual_vendor_product_data']['vendor_id'])) ? $this->adhocVendor($product) : '';
                    }
                //transaction check
                if($this->db->trans_status() === FALSE){
                    $this->db->trans_rollback();
                } else {
                    $this->db->trans_complete();
                    //push notification
                    $notifiedUsers = array();
                    $notification_data = array(
                                            'description' => 'Your Order got Placed at sd-store OD'.$input['order_id'],
                                            'touserid' => $checkRefNumber->sales_agent_id,
                                            'link' => 'orders/'.$input['order_id']);
                    if (add_notification($notification_data)) {
                        array_push($notifiedUsers, $checkRefNumber->sales_agent_id);
                    }
                    //send push notification
                    pusher_trigger_notification($notifiedUsers);
                    $orderStatusData = $this->getCustomFieldArray($checkRefNumber->crm_invoice_id,'Order Status');
                    //change the status in invoice
                    $value = 'Order placed on sd-store';
                    $orderStatus = $this->leads_model->update_custom_field($orderStatusData,$value,$checkRefNumber->crm_invoice_id);
                    $response = array('status'=> 1, 'message'=> 'success');
                    echo json_encode($response);
                } 
            } else {
                $response = array('status'=> 0, 'message'=> 'Unauthorized');
                echo json_encode($response);
            }
        } else {
            if(!empty($checkRefNumber)){
                $this->db->trans_complete();
                //updating order status
                $orderStatusData = $this->getCustomFieldArray($checkRefNumber->crm_invoice_id,'Order Status');
                $value = 'Order failed on sd-store';
                $orderStatus = $this->leads_model->update_custom_field($orderStatusData,$value,$checkRefNumber->crm_invoice_id);
                //push notification
                $notifiedUsers = array();
                $notification_data = array(
                                        'description' => 'Your Order got failed at sd-store. Refernce number: '.$checkRefNumber->queue_reference_number,
                                        'touserid' => $checkRefNumber->sales_agent_id,
                                        'link' => 'orders/'.$checkRefNumber->queue_reference_number);
                if (add_notification($notification_data)) {
                    array_push($notifiedUsers, $checkRefNumber->sales_agent_id);
                }
                //send push notification
                pusher_trigger_notification($notifiedUsers);
                //updating pivot table
                $status = 0;
                $updateSalesAgentPivot = $this->estimates_model->update_salesagent_table('', $checkRefNumber->sales_agent_id,$status,$checkRefNumber->queue_reference_number);
                //error
                $error = $input['error']; 
                //product error
                $product = $error['products'] ? implode(',',$error['products']) : '';
                //user error
                $user = $error['user'] ? implode(',', $error['user']) : '';
                //order error
                $order = $error['order'] ? implode(',', $error['order']) : '';
                //ref number 
                $refNumber = $checkRefNumber->queue_reference_number;
                //populating error log
                $errorLogMsg = 'Products issue -'. $product.'/ User issue '.$user.' /Order issue '.$order;
                //saving in db
                $updateError = $this->estimates_model->update_error($errorLogMsg, $refNumber, $product, $user, $order);
                //user track log
                logActivity('The Refernce Number Order Got Failed check in db with following id '. $updateError. 'Errormsg '. $errorLogMsg);
                //success response
                $response = array('status'=> 1, 'message'=> 'success');
                echo json_encode($response);

            } else {
                $response = array('status'=> 0, 'message'=> 'Unauthorized');
                echo json_encode($response);
            }
        }
        
    }

    public function adhocVendor($product){
        $crmVendorId = $product['crm_vendor_id'];
        $sdStoreVendorId = $product['actual_vendor_product_data']['vendor_id'];
        $sdStoreCompanyId = $product['actual_vendor_product_data']['company_id'];

        $adhocVendor = $this->estimates_model->insert_sdstore_vendor_crm($crmVendorId, $sdStoreVendorId, $sdStoreCompanyId);
        return $adhocVendor;

    }

    public function getCustomFieldArray($id,$name){

        $data= $this->leads_model->get_customfields_details($name);
        $resultArray = array('relid' => $id,
                             'fieldid' => $data['id'],
                             'fieldto' => $data['fieldto']
                            );
        return $resultArray;
    }

    public function adhoc($product){
            //adhoc products data(existing+new)
        $checkProductExists = $this->estimates_model->check_product_existsin_pivot($product['crm_product_id'],''); 

        if(!empty($checkProductExists)){
                //existing(need to update only child table)
                $storePivotData = $this->adhocProduct($product);
                $checkIfRelationExists = $this->estimates_model->check_store_adhoc_product($storePivotData);
                if(empty($checkIfRelationExists)){
                    $responseData = $this->estimates_model->store_adhoc_product($storePivotData); 
                } else {
                    $responseData = '';
                }
        } else {
                //new(need to update both master and child table)
                $itemName = $this->estimates_model->get_item_by_id($product['crm_product_id']);
                $masterPivotData = $product['simtech_product_data'];
                $sdTeamPivotData = $product['shakedeal_product_data'];
                $vendorPivotData = $product['actual_vendor_product_data'];
                $responseData = $this->estimates_model->store_master_child_vendor_adhoc_product($product,$masterPivotData, $sdTeamPivotData, $vendorPivotData, $itemName['description']); // need to log it in log file or txt file.         
        }
        //crm adhoc/exist vendor or sd-vendor 
        $vendorId = !empty($product['crm_vendor_id']) ? $product['crm_vendor_id'] : $product['actual_vendor_product_data']['company_id'];
        //if crm id found then crm vendor or sd-store
        $vendorType = empty($product['crm_vendor_id']) ? 1 : 0;
        //product mapping update is_pushed status
        $productMappingStatus = $this->estimates_model->update_product_mapping_status($product['crm_product_id'], $vendorId, $vendorType);

        $productUpdateStatus = $this->estimates_model->update_sd_store_status($product['crm_product_id']);
        $response = array('result' => $responseData, 'productStatus' => $productUpdateStatus);
        return $response;

    }

    public function sdStore($product){
        //sd-store products data
        $storePivotData = $this->sdStoreProduct($product);
        $checkIfRelationExists = $this->estimates_model->check_store_sdstore_product($storePivotData);
        //update the ids in sd-store pivot table 
        if(empty($checkIfRelationExists)){
            $responseData = $this->estimates_model->store_sdstore_product($storePivotData);
        } else {
            $responseData = '';
        }
        $productId = $storePivotData['sd_store_product_id'];
        $vendorId = empty($product['crm_vendor_id']) ? $storePivotData['vendor_id'] : $product['crm_vendor_id'];
        $vendorType = $storePivotData['vendor_type'];
        //update the product pushed status
        $productUpdateStatus = $this->estimates_model->update_product_mapping_status($productId, $vendorId, $vendorType);
        $response = array('result' => $responseData, 'productStatus' => $productUpdateStatus);
        return $response;
    }
    
    public function adhocProduct($product){
        $adhocPivotData = array(
                                'crm_product_id' => $product['crm_product_id'],
                                'sdstore_vendor_child_product_id' => $product['actual_vendor_product_data']['product_id'],
                                'vendor_id' => $product['actual_vendor_product_data']['company_id'],
                                'vendor_type' => empty($product['crm_vendor_id']) ? 1 : 0
                                ); //array to store in pivot table
        return $adhocPivotData;
    }

    public function sdStoreProduct($product)
    {
        $storePivotData = array('sd_store_product_id' => $product['shakedeal_product_data']['product_id'],
                                'sd_store_child_product_id' => $product['actual_vendor_product_data']['product_id'],
                                'vendor_id' => $product['actual_vendor_product_data']['company_id'],
                                'product_code' => $product['skucode'],
                                'vendor_type' => empty($product['crm_vendor_id']) ? 1 : 0
                                ); //array to store in pivot table
        return $storePivotData;

    }

    public function convertCustomer($estimate, $invoice){
        $customer = array('leadid' => $estimate->client->id,
                          'default_language' => '',
                          'firstname' => $estimate->client->name,
                          'lastname' =>'',
                          'email' => $estimate->client->email,
                          'company' => $estimate->client->company,
                          'vat' => !empty($estimate->vat) ? $estimate->vat : '',
                          'phonenumber' => $estimate->client->phonenumber,
                          'website' => $estimate->client->website,
                          'address' =>$estimate->billing_street,
                          'city' => $estimate->billing_city,
                          'state' => $estimate->billing_state,
                          'billing_street' => $estimate->billing_street,
                          'billing_city' => $estimate->billing_city,
                          'billing_state' => $estimate->billing_state, 
                          'billing_zip' => $estimate->billing_zip,
                          'billing_country' => 'IN',
                          'shipping_street' => $estimate->shipping_street,
                          'shipping_city' => $estimate->shipping_city,
                          'shipping_state' => $estimate->shipping_state, 
                          'shipping_zip' => $estimate->shipping_zip,
                          'country' => isset($estimate->client->country) ? $estimate->client->country : 'IN',
                          'zip' => $estimate->client->zip,
                          'original_lead_email' => $estimate->client->email,
                          'fakeusernameremembered' => '',
                          'fakepasswordremembered' => '',
                          'password' => 'test'
                        );
            $checkInCustomerQuery = "SELECT * FROM tblcontacts WHERE email='".$estimate->client->email."'";
            $checkInCustomerResult = $this->db->query($checkInCustomerQuery)->row_array();
            //convert customer from lead if user accept quote
            $clientId = empty($checkInCustomerResult) ? convert_to_customer($customer) : $checkInCustomerResult['userid'];
            $contactData = array(
                                 'userid' => $clientId,
                                 'is_primary' => 1,
                                 'firstname' => $estimate->client->name,
                                 'lastname' => '',
                                 'email' => $estimate->client->email,
                                 'phonenumber' => $estimate->client->phonenumber   
                                );
            //adding contact for customer
            empty($checkInCustomerResult) ? $this->estimates_model->add_contact($contactData) : '' ;
            //updating client_id in quote
            $this->estimates_model->update_clientid_quote($estimate->id,$clientId);
            //updating client_id in invoice 
            $this->estimates_model->update_clientid_invoice($invoice->id,$clientId); 

            return $clientId;

    }
   
}
            