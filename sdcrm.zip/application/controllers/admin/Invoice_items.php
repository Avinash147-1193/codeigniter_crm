<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Invoice_items extends Admin_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('invoice_items_model');
        $this->load->model('tasks_model');
        $this->load->model('estimates_model');
        $this->load->model('vendors_model');
        $this->load->helper('common_helper');
    }

    /* List all available items */
    public function index()
    {
        if (!has_permission('items', '', 'view')) {
            access_denied('Invoice Items');
        }

        $this->load->model('taxes_model');
        $data['taxes']        = $this->taxes_model->get();
        $data['items_groups'] = $this->invoice_items_model->get_groups();

        $this->load->model('currencies_model');
        $data['currencies'] = $this->currencies_model->get();

        $data['base_currency'] = $this->currencies_model->get_base_currency();
        $data['sd_store_vendors'] = array();
        $jsonArray = load_sd_store_vendors();
        $data['categories'] = $this->vendors_model->get_all_categories();
        foreach ($jsonArray as $key => $value) {
            $arrVendor = [];
            if($value['company'] != "" || $value['company'] != null){
                $arrVendor['vendorId'] = $value['company_id'];
                $arrVendor['companyName'] = $value['company'];
                $arrVendor['vendorType'] = 1;
                array_push($data['sd_store_vendors'], $arrVendor);
            }
        }

        $data['title'] = _l('invoice_items');
        $this->load->view('admin/invoice_items/manage', $data);
    }

    public function table(){
        if (!has_permission('items', '', 'view')) {
            ajax_access_denied();
        }
        $this->app->get_table_data('invoice_items');
    }
    /* Edit or update items / ajax request /*/
    public function manage()
    {
        if (has_permission('items', '', 'view')) {
            if ($this->input->post()) {
                $data = $this->input->post();
                $data['search_keyword'] = str_replace(' ', '',$this->input->post('description'));
                $data['description'] = $this->input->post('description');
                $data['description'] = return_allowed_charactres($data['description']);// Removes special chars

                $success = false;
                $message = '';
                if ($data['itemid'] == '') {
                    if (!has_permission('items', '', 'create')) {
                        header('HTTP/1.0 400 Bad error');
                        echo _l('access_denied');
                        die;
                    }

                    $checkItem = $this->invoice_items_model->get_product('',$this->input->post('description'));
                    if($checkItem != null){
                        $success = false;
                        $message = _l('invoice_item_already_exists', _l('invoice_item'));
                    }else{
                        $id      = $this->invoice_items_model->add($data);

                        //Newly added items
                        $sessData = $this->session->userdata('items');

                        if(!is_array($sessData)){
                            $sessData = array();
                        }
                        array_push($sessData, $id);

                        $this->session->set_userdata('items',$sessData);

                        if ($id) {
                            $success = true;
                            $message = _l('added_successfully', _l('invoice_item'));
                        }else{
                            $success = false;
                            $message = _l('invalid_transaction', _l('invoice_item'));
                        }

                        echo json_encode(array(
                            'success' => $success,
                            'message' => $message,
                            'item' => $this->invoice_items_model->get($id)
                        ));exit();
                    }
                } else {
                    if (!has_permission('items', '', 'edit')) {
                        header('HTTP/1.0 400 Bad error');
                        echo _l('access_denied');
                        die;
                    }
                    $success = $this->invoice_items_model->edit($data);
                    if ($success) {
                        $message = _l('updated_successfully', _l('invoice_item'));
                    }
                }
                echo json_encode(array(
                    'success' => $success,
                    'message' => $message
                ));exit();
            }
        }
    }

    public function getproductvendor(){

        $id = $_POST['id'];
        $productDetails = $this->invoice_items_model->get_product_vendors($id);
        $response = array();
        $vendorLogArray = array();
        foreach($productDetails as $product){
            if(!in_array($product['vendor_id'], $vendorLogArray)){
                $vendorData = $this->invoice_items_model->get_vendor_mapping_data($product['vendor_id']);
                if($vendorData['vendor_type'] == 0 && $vendorData['is_pushed'] == 0){
                    $vendorname = $this->invoice_items_model->get_vendor_name($product['vendor_id']);
                    array_push($vendorLogArray, $product['vendor_id']);
                }
                
                elseif($vendorData['vendor_type'] == 1){
                    $vendorname = $this->invoice_items_model->get_sd_store_vendor_name($product['vendor_id']);
                    array_push($vendorLogArray, $product['vendor_id']);
                }
                elseif($vendorData['vendor_type'] == 0 && $vendorData['is_pushed'] == 1){
                    $this->db->select('sdstore_company_id');
                    $this->db->from('tblcrmstore_vendor');
                    $this->db->where('crm_vendor_id',$product['vendor_id']);
                    $result = $this->db->get()->row_array();
                    array_push($vendorLogArray, $result['sdstore_company_id']);
                    $vendorname = $this->invoice_items_model->get_sd_store_vendor_name($result['sdstore_company_id']);
                }
                $response[] ='<tr><td>'.$vendorname['companyname'].'<td ><input style="width: 50%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;" type=text id=price'.$vendorname['id'].' value='.number_format($product['price'],2).' disabled><td><a  id=edit'.$vendorname['id'].' style="cursor:pointer" onclick="editproduct('.$product['product_id'].','.$vendorname['id'].')"> Edit<a id=update'.$vendorname['id'] .'     style="display:none;cursor:pointer" onclick="updateproduct('.$product['product_id'].','.$vendorname['id'].')"> update
                    ';
                
            }
            
        } 
                    
        echo json_encode($response);
    }


    public function addproductvendor(){

        $id = $_POST['id'];
        $productName = $this->invoice_items_model->get_product($id); 

        $response ='<tr><td style="margin-top:12px;">'.$productName['description'].'<td><input
        placeholder=SearchVendor  style="width: 100%;padding: 9px 10px;margin:
        8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px
        ;box-sizing: border-box;" list="vendors" name="browser" class="search_vendor" id="vendor">
        <input type="hidden" id="product_code" value="'.$productName['long_description'].'" > 
        <datalist id="vendors" class="vendor_list" style="overflow: scroll;">
        </datalist>
        <td><input type="text" style="width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;" id="price"><td><a style="margin-top:12px;" id="addVendorButton" data-original-prodid="'.$id.'" onclick="addnewvendor('.$id.')" class="btn btn-info">Add</tr>';
        echo json_encode($response);

    }

    public function datalist(){
        $datalist = array(); //to store vendors list

        $this->load->model('vendors_model');
        $vendors = $this->vendors_model->get_all_vendors()->result_array();
        $pushed_vendors = $this->vendors_model->get_all_pushed_vendors()->result_array();
        $data = array();
        $i = 1;

        foreach ($vendors as $key => $vendor) {
            $vendor_pushed = 0;
            foreach ($pushed_vendors as $keyTemp => $valueTemp) {
                if($valueTemp['crm_vendor_id'] == $vendor['id']){
                    $vendor_pushed = 1;
                }
            }
            if($vendor_pushed == 0){
                $categories = $this->vendors_model->get_all_categories($vendor['id']);
                $mandatoryFieldsCheck = $this->vendors_model->check_mandatory_fields($vendor['id']);
                $updateRequired = $mandatoryFieldsCheck == 1 ? ' (UpdateRequired)' :''; 
                $datalist[] = '<option data-value="'.$vendor["companyname"].'" value="'.$vendor["companyname"].' (CRM) " > '.$vendor["companyname"].' </option>';
            }
        }
        echo json_encode(array('datalist' => $datalist));
    }

    public function addmapping(){
        $vendorSearch = $_POST['vendor'];
        $productId = $_POST['id'];
        $product_code = $_POST['product_code'];
        $productPrice = $_POST['price'];
        $vendorName = array();
        if(strpos($vendorSearch, 'SD-Store') !== false){
            $vendorName = array();
            $jsonArray = load_sd_store_vendors();
            $vendorSearch = str_replace('(SD-Store)', '', $vendorSearch);
            foreach ($jsonArray as $key => $value) {
                if(trim($value['company']) == trim($vendorSearch)){
                    $vendorName['id'] = $value['company_id'];
                }
            }
            $vendorName['vendor_type'] = 1;
        } else{
            $vendorSearch = str_replace('(CRM)', '', $vendorSearch);
            $vendorName = $this->invoice_items_model->get_vendor($vendorSearch);
            $vendorName['vendor_type'] = 0;

        }
        
        $data = array('product_id' => $productId, 'vendor_id' => $vendorName['id'], 'price' => $productPrice, 'product_code' => $product_code , 'vendor_type' => $vendorName['vendor_type']);
        $checkMapping = $this->invoice_items_model->check_vendorproduct_mappping($data); //here checking if mapping already done or not
        //In future we will have to map it with category also
        if(empty($checkMapping)){
            $this->invoice_items_model->add_mapping($data);     
            $response = array('status'=> 1, 'message' => 'success');
            echo json_encode($response);
        }else{ 
            $response = array('status'=> 0, 'message' => 'Failure');
            echo json_encode($response);
        }
    }

    public function editproductvendor(){
        $editReqVendorId = $_POST['vendorid'];
        $editReqProductId = $_POST['id'];
        $updatePrice = $_POST['price'];
        $updatePrice = str_replace(',', '', $updatePrice);
        $updatearray = array('product_id' => $editReqProductId,'vendor_id' => $editReqVendorId);
        $result = $this->invoice_items_model->update_product_price($updatearray,$updatePrice);

        echo $result;
                    
        //echo json_encode($response);        
    }
    public function add_group()
    {
        if ($this->input->post() && has_permission('items', '', 'create')) {
            $this->invoice_items_model->add_group($this->input->post());
            set_alert('success', _l('added_successfully', _l('item_group')));
        }
    }

    public function update_group($id)
    {
        if ($this->input->post() && has_permission('items', '', 'edit')) {
            $this->invoice_items_model->edit_group($this->input->post(), $id);
            set_alert('success', _l('updated_successfully', _l('item_group')));
        }
    }

    public function delete_group($id)
    {
        if (has_permission('items', '', 'delete')) {
            if ($this->invoice_items_model->delete_group($id)) {
                set_alert('success', _l('deleted', _l('item_group')));
            }
        }
        redirect(admin_url('invoice_items?groups_modal=true'));
    }

    /* Delete item*/
    public function delete($id)
    {
        if (!has_permission('items', '', 'delete')) {
            access_denied('Invoice Items');
        }

        if (!$id) {
            redirect(admin_url('invoice_items'));
        }

        $response = $this->invoice_items_model->delete($id);
        if (is_array($response)) {
            if(isset($response['referenced'])){
                set_alert('warning', _l('is_referenced', _l('invoice_item_lowercase')));
            }
        } elseif ($response == true) {
            set_alert('success', _l('deleted', _l('invoice_item')));
        } else {
            set_alert('warning', _l('problem_deleting', _l('invoice_item_lowercase')));
        }
        redirect(admin_url('invoice_items'));
    }

    public function delete_item_via_ajax($id, $rel_id = '', $rel_type = ''){
        if ($this->input->is_ajax_request()) {
            $newlyAddedItem = $this->session->userdata('items');
            $item = $this->invoice_items_model->get($id);
            if(isset($item->itemid)){
                $isNewItem = 0;            

                if(!empty($newlyAddedItem)){
                    $key = array_search($id, $newlyAddedItem);
                    if($key !== false){
                        //Newly Added Items Only
                        $this->db->where('id', $id);
                        $this->db->delete('tblitems');

                        unset($newlyAddedItem[$key]);
                        $this->session->set_userdata('items',$newlyAddedItem);
                        $isNewItem = 1;
                    }
                }
                if($isNewItem == 0 && !empty($rel_id)){
                    //Deletion from tblitems_in
                    $response = $this->invoice_items_model->delete($id, $rel_id, $rel_type);
                }
                $response = array("status" => 200, "message" => "Success");
            }else{
                $response = array("status" => 200, "message" => "Success");
            }
            echo json_encode($response);
        }
    }

    public function search(){
        if($this->input->post() && $this->input->is_ajax_request()){
            echo json_encode($this->invoice_items_model->search($this->input->post('q')));
        }
    }

    /* Get item by id / ajax */
    public function get_item_by_id($id)
    {   
        if (strpos($id, 'SD') !== false) {
            return false;
        }
        if ($this->input->is_ajax_request()) {
            $item                   = $this->invoice_items_model->get($id);
            $item->long_description = $item->long_description;
            $item->model_number = nl2br($item->model_number);
            $item->vendor = 'No Vendor Selected';
            $item->brand = nl2br($item->brand);
            $item->vendor = 'No Vendors Selected';
            $item->rate = '';
            $item->hsn_code = $item->hsn_code;
            $item->custom_fields_html = render_custom_fields('items',$id,array(),array('items_pr'=>true));
            $item->custom_fields = array();
            $item->allVendors = array();

            $cf = get_custom_fields('items');

            foreach($cf as $custom_field) {
                $val = get_custom_field_value($id,$custom_field['id'],'items_pr');
                if($custom_field['type'] == 'textarea') {
                    $val = clear_textarea_breaks($val);
                }
                $custom_field['value'] = $val;
                $item->custom_fields[] = $custom_field;
            }
            
            // Getting venodr list for showing in dropdown in quotation page
            // echo $this->uri->segment(3);die;  
            // Its getting ajax function as 3rd uri segment thats why removed condition
//            if($this->uri->segment(3) == "estimate"){
                $vendorList = get_vendor_list_by_item_id($id);
                foreach($vendorList as $vendor){
                    array_push($item->allVendors,  $vendor);
                    // $item->allVendors = $vendor;
                }
//            }
            echo json_encode($item);
        }
    }
    
    public function get_item_price($vendor_id, $item_id){

         $query = "SELECT TVP.*, TVP.price as price FROM tblvendorproductmapping TVP WHERE TVP.product_id=(SELECT id FROM tblitems WHERE tblitems.long_description=(SELECT long_description FROM tblitems_in WHERE tblitems_in.id= '".$item_id."')) AND TVP.vendor_id = '".$vendor_id."'";
        $query = $this->db->query($query);

        if (is_numeric($item_id) && is_numeric($item_id)) {
            $result = $query->row_array();
        }else{
            $result = array();
        }
        if(!empty($result)){
            $this->estimates_model->update_vendor($result['vendor_id'], $result['product_id'],$result['is_mapping_from_sdstore'], $result['price'], $result['product_code']); //update the default vendor for the products
            echo json_encode($result);
        }else{
            $query = "SELECT TVP.*, TVP.price as price FROM tblvendorproductmapping TVP WHERE TVP.product_code=(SELECT long_description as productCode FROM tblitems_in WHERE tblitems_in.id= '".$item_id."'
            ) AND TVP.vendor_id = '".$vendor_id."'";
            $query = $this->db->query($query);
            $result = $query->row_array();
            
            if(empty($result)){
                $sql = 'SELECT long_description FROM tblitems_in WHERE id = "'.$item_id.'" ';
                $query = $this->db->query($sql);
                $result = $query->row_array();
                $product_code = $result['long_description'];
                
                $sql = 'SELECT * FROM tblvendorproductmapping WHERE product_code = "'.$product_code.'" ';
                $query = $this->db->query($sql);
                $result = $query->row_array();
                $product_id = $result['product_id'];
                
                $this->load->helper('constant_helper');
                $this->load->helper('estimates_helper');
                $elasticUrl =  elasticUrl;
                $url = $elasticUrl."_search?q=code:".$product_code;
                $tempResult = elasticSearchAPICurl($url,'GET');
                $tempJsonArray = json_decode($tempResult,true);
                if(!empty($tempJsonArray['hits']['hits'])){
                    $products = $tempJsonArray['hits']['hits'];
                    $shakedealVendors = $this->config->item('sd_vendors');
                    foreach($products as $product){
                      if(!in_array($product['_source']['companyid'], $shakedealVendors) && $product['_source']['companyid'] == $vendor_id){ 
                            $vendorArray['price']  = round($product['_source']['transferprice']);
                            $vendorArray['vendor_id']  = $product['_source']['companyid'];
                            $vendorArray['product_code']  = $product_code;
                            $vendorArray['is_default_vendor']  = 1;
                            $vendorArray['product_id']  = $product_id;
                            $vendorArray['product_type']  = 1;
                            $vendorArray['vendor_type']  = 1;
                            $vendorArray['is_mapping_from_sdstore']  = 1;
                            $vendorArray['is_pushed']  = 2;
                      }
                      
                    }
                }
                $addnewvendor = $this->estimates_model->store_sdstore_vendor($vendorArray);
                if(!empty($addnewvendor)){
                    $query = "SELECT TVP.*, TVP.price as price FROM tblvendorproductmapping TVP WHERE TVP.product_code=(SELECT long_description as productCode FROM tblitems_in WHERE tblitems_in.id= '".$item_id."') AND TVP.vendor_id = '".$vendor_id."'";
                    $query = $this->db->query($query);
                    $result = $query->row_array();
                }
            }
            
            $this->estimates_model->update_vendor($result['vendor_id'], $result['product_id'],$result['is_mapping_from_sdstore'], $result['price'], $result['product_code']); //update the default vendor for teh products
        
            echo json_encode($result);
        }
    }

    public function updateDefaultVendor(){
        $vendorId = $_POST['vendorId'];
        $productId = $_POST['productId'];
        $proposalId = $_POST['proposalId'];
        $mappingFrom = $_POST['mappingFrom'];
        $rate = $_POST['rate'];
        $productCode = $_POST['productCode'];
        $response = $this->estimates_model->update_vendor($vendorId, $productId, $mappingFrom, $rate, $productCode); //update the default vendor for the products
        if(!empty($response)) {
            $resultStatus = array('status' => 1, 'message' => 'success');
        } else {
            $resultStatus = array('status' => 0, 'message' => 'error');
        }
        
        $sql = "SELECT product_code, vendor_type FROM tblvendorproductmapping WHERE product_id = '".$_POST['productId']."' AND vendor_id = '".$vendorId."' ";
        $query = $this->db->query($sql);
        $result = $query->row();
        $product_code = !empty($result->product_code) ? $result->product_code : '';
        
        if(!empty($product_code) && $result->vendor_type == 0){
            $sql = "UPDATE tblitems_in a INNER JOIN tblvendor b SET a.vendor = b.companyname WHERE a.long_description = '".$product_code."' AND rel_id = '".$_POST['proposalId']."' AND b.id = '".$_POST['vendorId']."' ";
            $query = $this->db->query($sql);
        }
        if(!empty($product_code) && $result->vendor_type == 1){
            $url = apiUrl."vendors/";
            $url = $url.$_POST['vendorId'];
            $result = commanCurl($url,'GET');
            $jsonArray = json_decode($result['result'],true);
            $companyname = $jsonArray['company'];
            
            $sql = "UPDATE tblitems_in SET vendor = '".$companyname."' WHERE long_description = '".$product_code."' AND rel_id = '".$_POST['proposalId']."' ";
            $query = $this->db->query($sql);
        }
        

        echo json_encode($resultStatus);

    }

    /*****Importing All ITEMS VIA .CSV FILE*****/
    public function bulk_upload(){
      $filename = time().'-'.$_FILES["File_Upload"]["name"];
      $temp_url = './uploads/items/'.$filename;
      if (move_uploaded_file($_FILES["File_Upload"]["tmp_name"], $temp_url)) {
          $handle = fopen($temp_url,"r");
          $i = 1;

          $taxes = array('1' => '0%',
                       '2' => '5.00%',
                       '3' => '12.00%',
                       '4' => '18.00%',
                       '5' => '28.00%',
                       '12'=> '20.00%');
          while (($row = fgetcsv($handle, 10000, ",")) != FALSE){
            if($i > 1){
                $tax = $row[4]?str_replace(' ', '', rtrim($row[4],"%")):'0%';
                $floatTax = number_format((int)$tax,2);
                $taxWithPercent = $floatTax.'%';

                $data = array(
                            "description" => preg_replace('/[^A-Za-z0-9\-]/','',$row[2]),
                            "search_keyword" => str_replace(' ', '',$row[2]),
                            "long_description" => preg_replace('/[^A-Za-z0-9\-]/', '',$row[1]),
                            "rate" => $row[3],
                            "vendor" => $row[5],
                            "tax" => array_search($taxWithPercent,$taxes));
                if (!has_permission('items', '', 'create')) {
                    header('HTTP/1.0 400 Bad error');
                    echo _l('access_denied');
                    die;
                }
                //check product is exist or not
                $checkProductExistorNot = $this->invoice_items_model->check_item($data['search_keyword']);
                //echo "<pre>"; print_r($checkProductExistorNot);
                if(empty($checkProductExistorNot)){
                    $id = $this->invoice_items_model->add($data);

                    $success = false;
                    $message = '';
                    if ($id) {
                        $vendor = $this->invoice_items_model->get_vendor($row[5]);
                        if($vendor){
                            $data = array('product_id' => $id, 'vendor_id' => $vendor['id'], 'price' => $row[3]);

                            $checkMapping = $this->invoice_items_model->check_vendorproduct_mappping($data); //here checking if mapping already done or not
                            if($checkMapping == null){
                                $this->invoice_items_model->add_mapping($data);
                            }
                        }
                        $success = true;
                        $message = _l('added_successfully', _l('invoice_item'));
                    }
                }
                //$response = 1;
            }
            $i++;
          }
          fclose($handle); 

          $response = array('status'=> 1, 'message' => 'Success');
          // Delete uploaded file
          unlink($temp_url);
      } else {
          $response = array('status'=> 0, 'message' => 'Failure');
      }
      echo json_encode($response);
    }

    public function getVendorDataBysearch(){
        $vendorSearch = $_POST['vendorSearch'];
        $vendorSearch = str_replace('(CRM)', '', $vendorSearch);
        $vendorSearch = str_replace('(UpdateRequired)', '', $vendorSearch);
        $vendorSearch = trim($vendorSearch);
        $vendorId = $this->invoice_items_model->get_vendor($vendorSearch);
        echo json_encode($vendorId);
    }

    public function verifySku(){
        $sku = $_POST['sku'];
        $sql = "SELECT long_description FROM tblitems WHERE long_description = '".$sku."' ";
        $query = $this->db->query($sql);
        $result = $query->row_array();

        if(empty($result)){
            $response = array('status'=> 1, 'message' => 'Success');
        } else {
            $response = array('status'=> 0, 'message' => 'Failure');
        }
        
        echo json_encode($response);
        
    }

    public function checklastupdatedvendor(){
        $r['id'] = $_POST['id'];
        $last_updated_price_date_query = "SELECT price, updated_at FROM tblvendorproductmapping WHERE product_id=".$r['id']." ORDER BY updated_at DESC";
        $last_updated_data = $this->db->query($last_updated_price_date_query)->row_array();
        $least_price = "SELECT MIN(price) as price, vendor_id FROM tblvendorproductmapping WHERE product_id=".$r['id'];
        $least_price_data = $this->db->query($least_price)->row_array();
        $last_updated_data['price'] = number_format((float)$last_updated_data['price'], 2, '.', '');
        $least_price_data['price'] = number_format((float)$least_price_data['price'], 2, '.', '');
        if(!empty($least_price_data) && !empty($last_updated_data)){
            $response = array('last_updated_data'=>$last_updated_data , 'least_price_data' => $least_price_data );
        } else {
            $response = array('status'=> 0, 'message' => 'Failure');
        }
        
        echo json_encode($response);    
    }
}
