<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Proposals extends Admin_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('proposals_model');
        $this->load->model('currencies_model');
        $this->load->library('session');
        $this->load->model('estimates_model');
        $this->load->model('clients_model');
        $this->load->model('tasks_model');
        $this->load->model('leads_model');
        $this->load->model('invoice_items_model');
        $this->load->helper('general_helper');
        $this->load->helper('constant_helper');
        $this->load->helper('common_helper');
        $this->load->model('vendors_model');
    }

    public function dataCleanUpVendor(){
        $this->db->trans_begin();
        try{
            $sql = "SELECT id, companyname FROM `tblvendor` WHERE companyname != '' GROUP BY companyname HAVING COUNT(*) > 1";
            $duplicateVendors = $this->db->query($sql)->result_array();

            if(count($duplicateVendors) > 0){
                $companyname = array_column($duplicateVendors, 'companyname');
                $id = array_column($duplicateVendors, 'id');

                $mainarr = array_combine($companyname, $id);

                $sql = "SELECT id, companyname FROM `tblvendor`";
                $allVendors = $this->db->query($sql)->result_array();

                //VendorCategories to map with a distinct venodr_id
                $sql = "SELECT tblvendorcategory.id, tblvendor.companyname FROM `tblvendorcategory` LEFT JOIN tblvendor ON tblvendor.id = tblvendorcategory.vendor_id";
                $allVendorCategories = $this->db->query($sql)->result_array();      

                foreach ($allVendorCategories as $key => $vendorCategory) {
                    if(array_key_exists($vendorCategory['companyname'], $mainarr)){
                        $sql = "UPDATE `tblvendorcategory` SET vendor_id = ".$mainarr[$vendorCategory['companyname']]." WHERE id=".$vendorCategory['id']."";

                        $this->db->query($sql);
                    }
                }

                //VendorProductMapping to map with a distinct venodr_id
                $sql = "SELECT tblvendorproductmapping.id, tblvendor.companyname FROM `tblvendorproductmapping` LEFT JOIN tblvendor ON tblvendor.id = tblvendorproductmapping.vendor_id";
                $allVendorProductMappings = $this->db->query($sql)->result_array();      

                foreach ($allVendorProductMappings as $key => $VendorProductMapping) {
                    if(array_key_exists($VendorProductMapping['companyname'], $mainarr)){
                        $sql = "UPDATE `tblvendorproductmapping` SET vendor_id = ".$mainarr[$VendorProductMapping['companyname']]." WHERE id=".$VendorProductMapping['id']."";

                        $this->db->query($sql);
                    }
                }

                //tblitemsin to map with a distinct venodr_id
                $sql = "SELECT tblitems_in.id, tblvendor.companyname FROM `tblitems_in` LEFT JOIN tblvendor ON tblvendor.id = tblitems_in.vendor WHERE tblitems_in.vendor REGEXP '^[0-9]+$'";
                $alltblitemsin = $this->db->query($sql)->result_array();

                foreach ($alltblitemsin as $key => $tblitemsin) {
                    if(array_key_exists($tblitemsin['companyname'], $mainarr)){
                        $sql = "UPDATE `tblitems_in` SET vendor = ".$mainarr[$tblitemsin['companyname']]." WHERE id=".$tblitemsin['id']."";

                        $this->db->query($sql);
                    }
                }

                $sql = 'DELETE FROM tblvendor WHERE id not in ('.implode(',', $id).') AND companyname in ("' . implode('", "', $companyname) . '")';
                $this->db->query($sql);
            }else{
                echo "Already Cleaned";
            }

            $this->db->trans_commit();
        }catch(Exception $e){
            $this->db->trans_rollback();
        }
    }

    public function dataCleanUpItem(){
        $this->db->trans_begin();
        try{
            $sql = "DELETE FROM tblitems WHERE description = '' OR id in (1119, 1121, 1088, 1097, 1086, 1095, 307, 1616, 1148, 1143, 1146, 1147, 1149, 1150, 1151, 1153, 1155, 1156, 2475)";
            $this->db->query($sql);

            $sql = "SELECT id, description, search_keyword FROM `tblitems` WHERE description != '' GROUP BY description HAVING COUNT(*) > 1";
            $duplicateItems = $this->db->query($sql)->result_array();

            if(count($duplicateItems) > 0){
                $itemname = array_column($duplicateItems, 'search_keyword');
                $id = array_column($duplicateItems, 'id');

                $mainarr = array_combine($itemname, $id);

                //tblsourcingitems to map with a distinct item_id
                $sql = "SELECT tblsourcingitems.id, tblsourcingitems.item_id, tblitems.description, tblitems.search_keyword FROM `tblsourcingitems` LEFT JOIN tblitems ON tblitems.id = tblsourcingitems.item_id";
                $alltblsourcingitems = $this->db->query($sql)->result_array();

                foreach ($alltblsourcingitems as $key => $sourcingitem) {
                    if(array_key_exists($sourcingitem['search_keyword'], $mainarr)){
                        $sql = "UPDATE `tblsourcingitems` SET item_id = ".$mainarr[$sourcingitem['search_keyword']]." WHERE id=".$sourcingitem['id']."";
                        $this->db->query($sql);
                    }
                }

                //tblsourcing_item_alternatives to map with a distinct item_id
                $sql = "SELECT tblsourcing_item_alternatives.id, tblitems.search_keyword, tblsourcing_item_alternatives.alternate_item_id, tblitems.description FROM `tblsourcing_item_alternatives` LEFT JOIN tblitems ON tblitems.id = tblsourcing_item_alternatives.alternate_item_id";
                $alltblsourcing_item_alternatives = $this->db->query($sql)->result_array();      

                foreach ($alltblsourcing_item_alternatives as $key => $sourcingitemalternate) {
                    if(array_key_exists($sourcingitemalternate['search_keyword'], $mainarr)){
                        $sql = "UPDATE `tblsourcing_item_alternatives` SET alternate_item_id = ".$mainarr[$sourcingitemalternate['search_keyword']]." WHERE id=".$sourcingitemalternate['id']."";
                        $this->db->query($sql);
                    }
                }


                //tblproposalitems to map with a distinct item_id
                $sql = "SELECT tblproposalitems.id, tblproposalitems.item_id, tblitems.description, tblitems.search_keyword FROM `tblproposalitems` LEFT JOIN tblitems ON tblitems.id = tblproposalitems.item_id";
                $alltblproposalitems = $this->db->query($sql)->result_array();      

                foreach ($alltblproposalitems as $key => $proposalitem) {
                    if(array_key_exists($proposalitem['search_keyword'], $mainarr)){
                        $sql = "UPDATE `tblproposalitems` SET item_id = ".$mainarr[$proposalitem['search_keyword']]." WHERE id=".$proposalitem['id']."";
                        $this->db->query($sql);
                    }
                }


                //tblitemstax to map with a distinct item_id
                $sql = "SELECT tblitemstax.id, tblitemstax.itemid, tblitems.description, tblitems.search_keyword FROM `tblitemstax` LEFT JOIN tblitems ON tblitems.id = tblitemstax.itemid";
                $alltblitemstax = $this->db->query($sql)->result_array();      

                foreach ($alltblitemstax as $key => $itemtax) {
                    if(array_key_exists($itemtax['search_keyword'], $mainarr)){
                        $sql = "UPDATE `tblitemstax` SET itemid = ".$mainarr[$itemtax['search_keyword']]." WHERE id=".$itemtax['id']."";
                        $this->db->query($sql);
                    }
                }

                foreach ($duplicateItems as $key => $dItem) {
                    $sql = 'DELETE FROM tblitems WHERE id != '.$dItem['id'].' AND search_keyword = "'.$dItem['search_keyword'].'"';
                    $this->db->query($sql);
                }
            }else{
                echo "Already Cleaned";
            }

            $this->db->trans_commit();
        }catch(Exception $e){
            $this->db->trans_rollback();
        }
    }

    public function dataCleanUpCustomer() {
        $this->db->trans_begin();
        try{
            $sql = "SELECT userid, company FROM `tblclients` WHERE company != '' GROUP BY company HAVING COUNT(*) > 1";
            $duplicateClients = $this->db->query($sql)->result_array();
            
            if(count($duplicateClients) > 0){
                $companyname = array_column($duplicateClients, 'company');
                $id = array_column($duplicateClients, 'userid');

                $mainarr = array_combine($companyname, $id);

                //tblproposals to map with a distinct client_id
                $sql = "SELECT  tblproposals.id, tblproposals.rel_type, tblproposals.rel_id as clientid, tblclients.company as company FROM tblproposals LEFT JOIN tblcustomfieldsvalues AS ctable_0 ON tblproposals.id = ctable_0.relid AND ctable_0.fieldto = 'proposal' AND ctable_0.fieldid = 3 LEFT JOIN tblcustomfieldsvalues AS ctable_1 ON tblproposals.id = ctable_1.relid AND ctable_1.fieldto = 'proposal' AND ctable_1.fieldid = 6 LEFT JOIN  tblclients ON tblclients.userid = tblproposals.rel_id WHERE rel_type = 'customer'";
                $allproposals = $this->db->query($sql)->result_array();

                foreach ($allproposals as $key => $proposal) {
                    if(array_key_exists($proposal['company'], $mainarr)){
                        $sql = "UPDATE `tblproposals` SET rel_id = ".$mainarr[$proposal['company']]." WHERE id=".$proposal['id']." AND rel_type='customer'";
                        $this->db->query($sql);
                    }
                }

                //tblestimates to map with a distinct client_id
                $sql = "SELECT tblestimates.id, tblestimates.clientid, tblclients.company FROM `tblestimates` LEFT JOIN tblclients ON tblclients.userid = tblestimates.clientid";
                $allquotes = $this->db->query($sql)->result_array();

                foreach ($allquotes as $key => $quote) {
                    if(array_key_exists($quote['company'], $mainarr)){
                        $sql = "UPDATE `tblestimates` SET clientid = ".$mainarr[$quote['company']]." WHERE id=".$quote['id']."";
                        $this->db->query($sql);
                    }
                }

                //tblinvoices to map with a distinct client_id
                $sql = "SELECT tblinvoices.id, tblinvoices.clientid, tblclients.company FROM `tblinvoices` LEFT JOIN tblclients ON tblclients.userid = tblinvoices.clientid";

                $allinvoices = $this->db->query($sql)->result_array();

                foreach ($allinvoices as $key => $invoice) {
                    if(array_key_exists($invoice['company'], $mainarr)){
                        $sql = "UPDATE `tblinvoices` SET clientid = ".$mainarr[$invoice['company']]." WHERE id=".$invoice['id']."";
                        $this->db->query($sql);
                    }
                }

                //tblstafftasks to map with a distinct client_id
                $sql = "SELECT tblstafftasks.id, tblstafftasks.rel_id as clientid, tblclients.company FROM tblstafftasks LEFT JOIN tblclients ON tblclients.userid = tblstafftasks.rel_id WHERE ( status IN (1, 4, 3, 2, 5)) AND rel_type='customer'";

                $alltasks = $this->db->query($sql)->result_array();

                foreach ($alltasks as $key => $task) {
                    if(array_key_exists($task['company'], $mainarr)){
                        $sql = "UPDATE `tblstafftasks` SET rel_id = ".$mainarr[$task['company']]." WHERE id=".$task['id']." AND rel_type='customer'";
                        $this->db->query($sql);
                    }
                }

                $sql = 'DELETE FROM tblclients WHERE userid not in ('.implode(',', $id).') AND company in ("' . implode('", "', $companyname) . '")';
                $this->db->query($sql);
            }else{
                echo "Already Cleaned";
            }
            $this->db->trans_commit();
        }catch(Exception $e){
            $this->db->trans_rollback();
        }
    }

    public function dataCleanUpCustomerViaEmail() {
        $this->db->trans_begin();
        try{
            //Contacts
            $sql = "DELETE FROM tblcontacts WHERE userid in(22, 23, 24, 25, 26, 28, 29, 30, 31, 37, 145)";
            $this->db->query($sql);

            //Clients
            $sql = "DELETE FROM tblclients WHERE userid in(22, 23, 24, 25, 26, 28, 29, 30, 31, 37, 145)";
            $this->db->query($sql);

            //Estimates
            $sql = "DELETE FROM tblestimates WHERE clientid in(22, 23, 24, 25, 26, 28, 29, 30, 31, 37, 145)";
            $this->db->query($sql);

            //Invoices
            $sql = "DELETE FROM tblinvoices WHERE clientid in(22, 23, 24, 25, 26, 28, 29, 30, 31, 37, 145)";
            $this->db->query($sql);

            //Proposals
            $sql = "SELECT tblproposals.id, tblproposals.rel_type, tblproposals.rel_id as clientid, tblclients.company as company FROM tblproposals LEFT JOIN tblcustomfieldsvalues AS ctable_0 ON tblproposals.id = ctable_0.relid AND ctable_0.fieldto = 'proposal' AND ctable_0.fieldid = 3 LEFT JOIN tblcustomfieldsvalues AS ctable_1 ON tblproposals.id = ctable_1.relid AND ctable_1.fieldto = 'proposal' AND ctable_1.fieldid = 6 LEFT JOIN  tblclients ON tblclients.userid = tblproposals.rel_id WHERE rel_type = 'customer' AND tblclients.userid in(22, 23, 24, 25, 26, 28, 29, 30, 31, 37, 145)";
            $allproposals = $this->db->query($sql)->result_array();

            foreach ($allproposals as $key => $proposal) {
                $sql = "DELETE FROM tblproposals WHERE id = ".$proposal['id']."";
            }

            $sql = "SELECT tblclients.userid, tblclients.company, tblcontacts.email FROM `tblclients` LEFT JOIN tblcontacts on tblcontacts.userid = tblclients.userid WHERE tblclients.userid in(22, 23, 24, 25, 26, 28, 29, 30, 31, 37, 145)";
            $testClients = $this->db->query($sql)->result_array();

            if(count($testClients) === 0){
                echo "Already Cleaned Customers";
            }

            $this->db->trans_commit();
        }catch(Exception $e){
            $this->db->trans_rollback();
        }
    }

    public function index($proposal_id = '')
    {
        $this->list_proposals($proposal_id);
    }

    public function list_proposals($proposal_id = '')
    {
        close_setup_menu();

        if (!has_permission('proposals', '', 'view') && !has_permission('proposals', '', 'view_own') && get_option('allow_staff_view_proposals_assigned') == 0) {
            access_denied('proposals');
        }

        $isPipeline = $this->session->userdata('proposals_pipeline') == 'true';

        if ($isPipeline && !$this->input->get('status')) {
            $data['title']           = _l('proposals_pipeline');
            $data['bodyclass']       = 'proposals-pipeline';
            $data['switch_pipeline'] = false;
            // Direct access
            if (is_numeric($proposal_id)) {
                $data['proposalid'] = $proposal_id;
            } else {
                $data['proposalid'] = $this->session->flashdata('proposalid');
            }
            $this->load->view('admin/proposals/pipeline/manage', $data);
        } else {

            // Pipeline was initiated but user click from home page and need to show table only to filter
            if ($this->input->get('status') && $isPipeline) {
                $this->pipeline(0, true);
            }

            $data['proposal_id'] = $proposal_id;
            $data['switch_pipeline']       = true;
            $data['title']                 = _l('proposals');
            $data['statuses']              = $this->proposals_model->get_statuses();
            $data['proposals_sale_agents'] = $this->proposals_model->get_sale_agents();
            $data['years']                 = $this->proposals_model->get_proposals_years();
            $data['user_id']               = $this->session->userdata('staff_user_id');
            if($this->session->userdata('staff_user_id') != 1){
                $this->load->view('admin/proposals/proposal-all', $data);
            }else{
                $this->load->view('admin/proposals/manage', $data);
            }
        }
    }

    public function table()
    {
        if (!has_permission('proposals', '', 'view')
            && !has_permission('proposals', '', 'view_own')
            && get_option('allow_staff_view_proposals_assigned') == 0) {
            ajax_access_denied();
        }
        $this->app->get_table_data('proposals');
    }

    public function getcustomizedtable(){
        
        $this->app->get_table_data('customizedproposals');
    }
    public function proposal_relations($rel_id, $rel_type)
    {
        $this->app->get_table_data('proposals_relations', array(
            'rel_id' => $rel_id,
            'rel_type' => $rel_type,
        ));
    }

    public function delete_attachment($id)
    {
        $file = $this->misc_model->get_file($id);
        if ($file->staffid == get_staff_user_id() || is_admin()) {
            echo $this->proposals_model->delete_attachment($id);
        } else {
            ajax_access_denied();
        }
    }

    public function sync_data()
    {
        if (has_permission('proposals', '', 'create') || has_permission('proposals', '', 'edit')) {
            $has_permission_view = has_permission('proposals', '', 'view');

            $this->db->where('rel_id', $this->input->post('rel_id'));
            $this->db->where('rel_type', $this->input->post('rel_type'));

            if (!$has_permission_view) {
                $this->db->where('addedfrom', get_staff_user_id());
            }

            $address = trim($this->input->post('address'));
            $address = nl2br($address);
            $this->db->update('tblproposals', array(
                'phone' => $this->input->post('phone'),
                'zip' => $this->input->post('zip'),
                'country' => $this->input->post('country'),
                'state' => $this->input->post('state'),
                'address' => $address,
                'city' => $this->input->post('city'),
            ));

            if ($this->db->affected_rows() > 0) {
                echo json_encode(array(
                    'message' => _l('all_data_synced_successfully'),
                ));
            } else {
                echo json_encode(array(
                    'message' => _l('sync_proposals_up_to_date'),
                ));
            }
        }
    }

    public function viewvendors(){
        $this->load->view('admin/vendor_product_mapping/viewvendor_popup');
    }

    public function proposal($id = '')
    {
        $itemIds = $this->session->userdata('items');
        if ($this->input->post()) {

            $proposal_data = $this->input->post();
            
            if(!empty($proposal_data['newitems'])){
                foreach ($proposal_data['newitems'] as $key => $value) {
                    $productName = delete_all_between('(Stock', ')', $value['description']);
                    $productName = delete_all_between('(MOQ', ')', $productName);
                    $proposal_data['newitems'][$key]['description'] = $productName;  
                }
            }

            if($this->input->post('save_and_send')){
                /*This to add the estimate on open status*/
                $proposal_data['status'] = 3;
                if(!empty($id)){
                    $data = $this->input->post();
                    $quoteId = $this->createQuote($data,$id);
                }    
            }
            if($this->input->post('saveandtask')){
                /*This to create a task and items into it*/
                $proposal_data['status'] = 5;
                if($id){
                    unset($proposal_data['saveandtask']);
                    $data = $this->input->post();
                    $taskId = $this->createTask($data);
                }
            }
            if(!$this->input->post('saveandtask') && !$this->input->post('save_and_send')){
                /*save as draft*/
                $proposal_data['status'] = 6;
                $data = $this->input->post();
                $quoteItems = array();
                $quoteItems = $this->getQuoteItems($data);//get the added items
                foreach($quoteItems as $quoteItem){
                    $checkItemIsAdhoc = $this->estimates_model->check_is_adhoc($quoteItem['long_description']);
                    empty($checkItemIsAdhoc) ? $this->updateTax($quoteItem) : '';
                    if(!empty($quoteItem['product_id']) && !empty($quoteItem['vendor_id'])){
                        /* Item from store */
                        $data = array('product_id' => $quoteItem['product_id'],'vendor_id' => $quoteItem['vendor_id'],'proposal_id' => $id,'product_name' => $quoteItem['description'],'is_from_store' => 1);
                        /*add the item into tblcustomorder_proposal_rel pivot this is store product*/
                        $this->proposals_model->insert_customorder_proposal_data($data);
                    }else{
                        /*Item from crm, Here we are ignoring already sourced product from crm*/
                        $sessionItems = $this->session->userdata('items');
                        $productName = str_replace(' ', '',$quoteItem['description']);
                        $itemId = $this->invoice_items_model->get_product_by_name($productName);
                        if(!empty($itemId)){
                            if($sessionItems != null){
                                foreach($sessionItems as $key => $newitem){
                                    if($newitem == $itemId['id']){
                                        $data = array('proposal_id' => $id,'product_name' => $quoteItem['description'],'is_from_store' => 0,'item_id' => $itemId['id']);
                                        $this->proposals_model->insert_customorder_proposal_data($data);
                                    }
                                }
                            }
                            /*Unsetting session after inserting to customorder_proposal
                            $this->session->unset_userdata('items');*/
                        }
                    }
                }
            }
            //added to remove file upload control
            unset($proposal_data['File_Upload']);
            unset($proposal_data['product_id']);
            unset($proposal_data['vendor_id']);
            unset($proposal_data['store_tax_id']);
            //added to remove file upload control

            /* This code id for if lead is with empty email we are updating here*/
            $checkLeadEmailIsnotEmpty = $this->proposals_model->check_email_is_not_empty_forlead($proposal_data['rel_id']);
            $data = $this->input->post();
            if(empty($checkLeadEmailIsnotEmpty['email']) && $data['rel_type'] == 'lead'){
                $this->proposals_model->lead_email($data['rel_id'],$data['email']);
            }
            /*end*/

            if ($id == '') {
                /* if (!has_permission('proposals', '', 'create')) {
                     access_denied('proposals');
                }*/
                unset($proposal_data['saveandtask']);

                $id = $this->proposals_model->add($proposal_data);

                if($this->input->post('saveandtask')){
                    /*This to create a task and items into it*/
                    $data = $this->input->post();
                    $data['proposal_id'] = $id;
                    $taskId = $this->createTask($data);
                }
                
                if($this->input->post('save_and_send')){
                    $data = $this->input->post();
                    $quoteId = $this->createQuote($data,$id);
                }

                if(!$this->input->post('saveandtask') && !$this->input->post('save_and_send')){
                /*save as draft*/
                $proposal_data['status'] = 6;
                $data = $this->input->post();
                $quoteItems = array();
                $quoteItems = $this->getQuoteItems($data);//get the added items

                foreach($quoteItems as $quoteItem){
                    $quoteItem['is_newly_created'] == 'new' ? $this->updateTax($quoteItem) : '';
                    
                    if(!empty($quoteItem['product_id']) && !empty($quoteItem['vendor_id'])){
                        /* Item from store */
                        $data = array('product_id' => $quoteItem['product_id'],'vendor_id' => $quoteItem['vendor_id'],'proposal_id' => $id,'product_name' => $quoteItem['description'],'is_from_store' => 1);
                        /*add the item into tblcustomorder_proposal_rel pivot this is store product*/
                        $this->proposals_model->insert_customorder_proposal_data($data);
                    }else{
                        /*Item from crm, Here we are ignoring already sourced product from crm*/
                        $sessionItems = $this->session->userdata('items');
                        $productName = str_replace(' ', '',$quoteItem['description']);
                        $itemId = $this->invoice_items_model->get_product_by_name($productName);
                        if(!empty($itemId)){
                            if($sessionItems != null){
                                foreach($sessionItems as $key => $newitem){
                                    if($newitem == $itemId['id']){
                                        $data = array('proposal_id' => $id,'product_name' => $quoteItem['description'],'is_from_store' => 0,'item_id' => $itemId['id']);
                                        $this->proposals_model->insert_customorder_proposal_data($data);
                                    }
                                }
                            }
                            /*Unsetting session after inserting to customorder_proposal
                            $this->session->unset_userdata('items');*/
                        }
                    }
                }
            }

                /**** [SC-121] Manual enquiry assigning to staff ****/
                $this->proposals_model->assignenquiry($id,$this->input->post('assigned'));

                if ($id) {
                    set_alert('success', _l('added_successfully', _l('proposal')));
                    if ($this->set_proposal_pipeline_autoload($id)) {
                        redirect(admin_url('proposals'));
                    } else {
                        redirect(admin_url('proposals/list_proposals/' . $id));
                    }
                }
            } else {
                /*if (!has_permission('proposals', '', 'edit')) {
                    access_denied('proposals');
                }*/
                
                $success = $this->proposals_model->update($proposal_data, $id);
                if ($success) {
                    set_alert('success', _l('updated_successfully', _l('proposal')));
                }
                if ($this->set_proposal_pipeline_autoload($id)) {
                    redirect(admin_url('proposals'));
                } else {
                    redirect(admin_url('proposals/list_proposals/' . $id));
                }
            }
        }
        if ($id == '') {
            $title = _l('add_new', _l('proposal_lowercase'));
        } else {
            $data['proposal'] = $this->proposals_model->get($id);
            if (!$data['proposal']) {
                blank_page(_l('proposal_not_found'));
            }

            $data['estimate']    = $data['proposal'];
            $data['is_proposal'] = true;
            $title               = _l('edit', _l('proposal_lowercase'));


            $disable = 0;
            $this->db->select('item_id');
            $this->db->from('tblproposalitems');
            $this->db->where('proposal_id', $id);
            $proposalItem = $this->db->get()->num_rows();

            if($proposalItem > 0){
                $disable = 1;
            }
            $data['disable'] = $disable;
        }
        $this->load->model('taxes_model');
        $data['taxes'] = $this->taxes_model->get();
        $this->load->model('invoice_items_model');
        $data['ajaxItems'] = false;
        //There is a limit for items..if the item is more than 200 then it will go for ajax call, so to avoid that functionality the below code is commented.
        // if (total_rows('tblitems') <= ajax_on_total_items()) {
            $data['items']        = $this->invoice_items_model->get_grouped();
        // } else {
            // $data['items'] = array();
            // $data['ajaxItems'] = true;
        // }
        $data['items_groups'] = $this->invoice_items_model->get_groups();

        $data['statuses']   = $this->proposals_model->get_statuses();
        $userId = $this->session->userdata('staff_user_id');
        $staff = $this->staff_model->get('', 1);
        if($userId == 1 || $userId == 9){
            $data['staff'] = $staff;
        }else{
            $tempArray = array();
            foreach ($staff as $key => $value) {
                if($value['staffid'] == $userId){
                    $tempArray[] = $value;
                }
            }
            $data['staff'] = $tempArray;
        }

        $data['currencies'] = $this->currencies_model->get();
        $data['base_currency'] = $this->currencies_model->get_base_currency();
        $data['title']      = $title;
        $data['user_id'] = $userId;
        $data['categories'] = $this->vendors_model->get_all_categories();
        $data['vendors'] = $this->proposals_model->get_all_vendors();
        $data['sd_store_vendors'] = [];
        $jsonArray = $this->getSdStoreVendor();
        foreach ($jsonArray as $key => $value) {
            $arrVendor = [];
            if($value['company'] != "" && $value['company'] != null){
                $arrVendor['vendorId'] = $value['company_id'];
                $arrVendor['companyName'] = $value['company'];
                $arrVendor['vendorLabel'] = 'SD-Store';
                $arrVendor['vendorType'] = 1;
                array_push($data['sd_store_vendors'], $arrVendor);
            }
        }

        if($this->session->userdata('items') != null){
            $this->session->unset_userdata('items');
        }
        $this->load->view('admin/proposals/proposal', $data);
    }

    public function updateTax($value) {
        $taxId = getSdStoreTaxId($value['taxname']);
        $this->estimates_model->updateTax($taxId, $value['long_description']);
    }

    public function getQuoteItems($data){
        $quoteItems = array();
        if(isset($data['newitems']) && isset($data['items'])){
            /*merging old items and newitems*/
            $quoteItems = array_merge($data['newitems'],$data['items']);
        }

        if(isset($data['items']) && !isset($data['newitems'])){
            /*pushing the old items*/
            foreach($data['items'] as $item){
                array_push($quoteItems,$item);
            }
        }
        if(isset($data['newitems']) && !isset($data['items'])){
            /*pushing new items*/
            foreach($data['newitems'] as $newitem){
                array_push($quoteItems,$newitem);
            }
        }
        if(isset($data['alt_item'])){  
            /*pushing alternate items*/
            foreach($data['alt_item'] as $key=>$altitems){
                if($key > 0 && count($altitems) > 0){
                    foreach ($altitems as $key => $altitem) {
                        array_push($quoteItems,$altitems[$key]);
                    }
                }
            }        
            //Change Item Status
            changeItemStatus($quoteItems, $data['item_check'], 'proposal', $data['rel_id']);
        }
        return $quoteItems;
    }

    public function createQuote($data,$id){
        if(!empty($data['newitems'] )){
            foreach ($data['newitems'] as $key => $value) {
                if(!empty($value['description'])){
                    $productName = delete_all_between('(Stock', ')', $value['description']);
                    $productName = delete_all_between('(MOQ', ')', $productName);
                    $data['newitems'][$key]['description'] = $productName;
                    $value['is_newly_created'] == 'new' ? $this->updateTax($value) : '';
                }
            } 
        }
        $nextEstimateNumber = $this->estimates_model->next_estimate_number();
        $quoteItems = array();
        $quoteItems = $this->getQuoteItems($data);
        $quoteItems = unsetInactiveItems($quoteItems);

        $itemIds = $this->session->userdata('items');
        /*this code for ignoring newly added item 
        if(!empty($itemIds)){
            foreach($itemIds as $item){
              $itemName = $this->proposals_model->get_item($item);
                foreach($quoteItems as $key => $quoteItem){
                    if($quoteItem['description'] == $itemName['description']){
                        unset($quoteItems[$key]);
                    }
                }    
            }    
        }*/

        $userId = $this->session->userdata('staff_user_id');
        $estimateData = array('clientid' => $data['rel_id'],
                              'billing_street'=> $data['address'],
                              'billing_city' => $data['city'],
                              'billing_state' => $data['state'],
                              'billing_zip' => $data['zip'],
                              'billing_country' => 102,
                              'show_shipping_on_estimate' => 'on',
                              'date' => $data['date'],
                              'number' => $nextEstimateNumber['value'], 
                              'currency' => 1,
                              'sale_agent' => $userId,
                              'status' => 1, //need to change this status
                              'reference_no' => $id,
                              'show_quantity_as' => 1,
                              'newitems' => $quoteItems,
                              'subtotal' => $data['subtotal'],
                              'total' => $data['total'],
                              'total_tax' => $data['total'] - $data['subtotal'],
                              'is_from_leads' => $data['rel_type'] == 'lead' ? 1 : 0
                            );
        $estimateCheck = $this->estimates_model->check_estimate_exist($id);
        /*multiple quote for single enquiry so commented the if condition*/
        //if(empty($estimateCheck)){
            $estimateId = $this->estimates_model->add($estimateData);
            $email = $this->leads_model->get_customfields_details('email');
            $gstin = $this->leads_model->get_customfield_gstin('gstin','estimate');
            $leadGstin = $this->leads_model->get_customfield_gstin('gstin','leads');
            if($data['rel_type'] == 'customer') {
                $gstinValue = $this->leads_model->get_gst($data['email']);
                $gst = !empty($gstinValue) ? $gstinValue->vat : '';
            }

            if($data['rel_type'] == 'lead') {
                $leadGst = $this->proposals_model->lead_gst($data['rel_id'],$leadGstin['id'],'leads');
                $gst = !empty($leadGst) ? $leadGst->value : '';
            }
            
            /*This is to create custom field value of email in quote*/
            createCustomFieldValue($estimateId,$gstin['id'],'estimate',$gst);
            createCustomFieldValue($estimateId,$email['id'],'estimate',$data['email']);
            /*end*/
            if($data['rel_type'] == 'lead'){
                $this->leads_model->update_email($data['rel_id'],$data['email']);    
            }
            logActivity('Propsal and Lead Email updated:'.$id.',Email:'.$data['email']);
            if(isset($data['items'])){
                if(count($data['items']) > 0){
                    foreach ($data['items'] as $key => $item) {
                        //Getting itemid from tblitems
                        $this->db->select('id');
                        $this->db->from('tblitems');
                        $this->db->where('description',$item['description']);
                        $itemRow = $this->db->get()->row_array();

                        $this->db->where('item_id', $itemRow['id']);
                        $this->db->from('tblsourcingitems');
                        $sourcingTaskData = $this->db->get()->row_array();
                        if(!empty($sourcingTaskData)){
                            $taskId = $sourcingTaskData['task_id'];
                        }
                    }
                }
            }
            /*Here we are adding the product_id and vendor_id into customorder_rel products from sdstore*/
            foreach($quoteItems as $quoteItem){
                $checkItemIsAdhoc = $this->estimates_model->check_is_adhoc($quoteItem['long_description']);
                empty($checkItemIsAdhoc) ? $this->updateTax($quoteItem) : '';    
                if(!empty($quoteItem['product_id']) && !empty($quoteItem['vendor_id'])){
                    $data = array('product_id' => $quoteItem['product_id'],'vendor_id' => $quoteItem['vendor_id'],'estimate_id' => $estimateId,'product_name' => $quoteItem['description']);
                    $this->proposals_model->insert_customorder_data($data);
                }else{
                    $checkInPivot = $this->proposals_model->check_sdstore_product($quoteItem['product_id'], $id); 
                   if(!empty($checkInPivot)){
                    $data = array('product_id' => $quoteItem['product_id'],'vendor_id' => 98,'estimate_id' => $estimateId,'product_name' => $quoteItem['description']);
                    $this->proposals_model->insert_customorder_data($data);
                   }
                }
            }
            /*end*/

            /*This block for Draft case Items*/
            $draftItems = array();
            $draftItems = $this->proposals_model->get_data_from_draft($id); //Get draft items
            if(!empty($draftItems)){
                foreach($draftItems as $draftItem){
                    if(!empty($draftItem['product_id']) && !empty($draftItem['vendor_id'])){
                        $data = array('product_id' => $draftItem['product_id'],
                                      'vendor_id' => $draftItem['vendor_id'],
                                      'estimate_id' => $estimateId,
                                      'product_name' => $draftItem['product_name']
                                     );
                        $this->proposals_model->insert_customorder_data($data);
                    }
                }
            }

            if(isset($taskId)){
                $this->db->select('product_id, vendor_id,product_name');
                $this->db->where('task_id',$taskId);
                $this->db->from('tblcustomorder_task_rel');
                $result = $this->db->get()->result_array(); //need to remove from db
                foreach($result as $res){
                    $data = array('product_id' => $res['product_id'],'vendor_id' => $res['vendor_id'],'estimate_id' => $estimateId,'product_name' => $res['product_name']);
                    $this->proposals_model->insert_customorder_data($data);
                }
            }
       /*}else{
            if(!empty($id)){
                $data = array('rel_id' => $estimateCheck['id']);
                $this->estimates_model->remove_items($data);
                $this->estimates_model->update($estimateData, $estimateCheck['id']);
            }
        }*/
    }

    public function createTask($data){
        // $data = $this->input->post();
        if(isset($data['proposal_id'])){
            $relId = $data['proposal_id'];
        }else{
            $relId = $this->uri->segment(4);
        }
        $taskData = array('billable' => 'on',
                          'name' => $data['subject'],
                          'hourly_rate' => 0,
                          'milestone' => '',
                          'startdate' => date('Y-m-d'),
                          'duedate' => date('Y-m-d', strtotime("+2 days")),
                          'priority' => 4,
                          'status' => 1,
                          'repeat_every' => '', 
                          'repeat_every_custom' => 1,
                          'repeat_type_custom' => 'day',
                          'recurring_ends_on' => '',
                          'rel_type' => 'proposal',
                          'rel_id' => $relId,
                          'tags' => '',
                          'description' => $data['custom_fields']['proposal'][1]
                         );

        $taskId = $this->tasks_model->add($taskData);
        $assignee = $this->invoice_items_model->get_assignee();

        //Getting new CRM items from tblcustomorder_proposal_rel table which was added while save as draft
        $this->db->select('tblcustomorder_proposal_rel.item_id');
        $this->db->join('tblitems_in','tblitems_in.description=tblcustomorder_proposal_rel.product_name','left');
        $this->db->where('tblcustomorder_proposal_rel.proposal_id', $relId);
        $this->db->where('tblcustomorder_proposal_rel.is_from_store', '0');
        $draftItems = $this->db->get('tblcustomorder_proposal_rel')->result_array();

        $crmDraftItemArray = array();
        foreach ($draftItems as $key => $draftItem) {
            array_push($crmDraftItemArray, $draftItem['item_id']);
        }

        /*adding the sdproducts in pivot table*/
        if(isset($data['newitems'])){
            foreach($data['newitems'] as $quoteItem){
                if(!empty($quoteItem['product_id']) && !empty($quoteItem['vendor_id'])){
                    $data = array('product_id' => $quoteItem['product_id'],'vendor_id' => $quoteItem['vendor_id'],'task_id' => $taskId,'product_name' => $quoteItem['description']);
                    $this->proposals_model->insert_customer_data_task($data);
                }
            }
        }
        /*end*/

        //Getting new items from tblproposalitems table which was added while save as draft
        $this->db->select('item_id');
        $this->db->where('proposal_id', $relId);
        $newlyAddedItems = $this->db->get('tblproposalitems')->result_array();

        //Getting new items from session
        $sessionItems = $this->session->userdata('items');
        if($sessionItems == null && !isset($sessionItems)){
            $sessionItems = array();
        }

        $newlyAddedItemsArray = array();
        foreach($newlyAddedItems as $newlyAddedItem){
            array_push($newlyAddedItemsArray, $newlyAddedItem['item_id']);
        }

        $newlyAddedItemsArray = array_unique(array_merge($newlyAddedItemsArray,$crmDraftItemArray));
        //Merging the result arrays
        $finalNewlyAddedItems = array_unique(array_merge($newlyAddedItemsArray, $sessionItems));

        //Storing the values into tblsourcingitems table
        if(!empty($finalNewlyAddedItems)){
            foreach($finalNewlyAddedItems as $key => $item){
                $this->proposals_model->add_items_into_task($item,$taskId);
            }
            $this->session->unset_userdata('items');    
        }
        return $taskId;exit;
    }

    public function manage($id = '')
    {
         close_setup_menu();


        if (!has_permission('proposals', '', 'view') && !has_permission('proposals', '', 'view_own') && get_option('allow_staff_view_proposals_assigned') == 0) {
            access_denied('proposals');
        }

        $isPipeline = $this->session->userdata('proposals_pipeline') == 'true';

        if ($isPipeline && !$this->input->get('status')) {
            $data['title']           = _l('proposals_pipeline');
            $data['bodyclass']       = 'proposals-pipeline';
            $data['switch_pipeline'] = false;
            // Direct access
            if (is_numeric($proposal_id)) {
                $data['proposalid'] = $proposal_id;
            } else {
                $data['proposalid'] = $this->session->flashdata('proposalid');
            }

            $this->load->view('admin/proposals/pipeline/manage', $data);
        } else {

            // Pipeline was initiated but user click from home page and need to show table only to filter
            if ($this->input->get('status') && $isPipeline) {
                $this->pipeline(0, true);
            }

            $data['proposal_id'] = (!empty($proposal_id)) ? $proposal_id : '' ;
            $data['switch_pipeline']       = true;
            $data['title']                 = _l('proposals');
            $data['statuses']              = $this->proposals_model->get_statuses();
            $data['proposals_sale_agents'] = $this->proposals_model->get_sale_agents();
            $data['years']                 = $this->proposals_model->get_proposals_years();
            $data['user_id']               = $this->session->userdata('staff_user_id');
            $this->load->view('admin/proposals/proposal-all', $data);
        }
    }

    public function assignenquiry(){
        $id = $_POST['id'];
        $userId = $this->session->userdata('staff_user_id');
        $result = $this->proposals_model->assignenquiry($id,$userId);
        if($result){
            $this->session->set_flashdata('enquiryAssignValue','enquiryAssignSuccessMessage');
            $response = array('status' => 1, 'message'=>'success');
            echo json_encode($response);
        }else{
            $response = array('status'=>0, 'message'=>'Failure');
            echo json_encode($response);
        }
    }


    /******Ajax calling for fetching the enquiries******/
    public function getEnquiryAvailable(){
        $searching_for = $_GET['searching_for'];
        if($searching_for == "my_enquiries"){
            //My Enquiries
            $table_data = array(
                _l('proposal') . ' #',
                _l('proposal_subject'),
                _l('From'),
                _l('Date'),
                _l('assigned_at'),
                _l('proposal_date_created'),
                _l('proposal_status'),
                _l('task_action'),
                _l('phone'),
                _l('is_buyleads')
            );
        }else{
            //Available Enquiries
             $table_data = array(
                _l('proposal') . ' #',
                _l('proposal_subject'),
                _l('From'),
                _l('Date'),
                _l('proposal_date_created'),
                _l('proposal_status'),
                _l('phone'),
                _l('Action'),
                _l('is_buyleads'),
              );
        }

        $custom_fields = get_custom_fields('proposal',array('show_on_table'=>1));
        foreach($custom_fields as $field){
          array_push($table_data,$field['name']);
        }

        $table_data = do_action('proposals_table_columns',$table_data);
        return json_encode(render_datatable($table_data,'proposals'));
    }

    public function get_template()
    {
        $name = $this->input->get('name');
        echo $this->load->view('admin/proposals/templates/' . $name, array(), true);
    }

    public function send_expiry_reminder($id)
    {
        $canView = $this->user_can_view_proposal($id);
        if (!$canView) {
            access_denied('proposals');
        } else {
            if (!has_permission('proposals', '', 'view') && !has_permission('proposals', '', 'view_own') && $canView == false) {
                access_denied('proposals');
            }
        }

        $success = $this->proposals_model->send_expiry_reminder($id);
        if ($success) {
            set_alert('success', _l('sent_expiry_reminder_success'));
        } else {
            set_alert('danger', _l('sent_expiry_reminder_fail'));
        }
        if ($this->set_proposal_pipeline_autoload($id)) {
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            redirect(admin_url('proposals/list_proposals/' . $id));
        }
    }

    public function clear_acceptance_info($id)
    {
        if (is_admin()) {
            $this->db->where('id', $id);
            $this->db->update('tblproposals', get_acceptance_info_array(true));
        }

        redirect(admin_url('proposals/list_proposals/'.$id));
    }

    public function pdf($id)
    {
        $canView = $this->user_can_view_proposal($id);
        if (!$canView) {
            access_denied('proposals');
        } else {
            if (!has_permission('proposals', '', 'view') && !has_permission('proposals', '', 'view_own') && $canView == false) {
                access_denied('proposals');
            }
        }

        if (!$id) {
            redirect(admin_url('proposals'));
        }
        $proposal = $this->proposals_model->get($id);

        try {
            $pdf      = proposal_pdf($proposal);
        } catch (Exception $e) {
            $message = $e->getMessage();
            echo $message;
            if (strpos($message, 'Unable to get the size of the image') !== false) {
                show_pdf_unable_to_get_image_size_error();
            }
            die;
        }

        $type     = 'D';
        if ($this->input->get('print')) {
            $type = 'I';
        }

        $proposal_number = format_proposal_number($id);
    
        $pdf->Output($proposal_number . '.pdf', $type);
    }

    public function get_proposal_data_ajax($id, $to_return = false)
    {
        if (!has_permission('proposals', '', 'view') && !has_permission('proposals', '', 'view_own') && get_option('allow_staff_view_proposals_assigned') == 0) {
            echo _l('access_denied');
            die;
        }

        $proposal = $this->proposals_model->get($id, array(), true);

        if (!$proposal) {
            echo _l('proposal_not_found');
            die;
        } 
        // else {
        //     if (!$this->user_can_view_proposal($id)) {
        //         echo _l('proposal_not_found');
        //         die;
        //     }
        //}

        $template_name         = 'proposal-send-to-customer';
        $data['template_name'] = $template_name;
        $companyName = $this->proposals_model->get_additional_data($proposal);
        $descriptionEnquiry = $this->leads_model->get_customfields_details('Description');
        $proposalDescription = $this->proposals_model->get_proposal_description($id, $descriptionEnquiry['id']);
        $additionalData = array('companyName' => isset($companyName->company) ? $companyName->company : 'N/A','description' => isset($proposalDescription->value) ? $proposalDescription->value : 'No Description' );
        $this->db->where('slug', $template_name);
        $this->db->where('language', 'english');
        $template_result = $this->db->get('tblemailtemplates')->row();

        $data['template_system_name'] = $template_result->name;
        $data['template_id'] = $template_result->emailtemplateid;

        $data['template_disabled'] = false;
        if (total_rows('tblemailtemplates', array('slug'=>$data['template_name'], 'active'=>0)) > 0) {
            $data['template_disabled'] = true;
        }

        define('EMAIL_TEMPLATE_PROPOSAL_ID_HELP', $proposal->id);

        $data['template']      = get_email_template_for_sending($template_name, $proposal->email);
        $proposal_merge_fields  = get_available_merge_fields();
        $_proposal_merge_fields = array();
        array_push($_proposal_merge_fields, array(
            array(
                'name' => 'Items Table',
                'key' => '{proposal_items}',
            ),
        ));
        foreach ($proposal_merge_fields as $key => $val) {
            foreach ($val as $type => $f) {
                if ($type == 'proposals') {
                    foreach ($f as $available) {
                        foreach ($available['available'] as $av) {
                            if ($av == 'proposals') {
                                array_push($_proposal_merge_fields, $f);
                                break;
                            }
                        }
                        break;
                    }
                } elseif ($type == 'other') {
                    array_push($_proposal_merge_fields, $f);
                }
            }
        }
        $data['proposal_statuses']     = $this->proposals_model->get_statuses();
        $data['members']               = $this->staff_model->get('', 1);
        $data['proposal_merge_fields'] = $_proposal_merge_fields;
        $data['proposal']              = $proposal;
        $data['additional_data']       = $additionalData;
  
        if ($to_return == false) {
            $this->load->view('admin/proposals/proposals_preview_template', $data);
        } else {
            return $this->load->view('admin/proposals/proposals_preview_template', $data, true);
        }
    }

    public function convert_to_estimate($id)
    {
        if (!has_permission('estimates', '', 'create')) {
            access_denied('estimates');
        }
        if ($this->input->post()) {
            $this->load->model('estimates_model');
            $estimate_id = $this->estimates_model->add($this->input->post());
            if ($estimate_id) {
                set_alert('success', _l('proposal_converted_to_estimate_success'));
                $this->db->where('id', $id);
                $this->db->update('tblproposals', array(
                    'estimate_id' => $estimate_id,
                    'status' => 3,
                ));
                logActivity('Proposal Converted to Estimate [EstimateID: ' . $estimate_id . ', ProposalID: ' . $id . ']');

                do_action('proposal_converted_to_estimate', array('proposal_id'=>$id, 'estimate_id'=>$estimate_id));

                redirect(admin_url('estimates/estimate/' . $estimate_id));
            } else {
                set_alert('danger', _l('proposal_converted_to_estimate_fail'));
            }
            if ($this->set_proposal_pipeline_autoload($id)) {
                redirect(admin_url('proposals'));
            } else {
                redirect(admin_url('proposals/list_proposals/' . $id));
            }
        }
    }

    public function convert_to_invoice($id)
    {
        if (!has_permission('invoices', '', 'create')) {
            access_denied('invoices');
        }
        if ($this->input->post()) {
            $this->load->model('invoices_model');
            $invoice_id = $this->invoices_model->add($this->input->post());
            if ($invoice_id) {
                set_alert('success', _l('proposal_converted_to_invoice_success'));
                $this->db->where('id', $id);
                $this->db->update('tblproposals', array(
                    'invoice_id' => $invoice_id,
                    'status' => 3,
                ));
                logActivity('Proposal Converted to Invoice [InvoiceID: ' . $invoice_id . ', ProposalID: ' . $id . ']');
                do_action('proposal_converted_to_invoice', array('proposal_id'=>$id, 'invoice_id'=>$invoice_id));
                redirect(admin_url('invoices/invoice/' . $invoice_id));
            } else {
                set_alert('danger', _l('proposal_converted_to_invoice_fail'));
            }
            if ($this->set_proposal_pipeline_autoload($id)) {
                redirect(admin_url('proposals'));
            } else {
                redirect(admin_url('proposals/list_proposals/' . $id));
            }
        }
    }

    public function get_invoice_convert_data($id)
    {
        $this->load->model('payment_modes_model');
        $data['payment_modes'] = $this->payment_modes_model->get('', array(
            'expenses_only !=' => 1,
        ));
        $this->load->model('taxes_model');
        $data['taxes']      = $this->taxes_model->get();
        $data['currencies'] = $this->currencies_model->get();
        $data['base_currency'] = $this->currencies_model->get_base_currency();
        $this->load->model('invoice_items_model');
        $data['ajaxItems'] = false;
        if (total_rows('tblitems') <= ajax_on_total_items()) {
            $data['items']        = $this->invoice_items_model->get_grouped();
        } else {
            $data['items'] = array();
            $data['ajaxItems'] = true;
        }
        $data['items_groups'] = $this->invoice_items_model->get_groups();

        $data['staff']          = $this->staff_model->get('', 1);
        $data['proposal']       = $this->proposals_model->get($id);
        $data['billable_tasks'] = array();
        $data['add_items']      = $this->_parse_items($data['proposal']);

        if ($data['proposal']->rel_type == 'lead') {
            $this->db->where('leadid', $data['proposal']->rel_id);
            $data['customer_id'] = $this->db->get('tblclients')->row()->userid;
        } else {
            $data['customer_id'] = $data['proposal']->rel_id;
        }
        $this->load->view('admin/proposals/invoice_convert_template', $data);
    }

    public function get_estimate_convert_data($id)
    {
        $this->load->model('taxes_model');
        $data['taxes']      = $this->taxes_model->get();
        $data['currencies'] = $this->currencies_model->get();
        $data['base_currency'] = $this->currencies_model->get_base_currency();
        $this->load->model('invoice_items_model');
        $data['ajaxItems'] = false;
        if (total_rows('tblitems') <= ajax_on_total_items()) {
            $data['items']        = $this->invoice_items_model->get_grouped();
        } else {
            $data['items'] = array();
            $data['ajaxItems'] = true;
        }
        $data['items_groups'] = $this->invoice_items_model->get_groups();

        $data['staff']     = $this->staff_model->get('', 1);
        $data['proposal']  = $this->proposals_model->get($id);
        $data['add_items'] = $this->_parse_items($data['proposal']);

        $this->load->model('estimates_model');
        $data['estimate_statuses']  = $this->estimates_model->get_statuses();
        if ($data['proposal']->rel_type == 'lead') {
            $this->db->where('leadid', $data['proposal']->rel_id);
            $data['customer_id'] = $this->db->get('tblclients')->row()->userid;
        } else {
            $data['customer_id'] = $data['proposal']->rel_id;
        }
        $this->load->view('admin/proposals/estimate_convert_template', $data);
    }

    private function _parse_items($proposal)
    {
        $items = array();
        foreach ($proposal->items as $item) {
            $taxnames = array();
            $taxes    = get_proposal_item_taxes($item['id']);
            foreach ($taxes as $tax) {
                array_push($taxnames, $tax['taxname']);
            }
            $item['taxname'] = $taxnames;
            $item['parent_item_id'] = $item['id'];
            $item['id']      = 0;
            $items[]         = $item;
        }

        return $items;
    }

    /* Send proposal to email */
    public function send_to_email($id)
    {
        $canView = $this->user_can_view_proposal($id);
        if (!$canView) {
            access_denied('proposals');
        } else {
            if (!has_permission('proposals', '', 'view') && !has_permission('proposals', '', 'view_own') && $canView == false) {
                access_denied('proposals');
            }
        }

        if ($this->input->post()) {
            $success = $this->proposals_model->send_proposal_to_email($id, 'proposal-send-to-customer', $this->input->post('attach_pdf'), $this->input->post('cc'));
            if ($success) {
                set_alert('success', _l('proposal_sent_to_email_success'));
            } else {
                set_alert('danger', _l('proposal_sent_to_email_fail'));
            }

            if ($this->set_proposal_pipeline_autoload($id)) {
                redirect($_SERVER['HTTP_REFERER']);
            } else {
                redirect(admin_url('proposals/list_proposals/' . $id));
            }
        }
    }

    public function copy($id)
    {
        if (!has_permission('proposals', '', 'create')) {
            access_denied('proposals');
        }
        $new_id = $this->proposals_model->copy($id);
        if ($new_id) {
            set_alert('success', _l('proposal_copy_success'));
            $this->set_proposal_pipeline_autoload($new_id);
            redirect(admin_url('proposals/proposal/' . $new_id));
        } else {
            set_alert('success', _l('proposal_copy_fail'));
        }
        if ($this->set_proposal_pipeline_autoload($id)) {
            redirect(admin_url('proposals'));
        } else {
            redirect(admin_url('proposals/list_proposals/' . $id));
        }
    }

    public function mark_action_status($status, $id)
    {
        if (!has_permission('proposals', '', 'edit')) {
            access_denied('proposals');
        }
        $success = $this->proposals_model->mark_action_status($status, $id);
        if ($success) {
            set_alert('success', _l('proposal_status_changed_success'));
        } else {
            set_alert('danger', _l('proposal_status_changed_fail'));
        }
        if ($this->set_proposal_pipeline_autoload($id)) {
            redirect(admin_url('proposals'));
        } else {
            redirect(admin_url('proposals/list_proposals/' . $id));
        }
    }

    public function delete($id)
    {
        if (!has_permission('proposals', '', 'delete')) {
            access_denied('proposals');
        }
        $response = $this->proposals_model->delete($id);
        if ($response == true) {
            set_alert('success', _l('deleted', _l('proposal')));
        } else {
            set_alert('warning', _l('problem_deleting', _l('proposal_lowercase')));
        }
        redirect(admin_url('proposals'));
    }

    public function get_relation_data_values($rel_id, $rel_type,$email = '')
    {

        echo json_encode($this->proposals_model->get_relation_data_values($rel_id, $rel_type,$email));
    }

    public function search_enqiry_lead_customer($value){
        $value = str_replace('%20', ' ', $value);
        $relType =  $this->uri->segment(5);
        //if($count != 0){
        if($relType == 'lead'){
            $leadresult = $this->proposals_model->check_on_leads($value);
            //$count = count($leadresult);
            $rel_type = 'lead';
            $rel_id = $leadresult['id'];
            //call to native function
            $this->get_relation_data_values($rel_id, $rel_type);
        }
        //}
        //else{
        if($relType == 'customer'){
            $email = $this->uri->segment(6);
            $clientresult = $this->proposals_model->check_on_clients($value,$email); 
            if(!empty($clientresult)){
                 $rel_type = 'customer';
                 $rel_id = $clientresult['userid'];
                 $this->get_relation_data_values($rel_id, $rel_type,$email);
            }
            else{
                $response = array('result' => 'not-found');
                echo json_encode($response);
            }
        }

       // }        

    }

    public function getCommissionPercent($companyid,$categoryid){
        /*As per discussion the company id will be always 1 so we have hard coded the company id to 1*/
        //$url = apiUrl."ProductsCommission&category_id=".$categoryid."&company_id=".$companyid;
        $url = apiUrl."ProductsCommission&category_id=".$categoryid."&company_id=1";
        $result = $this->comman_curl($url);
        $jsonArray = json_decode($result,true);
        return !empty($jsonArray) ? $jsonArray['commission_per'] : 1;
    }

    public function add_proposal_comment()
    {
        if ($this->input->post()) {
            echo json_encode(array(
                'success' => $this->proposals_model->add_comment($this->input->post()),
            ));
        }
    }

    public function edit_comment($id)
    {
        if ($this->input->post()) {
            echo json_encode(array(
                'success' => $this->proposals_model->edit_comment($this->input->post(), $id),
                'message' => _l('comment_updated_successfully'),
            ));
        }
    }

    public function get_proposal_comments($id)
    {
        $data['comments'] = $this->proposals_model->get_comments($id);
        $this->load->view('admin/proposals/comments_template', $data);
    }

    public function remove_comment($id)
    {
        $this->db->where('id', $id);
        $comment = $this->db->get('tblproposalcomments')->row();
        if ($comment) {
            if ($comment->staffid != get_staff_user_id() && !is_admin()) {
                echo json_encode(array(
                    'success' => false,
                ));
                die;
            }
            echo json_encode(array(
                'success' => $this->proposals_model->remove_comment($id),
            ));
        } else {
            echo json_encode(array(
                'success' => false,
            ));
        }
    }

    public function save_proposal_data()
    {
        if (!has_permission('proposals', '', 'edit') && !has_permission('proposals', '', 'create')) {
            header('HTTP/1.0 400 Bad error');
            echo json_encode(array(
                'success' => false,
                'message' => _l('access_denied'),
            ));
            die;
        }
        $success = false;
        $message = '';

        $this->db->where('id', $this->input->post('proposal_id'));
        $this->db->update('tblproposals', array(
            'content' => $this->input->post('content', false),
        ));

        if ($this->db->affected_rows() > 0) {
            $success = true;
            $message = _l('updated_successfully', _l('proposal'));
        }

        echo json_encode(array(
            'success' => $success,
            'message' => $message,
        ));
    }

    // Pipeline
    public function pipeline($set = 0, $manual = false)
    {
        if ($set == 1) {
            $set = 'true';
        } else {
            $set = 'false';
        }
        $this->session->set_userdata(array(
            'proposals_pipeline' => $set,
        ));
        if ($manual == false) {
            redirect(admin_url('proposals'));
        }
    }

    public function pipeline_open($id)
    {
        if (has_permission('proposals', '', 'view') || has_permission('proposals', '', 'view_own') || get_option('allow_staff_view_proposals_assigned') == 1) {
            $data['proposal']      = $this->get_proposal_data_ajax($id, true);
            $data['proposal_data'] = $this->proposals_model->get($id);
            $this->load->view('admin/proposals/pipeline/proposal', $data);
        }
    }

    public function update_pipeline()
    {
        if (has_permission('proposals', '', 'edit')) {
            $this->proposals_model->update_pipeline($this->input->post());
        }
    }

    public function get_pipeline()
    {
        if (has_permission('proposals', '', 'view') || has_permission('proposals', '', 'view_own') || get_option('allow_staff_view_proposals_assigned') == 1) {
            $data['statuses'] = $this->proposals_model->get_statuses();
            $this->load->view('admin/proposals/pipeline/pipeline', $data);
        }
    }

    public function pipeline_load_more()
    {
        $status = $this->input->get('status');
        $page   = $this->input->get('page');

        $proposals = $this->proposals_model->do_kanban_query($status, $this->input->get('search'), $page, array(
            'sort_by' => $this->input->get('sort_by'),
            'sort' => $this->input->get('sort'),
        ));

        foreach ($proposals as $proposal) {
            $this->load->view('admin/proposals/pipeline/_kanban_card', array(
                'proposal' => $proposal,
                'status' => $status,
            ));
        }
    }

    public function set_proposal_pipeline_autoload($id)
    {
        if ($id == '') {
            return false;
        }

        if ($this->session->has_userdata('proposals_pipeline') && $this->session->userdata('proposals_pipeline') == 'true') {
            $this->session->set_flashdata('proposalid', $id);

            return true;
        }

        return false;
    }

    private function user_can_view_proposal($id)
    {
        if (has_permission('proposals', '', 'view')) {
            return true;
        }

        $this->db->select('id,addedfrom,assigned');
        $this->db->from('tblproposals');
        $this->db->where('id', $id);
        $proposal = $this->db->get()->row();

        if((has_permission('proposals','','view_own') && $proposal->addedfrom == get_staff_user_id())
            || ($proposal->assigned == get_staff_user_id() && get_option('allow_staff_view_proposals_assigned') == 1)) {
            return true;
        }

        return false;
    }

    public function getVendors(){
        $productId = $_POST['productId'];
        $productCode = $_POST['productCode']; 
        $elasticUrl = elasticUrl;
        $imgurl = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? devImageUrl : prodImageUrl ;
        $url = $elasticUrl."_search?q=code:".$productCode;
        if(!empty($productCode)) {
            $data['response'] = $this->getSdstoreLineItemProducts($productCode,$url,$productId);
            $data['type'] = 'sdstoreProduct';
        } else {
            $data['response'] = '';
            $data['type'] = 'sdstoreProduct';
        }
        if(empty($_POST['isFromEstimate'])){
            $view = $this->load->view('admin/proposals/view_vendor_table_data',$data);
        }
        else{
            $view = $this->load->view('admin/estimates/view_vendor_table_data',$data);
        }

    }

    public function getSdstoreLineItemProducts($productCode,$url,$productId){        
        $result = $this->comman_curl($url,'GET');
        $jsonArray = json_decode($result,true);
        $response = array();
        $shiftArray = array();
        $sdVendors = $this->config->item('sd_vendors'); 
        $line_item_id = $productId;
        if(!empty($jsonArray['hits']['hits'])){    
            $products = $jsonArray['hits']['hits'];

            foreach($products as $product){
              if(!in_array($product['_source']['companyid'], $sdVendors)){    
                $shiftArray['vendor'] = $product['_source']['companyname'];
                $shiftArray['vendorId'] = $product['_source']['companyid'];
                $url = apiUrl."Orderassign";
                    $result = commanCurl($url,'GET');
                    $jsonArray = json_decode($result['result'],true);
                    foreach ($jsonArray as $key => $value) {
                        if($value['company_id'] == $product['_source']['companyid']){
                            $shiftArray['vendorCompany'] = !empty($value['company']) ? $value['company']: '-';
                            $shiftArray['vendorName'] = !empty($value['firstname'])? $value['firstname']: '-';
                            $shiftArray['vendorContact'] = !empty($value['phone']) ? $value['phone']: '-';
                            $shiftArray['vendorLocation'] = !empty($value['state']) ? $value['state']: '-';
                            $shiftArray['sdEntity'] = !empty($value['sd_entity']) ? $value['sd_entity']: '-';
                            $shiftArray['shipmentType'] = !empty($value['shipment_type'])? $value['shipment_type']: '-';     
                        }
                    }
                $shiftArray['productCode'] = $product['_source']['code'];
                $shiftArray['productName'] = $product['_source']['productname'];
                $shiftArray['productId'] = $product['_source']['product_id'];
                $shiftArray['rate'] = round($product['_source']['transferprice']);
                $shiftArray['isMappingFromSdstore'] = 1;
                $shiftArray['vendor_source'] = vendor_source_sd_store;
                $shiftArray['line_item_id'] = $line_item_id; 
                array_push($response, $shiftArray);
              }
            }
        }
        $getCrmVendors = $this->proposals_model->get_adhoc_vendors($productId);
        if(!empty($getCrmVendors)){
            foreach ($getCrmVendors as $key => $value) {
                    $shiftArray['vendor'] = $value['vendorCompany'];
                    $shiftArray['vendorId'] = $value['vendorId'];
                    $shiftArray['vendorLocation'] = $value['vendorLocation'];
                    $shiftArray['vendor_source'] = $value['vendor_source'];
                    $shiftArray['vendorContact'] = $value['vendorContact']; 
                    $shiftArray['vendorName'] = $value['vendorName']; 
                    $shiftArray['productCode'] = isset($value['productCode']) ? $value['productCode'] : '';
                    $shiftArray['productName'] = isset($value['productName']) ? $value['productName'] : '';
                    $shiftArray['productId'] = $value['productId'];
                    $shiftArray['rate'] = $value['rate'];
                    $shiftArray['sdEntity'] = $value['sdEntity'];
                    $shiftArray['shipmentType'] = $value['shipmentType'];
                    $shiftArray['isMappingFromSdstore'] = 0;
                    $shiftArray['line_item_id'] = $line_item_id; 
                    array_push($response, $shiftArray);
            }
        }
        return $response;

    }

    public function getSdstoreProducts($productCode,$url,$productId){        
        $result = $this->comman_curl($url,'GET');
        $jsonArray = json_decode($result,true);
        $response = array();
        $shiftArray = array();
        $sdVendors = $this->config->item('sd_vendors'); 
        if(!empty($jsonArray['hits']['hits'])){    
            $products = $jsonArray['hits']['hits'];
            foreach($products as $product){
              //if(!in_array($product['_source']['companyid'], $sdVendors)){    
                $shiftArray['vendor'] = $product['_source']['companyname'];
                $shiftArray['vendorId'] = $product['_source']['companyid'];
                $url = apiUrl."Orderassign";
                    $result = commanCurl($url,'GET');
                    $jsonArray = json_decode($result['result'],true);
                    foreach ($jsonArray as $key => $value) {
                        if($value['company_id'] == $product['_source']['companyid']){
                            $shiftArray['vendorCompany'] = !empty($value['company']) ? $value['company']: '-';
                            $shiftArray['vendorName'] = !empty($value['firstname'])? $value['firstname']: '-';
                            $shiftArray['vendorContact'] = !empty($value['phone']) ? $value['phone']: '-';
                            $shiftArray['vendorLocation'] = !empty($value['state']) ? $value['state']: '-';
                            $shiftArray['sdEntity'] = !empty($value['sd_entity']) ? $value['sd_entity']: '-';
                            $shiftArray['shipmentType'] = !empty($value['shipment_type'])? $value['phone']: '-';     
                        }
                    }
                $shiftArray['productCode'] = $product['_source']['code'];
                $shiftArray['productName'] = $product['_source']['productname'];
                $shiftArray['productId'] = $product['_source']['product_id'];
                $shiftArray['rate'] = round($product['_source']['transferprice']);
                $shiftArray['isMappingFromSdstore'] = 1; 
                array_push($response, $shiftArray);
              }
            //}
        }
        $getCrmVendors = $this->proposals_model->get_adhoc_vendors($productId);
        if(!empty($getCrmVendors)){
            foreach ($getCrmVendors as $key => $value) {
                $shiftArray['vendor'] = $value['vendorCompany'];
                $shiftArray['vendorId'] = $value['vendorId'];
                $shiftArray['vendorLocation'] = $value['vendorLocation'];
                $shiftArray['vendorContact'] = $value['vendorContact']; 
                $shiftArray['vendorName'] = $value['vendorName']; 
                $shiftArray['productCode'] = $value['productCode'];
                $shiftArray['productName'] = $value['productName'];
                $shiftArray['productId'] = $value['productId'];
                $shiftArray['rate'] = $value['rate'];
                $shiftArray['sdEntity'] = $value['sdEntity'];
                $shiftArray['shipmentType'] = $value['shipmentType'];
                $shiftArray['isMappingFromSdstore'] = 0;
                array_push($response, $shiftArray);
            }
        }
        return $response;

    }

    public function getProductAndAllVendors() {
        $productId = $_POST['productId'];
        $checkProductType = strpos($productId, 'CRMPRO');
        $data['getAllVendors'] = $this->proposals_model->get_all_vendors();
        if($checkProductType === false){
            $elasticUrl = elasticUrl;
            $imgurl = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? devImageUrl : prodImageUrl ;
            $url = $elasticUrl."_search?q=product_id:".$productId;
            $data['response'] = $this->getSdstoreProducts('',$url,$productId);               
        } else {
            $crmProductId = str_replace('CRMPRO', '', $productId);
            $data['response'] = $this->proposals_model->get_crm_product($crmProductId);
        }

        echo json_encode($data);

    }

    public function addMapping(){
        $checkProductType = strpos($_POST['productid'], 'CRMPRO');
        if($checkProductType === false){
            $productType = 1; //1-means SD-STORE PRODUCT
            $productId = $_POST['productid'];
        } else{
            $productType = 0; //0-means CRM PRODUCT
            $productId = str_replace('CRMPRO', '', $_POST['productid']);
        }
        $productCode = $_POST['productCode'];
        $productPrice = $_POST['transferprice'];
        $productPrice = number_format((float)$productPrice, 2, '.', ''); 
        $vendor = $_POST['vendor'];
        $productCode = $_POST['productCode'];
        $vendorType = $_POST['vendorType'];

        $data = array('product_id' => $productId, 'product_code' => $productCode,'vendor_id' => $vendor, 'price' => $productPrice, 'product_type' => $productType, 'vendor_type' => $vendorType);
        $checkMapping = $this->invoice_items_model->check_vendorproduct_mappping($data); //here checking if mapping already done or not
         if(empty($checkMapping)){
            $this->invoice_items_model->add_mapping($data);
            set_alert('success', _l('added_successfully', _l('proposal')));     
            $response = array('status'=> 1, 'message' => 'success');
            echo json_encode($response);
        }else{
            $update = $this->invoice_items_model->update_mapping($data);
            if($update){
                $response = array('status'=> 1, 'message' => 'success');
                set_alert('success', _l('added_successfully', _l('proposal')));
                echo json_encode($response);  
            }else{
                $response = array('status'=> 0, 'message' => 'Failure');
                echo json_encode($response);  
            }

        }
    }

    public function getAdhocVendors(){
        $productId = $_POST['productCode'];
        $data['type'] = 'crmProduct';
        $data['response'] = $this->proposals_model->get_adhoc_vendors($productId);
        if(empty($_POST['isFromEstimate'])){
            $view = $this->load->view('admin/proposals/view_vendor_table_data',$data);
        }
        else{
            $view = $this->load->view('admin/estimates/view_vendor_table_data',$data);
        }
    }

    public function viewVendorEstimate(){
        if(!empty($_POST['productCode'])){
            $productId = $_POST['productCode'];
            $data['type'] = 'crmProduct';
            $vendorResponse = array();
            $crmVendors= $this->proposals_model->get_adhoc_vendors($productId);
            if(!empty($crmVendors)){
                foreach ($crmVendors as $key => $vendors) {
                    array_push($vendorResponse, $vendors);   
                }
            }
            $sdVendors = $this->proposals_model->get_sd_store_vendors($productId);
            if(!empty($sdVendors)){
                foreach ($sdVendors as $key => $vendor) {
                    array_push($vendorResponse,$vendor);       
                }
            }
            $data['response'] = $vendorResponse;
            $view = $this->load->view('admin/estimates/view_vendor_table_data',$data);       
        } else {
            $data['response'] = '';
            $view = $this->load->view('admin/estimates/view_vendor_table_data',$data);
        }
    }

    public function getProductStore(){
        $term = trim(strip_tags($_GET['term']));
        $term = preg_replace('/\s+/', ' ', $term);
        $keyword = str_replace(" ","%20",$term);
        $elasticUrl = elasticUrl;
        $imgurl = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? devImageUrl : prodImageUrl ;
        $search_limit = $this->config->item('search_limit');
        $url = $elasticUrl."_search?q=productname:".$keyword.'&size='.$search_limit; 
        $result = $this->comman_curl($url); 
        $jsonArray = json_decode($result,true);
        if(empty($jsonArray['hits']['hits'])){
            $imgurl = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? devImageUrl : prodImageUrl ;
            $search_limit = $this->config->item('search_limit');
            $keyword = strtoupper($keyword);
            $url = $elasticUrl."_search?q=code:".$keyword.'*&size='.$search_limit; 
            $result = $this->comman_curl($url); 
            $jsonArray = json_decode($result,true);
        }
        $response = array(); 
        $storeProducts = array(); //to store products
        $shiftArray = array(); //temp variable
        $shiftArray = !empty($jsonArray['hits']['hits']) ? $jsonArray['hits']['hits'] : "" ;
        $sdVendors = $this->config->item('sd_vendors');
        if(!empty($shiftArray)){
            foreach ($shiftArray as $value) {
                if(in_array($value['_source']['companyid'], $sdVendors) && $value['_source']['status'] == "A"){ 
                    //[SC-129] Starts
                    $storeProducts['value'] = rtrim($value['_source']['productname']);
                    //[SC-129] Ends
                    $storeProducts['long_description'] = $value['_source']['code'];
                    $storeProducts['rate'] = round($value['_source']['transferprice']);
                    $storeProducts['vendor'] = $value['_source']['companyname'];
                    $storeProducts['vendor_id'] = $value['_source']['companyid'];
                    $storeProducts['product_id'] = $value['_source']['product_id'];
                    $storeProducts['moq'] = $value['_source']['moq'];
                    $storeProducts['stock'] = $value['_source']['stock'];
                    $storeProducts['tax_id'] = $value['_source']['taxid'];
                    $storeProducts['img'] = $imgurl.$value['_source']['imgfolder'].'/'.$value['_source']['imagepath'];
                    array_push($response,$storeProducts);
                }
            }
        }
        
        if(!empty($response)){
            echo json_encode($response);    
        }else{
            $response['value'] = '';
            echo json_encode($response);
        }
    }

    public function getProductStoreLineItem(){
        $term = trim(strip_tags($_GET['term']));
        $term = preg_replace('/\s+/', ' ', $term);
        $keyword = str_replace(" ","%20",$term);
        $elasticUrl = elasticUrl;  
        $imgurl = ENVIRONMENT == 'development' || ENVIRONMENT == 'testing' ? devImageUrl : prodImageUrl ;
        $url = $elasticUrl."_search?q=code:".$keyword;
        $result = $this->comman_curl($url); 
        $jsonArray = json_decode($result,true);
        $response = array(); 
        $storeProducts = array(); //to store products
        $shiftArray = array(); //temp variable
        $shiftArray = $jsonArray['hits']['hits'];
        $sdVendors = $this->config->item('sd_vendors'); 
        foreach ($shiftArray as $value) {
            if(in_array($value['_source']['companyid'], $sdVendors)){
                //[SC-129] Starts
                $storeProducts['value'] = rtrim($value['_source']['productname']);
                //[SC-129] Ends
                $storeProducts['long_description'] = $value['_source']['code'];
                $storeProducts['rate'] = '';
                $storeProducts['vendor'] = 'No Vendors Selected';
                $storeProducts['vendor_id'] = $value['_source']['companyid'];
                $storeProducts['product_id'] = $value['_source']['product_id'];
                $storeProducts['tax_id'] = $value['_source']['taxid'];
                $storeProducts['moq'] = $value['_source']['moq'];
                $storeProducts['stock'] = $value['_source']['stock'];
                $storeProducts['img'] = $imgurl.$value['_source']['imgfolder'].'/'.$value['_source']['imagepath'];
                array_push($response,$storeProducts);
            }
            
        }
        if(!empty($response)){
            echo json_encode($response);    
        }else{
            $response['value'] = '';
            echo json_encode($response);
        }
    }

    public function getProductCrm() {

        $term = trim(strip_tags($_GET['term']));
        $term = preg_replace('/\s+/', ' ', $term);
        $keyword = str_replace(" ","%20",$term);
        $value = $this->proposals_model->get_crm_product_by_name($term);
        $response['long_description'] = $value->long_description;
        $response['product_id'] = $value->id;
        if(!empty($response)){
            echo json_encode($response);    
        }else{
            $response['value'] = '';
            echo json_encode($response);
        }

    }

    public function pushProducts($value,$vendor){
        if(!empty($value['tax_ids'])){
            $taxRate = $this->getTaxRate($value['tax_ids']);
        }else{
            $taxRate = 10;
        }        
        $commissionPercent = $this->getCommissionPercent($value['company_id'],$value['main_category']);
        /*Tax calculation*/
        $gst = $taxRate/100;
        $finalGst = $gst + 1;
        /*End Tax Calculation*/
        $sellingPrice = $value['price']/$finalGst; 
        $productCommission = 1-($commissionPercent/100); 

        /*transfer price calculation with productcommission*/
        $transferPrice = $sellingPrice * $productCommission;
        $finalPrice = str_replace(',','',$transferPrice);
        /*end transfer price calculation*/
       
        /* start of product push*/
        $storeProducts['value'] = $value['product'];
        $storeProducts['long_description'] = $value['product_code'];
        $storeProducts['rate'] = round($finalPrice);
        $storeProducts['vendor'] = (!empty($vendor['company_name'])) ? $vendor['company_name']: 'N/A';
        $storeProducts['vendor_id'] = $value['company_id'];
        $storeProducts['product_id'] = $value['product_id'];
        $storeProducts['tax_id'] = $value['tax_ids'];
            if(!empty($value['main_pair']['detailed']['image_path'])){
                    $storeProducts['img'] = $value['main_pair']['detailed']['image_path'];
            }else{
                    $storeProducts['img'] = 'http://cdndev.shakedeal.com/images/detailed/129/SDJSH0001500.jpg?t=1477549986';
            }
        /*end of product push*/
        return $storeProducts;
    }

    public function getVendorName($id){

        $url = apiUrl."users&company_id=".$id;
        $result = $this->comman_curl($url);
        $jsonArray = json_decode($result,true);
        return $jsonArray['users'];

    }

    public function getTaxRate($id){

        $url = apiUrl."taxes/".$id;
        $result = $this->comman_curl($url);
        $jsonArray = json_decode($result,true);
        $tax = (float) filter_var($jsonArray['tax'],FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        return $tax;

        

    }

    public function comman_curl($url){

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
        curl_setopt($ch, CURLOPT_ENCODING, '');

        //curl_setopt($ch,CURLOPT_HTTPHEADER,array("authorization:".apiToken));

        $result = curl_exec($ch);

        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close ($ch);        
        return $result;
    }

    public function autocomplete_search(){
        
        $term = trim(strip_tags($_GET['term'])); //search keyword
        $a_json = array();
        $a_json_row = array();
        /*Search the keyword in leads table*/
        $data = $this->proposals_model->search_leads($term); 
        /*found in leads*/
        if(!empty($data)){
             foreach($data as $val){
                /*here checking lead converted to customer or not*/
                if($val['status'] != 1){
                    $a_json_row['value'] = $val['name'].' -- '.'Found in Leads';
                    $a_json_row['name'] = $val['name']; 
                    $a_json_row['id'] = $val['id'];
                    $a_json_row['email'] = $val['email'];
                    $a_json_row['type'] = 'lead';   
                    array_push($a_json, $a_json_row);
                }
                else{
                    /*here checking in customer */
                    $data = $this->proposals_model->search_customer($term);
                        foreach($data as $val){
                            $value = isset($val['firstname']) ? $val['firstname'] : $val['company'];
                            $a_json_row['value'] = $value.' -- '.'Found in Customers';    
                            $a_json_row['name'] = $value;
                            $a_json_row['id'] = $val['userid'];
                            $a_json_row['email'] = isset($val['email']) ? $val['email'] : '';
                            $a_json_row['type'] = 'customer';
                            array_push($a_json, $a_json_row);
                        }
                }
             }  
        }
        /*end found in leads*/

        /*if not found in leads search in customer*/
        else{
                 //$this->search_customer($term,$a_json,$a_json_row);
                 $data = $this->proposals_model->search_customer($term);
                        foreach($data as $val){
                            $value = isset($val['firstname']) ? $val['firstname'] : $val['company'];
                            $a_json_row['value'] = $value.' -- '.'Found in Customers';    
                            $a_json_row['name'] = $value;
                            $a_json_row['id'] = $val['userid'];
                            $a_json_row['email'] = isset($val['email']) ? $val['email'] : '';
                            $a_json_row['type'] = 'customer';
                            array_push($a_json, $a_json_row);
                        }
        }
        /*end of if not found in leads search in customer*/

        if(!empty($a_json)){
            echo json_encode($a_json);
        }else{
            //if not found in both leads and customer then create newlead
            $a_json_row['value'] = 'No Result Found -- Select this to create lead';
            array_push($a_json, $a_json_row);
            echo json_encode($a_json);
        }            
    }

    /*public function search_customer($term,$a_json,$a_json_row){
        $data = $this->proposals_model->search_customer($term);
                foreach($data as $val){
                    $a_json_row['value'] = $val['company'].' -- '.'Found in Customers';    
                    $a_json_row['name'] = $val['company'];
                    $a_json_row['id'] = $val['userid'];
                    $a_json_row['type'] = 'customer';
                    array_push($a_json, $a_json_row);
                }
    }*/

    public function download_file(){
        /*start of shubum code*/
            $file = FCPATH."uploads/demo.csv";
            // echo $file;die;
            if (file_exists($file)) {
                try{
                    header('Content-Description: File Transfer');
                    header("Content-Type:   text/csv;");
                    header('Content-Disposition: attachment; filename="demo.csv"');
                    header('Expires: 0');
                    header('Cache-Control: must-revalidate');
                    header('Pragma: public');
                    header('Content-Length: ' . filesize($file));
                    readfile($file);
                   // set_alert('success', _l('file_downloaded_successfully'));
                }catch(Exception $e){
                    //set_alert('danger', _l('try_again_later'));
                }
            }else{
                //set_alert('danger', _l('try_again_later'));
            }
        /*end of shubum code*/
    }

    public function checkVendorOldPrice(){
        $productId = $_POST['productId'];
        $vendorId = $_POST['vendorId'];
        $price = $_POST['newPrice'];
        $result = $this->proposals_model->get_vendor_mapped_price($vendorId, $productId);

        if(empty($result)){
            $response = array('status'=> 1, 'message' => 'success');
            echo json_encode($response);
        }
        elseif ((int)$result[0]['price'] == $price) {
            $response = array('status'=> 0, 'message' => 'productExists');
            echo json_encode($response);            
        }
        else {
            $response = array('status'=> 1, 'message' => 'success');
            echo json_encode($response);
        }
    }

    function getSdStoreVendor(){
        $url = apiUrl."Orderassign";
        $result = commanCurl($url,'GET');
        $jsonArray = json_decode($result['result'],true);
        return $jsonArray;
    }

    public function getVendorDataById(){
       $vendorId = $_POST['vendorId']; 
       $data = $this->proposals_model->getVendorData($vendorId);
       echo json_encode($data);
    }

    public function getSdStoreVendorDataById(){
       $vendorId = $_POST['vendorId']; 
       $data = load_sd_store_vendor_by_id($vendorId);
       $data = $data[0];
       $result['id'] = $data['company_id'];
       $result['companyname'] = $data['company'];
       $result['firstname'] = $data['firstname'];
       $result['phone'] = $data['phone'];
       $result['address'] = $data['address'];
       $result['city'] = $data['city'];
       $result['state'] = $data['state'];
       $result['sd_entity'] = $data['sd_entity'];
       $result['shipment_type'] = $data['shipment_type'];
       $result['gstin'] = $data['GSTIN'];
       $result['zip_postal_code'] = $data['zipcode'];
       $result['email'] = $data['email'];
       echo json_encode($result);
    }
    
}
