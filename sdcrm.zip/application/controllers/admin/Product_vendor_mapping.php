<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Product_vendor_mapping extends Admin_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('invoice_items_model');
        $this->load->model('product_vendor_mapping_model');
        $this->load->helper('common_helper');
    }

    /* List all */
    public function index()
    {
        
        if (!has_permission('product_vendor_list', '', 'view')) {
            access_denied('product_vendor_list');
        }
        $items = $this->product_vendor_mapping_model->get_all_items();
        
        $this->load->view('admin/mapping/list');
    }

    public function datatable(){
        if (!has_permission('product_vendor_list', '', 'view')) {
            access_denied('product_vendor_list');
        }
        // Datatables Variables
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));
          
          $sd_store_vendor = load_sd_store_vendors();
          $result = $this->product_vendor_mapping_model->get_all();
          $data = array();
          $i = 1;
          foreach($result->result() as $r) {

              $editBtn = "";
              $deleteBtn = "";
              if (has_permission('product_vendor_list', '', 'edit')) {
                  $editBtn = '<a class="editor_edit"><span style="cursor:pointer;" class="glyphicon glyphicon-edit" onclick="edit('.$r->id.')"></span></a>';
              }
              if (has_permission('product_vendor_list', '', 'delete')) {
                  $deleteBtn = '<a id="delete" class="editor_remove"><span style="cursor:pointer;" onclick="remove('.$r->id.')" class="glyphicon glyphicon-remove" id="delete"></a>';
              }

            $getProducts = $this->product_vendor_mapping_model->get_product($r->product_id);
            
            if($r->vendor_type == 0 && $r->is_pushed == 0){
              $getVendor = $this->product_vendor_mapping_model->get_vendor($r->vendor_id);
            }
            
            elseif($r->vendor_type == 1 && ($r->is_pushed == 0 || $r->is_pushed == 1 || $r->is_pushed == 2)){
                $VendorFound = 0;
                foreach ($sd_store_vendor as $keyTemp => $valueTemp) {
                    if($valueTemp['company_id'] == $r->vendor_id){
                        $getVendor['companyname']= $valueTemp['company'];
                        $VendorFound =1;
                    }
                }
                if($VendorFound == 0){
                    $getVendor['companyname'] = '';
                }
            }
            
            elseif($r->vendor_type== 0 && ($r->is_pushed== 1 || $r->is_pushed == 2)){
                $getvendorquery = "SELECT tblcrmstore_vendor.sdstore_company_id as vendor_id FROM tblcrmstore_vendor WHERE tblcrmstore_vendor.crm_vendor_id=".$r->vendor_id;
                $vendorname = $this->db->query($getvendorquery)->row_array();
                $VendorFound = 0;
                foreach ($sd_store_vendor as $keyTemp => $valueTemp) {
                    if($valueTemp['company_id'] == $vendorname['vendor_id']){
                        $getVendor['companyname'] = $valueTemp['company'];
                        $VendorFound = 1;
                    }
                }
                if($VendorFound == 0){
                    $getVendor['companyname'] = '';
                }
            }
            else{
                $getVendor['companyname'] = '';
            }

            
            //store products
            if(!empty($getProducts['description'])){
              $storeProducts = array(
                                      'p' => $i,
                                      'productname' => $getProducts['description'],
                                      //'price' => $getProducts['rate'],
                                      'price' => number_format($r->price,2),
                                      'vendorname' => $getVendor['companyname'],
                                      'action' => $editBtn.'&nbsp;&nbsp;'.$deleteBtn
                                    ); 

              $data[] = $storeProducts;
              $i++;
            }
          }

          $output = array(
                         "draw" => $draw,
                         "recordsTotal" => $result->num_rows(),
                         "recordsFiltered" => $result->num_rows(),
                         "data" => $data
                         );
          echo json_encode($output);
    }

   public function edit(){
        if (!has_permission('product_vendor_list', '', 'edit')) {
            access_denied('product_vendor_list');
        }
        $sd_store_vendor = load_sd_store_vendors();
        $id = $_POST['id'];
        $result = $this->product_vendor_mapping_model->get_product_vendor_mapping($id);

        if($result['vendor_type'] == 0 && $result['is_pushed'] == 0){
          $vendorname = $this->invoice_items_model->get_vendor_name($result['vendor_id']);
        }
        
        elseif($result['vendor_type'] == 1 && ($result['is_pushed']  == 0 || $result['is_pushed']  == 1 || $result['is_pushed']  == 2)){
            $VendorFound = 0;
            foreach ($sd_store_vendor as $keyTemp => $valueTemp) {
                if($valueTemp['company_id'] == $result['vendor_id']){
                    $vendorname['companyname']= $valueTemp['company'];
                    $vendorname['id'] = $valueTemp['company_id'];
                    $VendorFound = 1;
                }
            }
            if($VendorFound == 0){
                $getVendor['companyname'] = '';
            }
        }
        
        elseif($result['vendor_type'] == 0 && ($result['is_pushed'] == 1 || $result['is_pushed']  == 2)){
            $getvendorquery = "SELECT tblcrmstore_vendor.sdstore_company_id as vendor_id FROM tblcrmstore_vendor WHERE tblcrmstore_vendor.crm_vendor_id=".$result['vendor_id'];
            $vendorname = $this->db->query($getvendorquery)->row_array();
            $VendorFound = 0;
            foreach ($sd_store_vendor as $keyTemp => $valueTemp) {
                if($valueTemp['company_id'] == $vendorname['vendor_id']){
                    $vendorname['companyname'] = $valueTemp['company'];
                    $vendorname['id'] = $result['vendor_id'];
                    $VendorFound = 1;
                }
            }
            if($VendorFound == 0){
                $vendorname['companyname'] = '';
            }
        }
        else{
            $vendorname['companyname'] = '';
        }



        $productname = $this->product_vendor_mapping_model->get_product($result['product_id']);
        $response ='<tr><td>'.$productname['description'].'<td>'.$vendorname['companyname'].'<td ><input style="width: 100%;padding: 12px 20px;margin: 0px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;" type=text id=price'.$vendorname['id'].' value='.number_format($result['price'],2).'><td><a class="btn btn-info" id=update'.$vendorname['id'] .'     style="cursor:pointer" onclick="updateproductvendor('.$result['product_id'].','.$vendorname['id'].')"> update
                ';

        echo $response;

   }

   public function remove(){

        if (!has_permission('product_vendor_list', '', 'delete')) {
            access_denied('product_vendor_list');
        }
        $id = $_POST['id'];
        if($id != ''){
            $this->product_vendor_mapping_model->remove_product_vendor($id);
            echo "success";
        }else{
            echo "fail";
        }

    }

    public function getproductvendor(){

        $response ='<tr><td style="margin-top:12px;"><input
        placeholder=SearchProduct  style="padding: 9px 10px;margin:
        8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px
        ;box-sizing: border-box;" list="products" name="browser" id="product"><datalist id="products" style="overflow: scroll;">
        </datalist><td><input placeholder=SearchVendor  style="padding: 9px 10px;margin:
        8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px
        ;box-sizing: border-box;" list="vendors" name="vendor" id="vendor">
        <datalist id="vendors" style="overflow: scroll;">
        </datalist>
        <td><input type="text" style="width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;" id="price"><td><a style="margin-top:12px;" onclick="assignproductvendor()" class="btn btn-info">Add</tr>';
        echo json_encode($response);

    }

    public function productdatalist(){
        $datalist = array(); //to store vendors list
        $products = $this->product_vendor_mapping_model->get_all_products();
        foreach ($products as $product) {
            $productname = str_replace(' ', '',$product['search_keyword']);
            $datalist[] ='<option value='.$productname.'>';
        }
        //$datalist[] = '<a href="www.google.com" target="_blank">Add Vendor</a>"';       
        echo json_encode($datalist);
    }


    //Vendor assigning for item
    public function assignproductvendor(){
      $vendorSearch = $_POST['vendor'];
      $productSearch = $_POST['product'];
      $productPrice = $_POST['price'];

      $product = $this->invoice_items_model->get_product_by_name($productSearch);

      if($product != null){
        $vendor = $this->invoice_items_model->get_vendor($vendorSearch);
        $data = array('product_id' => $product['id'], 'vendor_id' => $vendor['id'], 'price' => $productPrice);
        // $checkMapping = $this->invoice_items_model->check_vendorproduct_mappping($data); //here checking if mapping already done or not
        // if(empty($checkMapping)){
            $this->invoice_items_model->add_mapping($data);
            if($product['rate'] > $productPrice){
              $this->db->where('id', $product['id']);
              $this->db->update('tblitems', array(
                  'rate' => $productPrice,
              ));     
            }
            $response = array('status'=> 1, 'message' => 'success');
            echo json_encode($response);
        // }else{
        //     $updatearray = array('product_id' => $product['id'],'vendor_id' => $vendor['id']);
        //     $result = $this->invoice_items_model->update_product_price($updatearray,$productPrice);

        //     $response = array('status'=> 0, 'message' => 'Vendor already exists for this product updated with the same price.');
        //     echo json_encode($response);
        // }
      }
    }

    public function editproductvendor(){
      $id = $_POST['id'];
      $rate = abs($_POST['rate']);
      $vendorId = $_POST['vendorId'];
      //update array
      $data = array('product_id' => $_POST['productId'], 'vendor_id' => $vendorId);
      $this->invoice_items_model->update_product_price($data, $rate,$vendorId);//update the price with product_vendor table(pivot table)
      if(!is_numeric($rate) && $rate > 0){
        $response = array('status'=> 0, 'message' => 'rate must be numeric and greater than 0');
        echo json_encode($response);
      }

      $sql = "UPDATE tblsourced_items SET rate='".$rate."' WHERE id= '".$id."' ";
      $this->invoice_items_model->update_items_in($id,$rate,$vendorId);
      
      $result = $this->db->query($sql);

      if($result){
        $response = array('status'=> 1, 'message' => 'success');
        echo json_encode($response);
      }
      else{
        $response = array('status'=> 0, 'message' => 'error');
        echo json_encode($response);
      }
    }

    public function deleteproductvendor(){
      $id = $_POST['id'];
      $vendorId = $_POST['vendorId'];
      $productId = $_POST['productId'];
      //delete product vendor mapping
      $this->invoice_items_model->delete_product_vendor_mapping($vendorId, $productId, $id);

      $sql = "DELETE from tblsourced_items WHERE id= '".$id."' ";
      $result = $this->db->query($sql);

      if($result){
        $response = array('status'=> 1, 'message' => 'success');
        echo json_encode($response);
      }
      else{
        $response = array('status'=> 0, 'message' => 'error');
        echo json_encode($response);
      }

    }
}
