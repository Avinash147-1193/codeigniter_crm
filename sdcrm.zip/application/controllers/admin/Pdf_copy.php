<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Pdf_copy extends CI_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->library('pdf');
        $this->load->model('invoices_model');
        $this->load->model('credit_notes_model');
        $this->load->model('leads_model');
        $this->load->model('estimates_model');
        $this->load->helper('pdf_helper');
        $this->load->helper('constant_helper');
        $this->load->model('payment_modes_model');      
    }
    /* Get all invoices in case user go on index page */
    public function pdf($id)
    {   
        $invoice        = $this->invoices_model->get($id);

        $invoice = do_action('before_admin_view_invoice_pdf', $invoice);
        $invoice_number = format_invoice_number($invoice->id);

        try {
            $pdf = $this->generatePdf($invoice);
        } catch (Exception $e) {
            $message = $e->getMessage();
            echo $message;
            if (strpos($message, 'Unable to get the size of the image') !== false) {
                show_pdf_unable_to_get_image_size_error();
            }
            die;
        }

        $type           = 'D';
        if ($this->input->get('print')) {
            $type = 'I';
        }

        ob_end_clean();
       $pdf->Output(mb_strtoupper(slug_it($invoice_number)) . '.pdf', $type);
    }

    public function generatePdf($invoice){

        $GLOBALS['invoice_pdf'] = $invoice;
        load_pdf_language($invoice->clientid);
        $invoice_number = format_invoice_number($invoice->id);
        $font_name      = get_option('pdf_font');
        $font_size      = get_option('pdf_font_size');

        if ($font_size == '') {
            $font_size = 10;
        }

        $payment_modes = $this->payment_modes_model->get();

        
        // In case user want to include {invoice_number} or {client_id} in PDF offline mode description
        foreach ($payment_modes as $key => $mode) {
            if (isset($mode['description'])) {
                $payment_modes[$key]['description'] = str_replace('{invoice_number}', $invoice_number, $mode['description']);
                $payment_modes[$key]['description'] = str_replace('{client_id}', $invoice->clientid, $mode['description']);
            }
        }

        $whereCF = array('show_on_pdf'=>1);
        if (is_custom_fields_for_customers_portal()) {
            $whereCF['show_on_client_portal'] = 1;
        }

        // check for invoice custom fields which is checked show on pdf
        $pdf_custom_fields = get_custom_fields('invoice', $whereCF);

        $formatArray = get_pdf_format('pdf_format_invoice');
        if (!file_exists(APPPATH.'libraries/Invoice_pdf.php')) {
           // echo APPPATH.'libraries/Invoice_pdf.php';die;
            $this->load->library('pdf');
            $pdf         = new Pdf($formatArray['orientation'], 'mm', $formatArray['format'], true, 'UTF-8', false, false, 'invoice');
            
        } else {
            include_once(APPPATH.'libraries/Invoice_pdf.php');
            $pdf         = new Invoice_pdf($formatArray['orientation'], 'mm', $formatArray['format'], true, 'UTF-8', false, false);
        }

        if (defined('APP_PDF_MARGIN_LEFT') && defined('APP_PDF_MARGIN_TOP') && defined('APP_PDF_MARGIN_RIGHT')) {
            $pdf->SetMargins(APP_PDF_MARGIN_LEFT, APP_PDF_MARGIN_TOP, APP_PDF_MARGIN_RIGHT);
        }

        $pdf->SetTitle($invoice_number);

        $pdf->SetAutoPageBreak(true, (defined('APP_PDF_MARGIN_BOTTOM') ? APP_PDF_MARGIN_BOTTOM : PDF_MARGIN_BOTTOM));

        $pdf->SetAuthor(get_option('company'));
        $pdf->SetFont($font_name, '', $font_size);
        $pdf->setImageScale(1.53);
        $pdf->setJPEGQuality(100);
        $pdf->AddPage($formatArray['orientation'], $formatArray['format']);

        if ($this->input->get('print') == 'true') {
            // force print dialog
            $js = 'print(true);';
            $pdf->IncludeJS($js);
        }

        $status = $invoice->status;
        $swap   = get_option('swap_pdf_info');
        $this->load->library('numberword', array(
            'clientid' => $invoice->clientid,
        ));
        $invoice = do_action('invoice_html_pdf_data', $invoice);

        _bulk_pdf_export_maybe_tag($tag, $pdf);
        if (file_exists(APPPATH . 'views/themes/' . active_clients_theme() . '/views/my_invoicepdf.php')) {
            include(APPPATH . 'views/themes/' . active_clients_theme() . '/views/my_invoicepdf.php');
        } else {
            include(APPPATH . 'views/themes/' . active_clients_theme() . '/views/invoicepdf.php');
        }

        if (ob_get_length() > 0 && ENVIRONMENT == 'production') {
            ob_end_clean();
        }

        return $pdf;
    }

    public function mailchimpPush(){
        $leadsData = $this->leads_model->get_leads_data();
            //Mailchimp api credentials
            $apiKey = mailChimpApiKey;
            $listId = mailChimpUniqueKey;

            foreach($leadsData as $data){
                 //Mailchimp api url
                $memberId = md5(strtolower($data['email']));
                $dataCenter = substr($apiKey,strpos($apiKey,'-')+1);
                $url = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . $listId . '/members/' . $memberId;
                 //Member information
                $payload = json_encode([
                                        'email_address' => $data['email'],
                                        'status' => 'subscribed',
                                        'merge_fields' =>[
                                                            'FNAME' => $data['proposal_to'],
                                                            'ADDRESS1' => 'test',
                                                            'PHONE' => $data['phone']
                                                        ]
                                        ]);
                $this->mailChimpCurl($url, $apiKey, $payload, $data);
            }
    }

    public function mailChimpCurl($url, $apiKey, $payload, $data){
        // send a HTTP POST request with curl
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_USERPWD, 'user:' . $apiKey);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            $result = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if($httpCode == 200){
                logActivity('Lead '.$data['email'].' pushed to mailchimp successfully');
            } else {
                logActivity('Lead '.$data['email'].' not pushed to mailchimp due to following error code '.$httpCode);
            }
    }

}
