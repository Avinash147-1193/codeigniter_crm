<?php
header('Content-Type: text/html; charset=utf-8');
defined('BASEPATH') or exit('No direct script access allowed');
class Leads extends Admin_controller
{
    private $not_importable_leads_fields;

    public function __construct()
    {
        parent::__construct();
        $this->not_importable_leads_fields = do_action('not_importable_leads_fields', array('id', 'source', 'assigned', 'status', 'dateadded', 'last_status_change', 'addedfrom', 'leadorder', 'date_converted', 'lost', 'junk', 'is_imported_from_email_integration', 'email_integration_uid', 'is_public', 'dateassigned', 'client_id', 'lastcontact', 'last_lead_status', 'from_form_id', 'default_language'));
        $this->load->model('leads_model');
        $this->load->model('proposals_model');
        $this->load->helper('general_helper');
        $this->load->helper('constant_helper');
    }

    /* List all leads */
    public function index($id = '')
    {
        close_setup_menu();

        if (!is_staff_member()) {
            access_denied('Leads');
        }

        $data['switch_kanban'] = true;

        if ($this->session->userdata('leads_kanban_view') == 'true') {
            $data['switch_kanban'] = false;
            $data['bodyclass']     = 'kan-ban-body';
        }

        $data['staff'] = $this->staff_model->get('', 1);

        $data['statuses'] = $this->leads_model->get_status();
        $data['sources']  = $this->leads_model->get_source();
        $data['title']    = _l('leads');
        // in case accesed the url leads/index/ directly with id - used in search
        $data['leadid']   = $id;
        $this->load->view('admin/leads/manage_leads', $data);
    }

    public function table()
    {
        if (!is_staff_member()) {
            ajax_access_denied();
        }
        $this->app->get_table_data('leads');
    }

    public function kanban()
    {
        if (!is_staff_member()) {
            ajax_access_denied();
        }
        $data['statuses'] = $this->leads_model->get_status();
        echo $this->load->view('admin/leads/kan-ban', $data, true);
    }

    /* Add or update lead */
    public function lead($id = '')
    {
        if (!is_staff_member() || ($id != '' && !$this->leads_model->staff_can_access_lead($id))) {
            $this->access_denied_ajax();
        }

        if ($this->input->post()) {
            if ($id == '') {
                $id      = $this->leads_model->add($this->input->post());
                $message = $id ? _l('added_successfully', _l('lead')) : '';

                echo json_encode(array(
                    'success' => $id ? true : false,
                    'id' => $id,
                    'message' => $message,
                    'leadView'=>$id ? $this->_get_lead_data($id) : array(),
                ));
            } else {
                $emailOriginal = $this->db->select('email')->where('id', $id)->get('tblleads')->row()->email;
                $proposalWarning = false;
                $message          = '';
                $success          = $this->leads_model->update($this->input->post(), $id);

                if ($success) {
                    $emailNow = $this->db->select('email')->where('id', $id)->get('tblleads')->row()->email;

                    $proposalWarning = (total_rows('tblproposals', array(
                        'rel_type' => 'lead',
                        'rel_id' => $id, )) > 0 && ($emailOriginal != $emailNow) && $emailNow != '') ? true : false;

                    $message = _l('updated_successfully', _l('lead'));
                }
                echo json_encode(array(
                    'success' => $success,
                    'message' => $message,
                    'id'=>$id,
                    'proposal_warning' => $proposalWarning,
                    'leadView'=>$this->_get_lead_data($id),
                ));
            }
            die;
        }

        echo json_encode(array('leadView'=>$this->_get_lead_data($id)));
    }

    private function _get_lead_data($id = '')
    {
        $reminder_data = '';
        $data['lead_locked'] = false;
        $data['members'] = $this->staff_model->get('', 1, array('is_not_staff' => 0));
        $data['status_id'] = $this->input->get('status_id') ? $this->input->get('status_id') : get_option('leads_default_status');

        if (is_numeric($id)) {
            $leadWhere = (has_permission('leads', '', 'view') ? array() : '(assigned = ' . get_staff_user_id() . ' OR addedfrom=' . get_staff_user_id() . ' OR is_public=1)');

            $lead = $this->leads_model->get($id, $leadWhere);

            if (!$lead) {
                header("HTTP/1.0 404 Not Found");
                echo _l('lead_not_found');
                die;
            }

            if (total_rows('tblclients', array('leadid' => $id )) > 0) {
                $data['lead_locked'] = ((!is_admin() && get_option('lead_lock_after_convert_to_customer') == 1) ? true : false);
            }

            $reminder_data = $this->load->view('admin/includes/modals/reminder', array(
                    'id' => $lead->id,
                    'name' => 'lead',
                    'members' => $data['members'],
                    'reminder_title' => _l('lead_set_reminder_title'),
                ), true);

            $data['lead']          = $lead;
            $data['mail_activity'] = $this->leads_model->get_mail_activity($id);
            $data['notes']         = $this->misc_model->get_notes($id, 'lead');
            $data['activity_log']  = $this->leads_model->get_lead_activity_log($id);
        }


        $data['statuses'] = $this->leads_model->get_status();
        $data['sources']  = $this->leads_model->get_source();

        $data = do_action('lead_view_data', $data);

        return array(
            'data' => $this->load->view('admin/leads/lead', $data, true),
            'reminder_data' => $reminder_data,
        );
    }

    public function leads_kanban_load_more()
    {
        if (!is_staff_member()) {
            $this->access_denied_ajax();
        }

        $status = $this->input->get('status');
        $page   = $this->input->get('page');

        $this->db->where('id', $status);
        $status = $this->db->get('tblleadsstatus')->row_array();

        $leads = $this->leads_model->do_kanban_query($status['id'], $this->input->get('search'), $page, array(
            'sort_by' => $this->input->get('sort_by'),
            'sort' => $this->input->get('sort'),
        ));

        foreach ($leads as $lead) {
            $this->load->view('admin/leads/_kan_ban_card', array(
                'lead' => $lead,
                'status' => $status,
            ));
        }
    }

    public function switch_kanban($set = 0)
    {
        if ($set == 1) {
            $set = 'true';
        } else {
            $set = 'false';
        }
        $this->session->set_userdata(array(
            'leads_kanban_view' => $set,
        ));
        redirect($_SERVER['HTTP_REFERER']);
    }

    /* Delete lead from database */
    public function delete($id)
    {
        if (!$id) {
            redirect(admin_url('leads'));
        }

        if (!is_lead_creator($id) && !has_permission('leads', '', 'delete')) {
            access_denied('Delte Lead');
        }

        $response = $this->leads_model->delete($id);
        if (is_array($response) && isset($response['referenced'])) {
            set_alert('warning', _l('is_referenced', _l('lead_lowercase')));
        } elseif ($response === true) {
            set_alert('success', _l('deleted', _l('lead')));
        } else {
            set_alert('warning', _l('problem_deleting', _l('lead_lowercase')));
        }
        $ref = $_SERVER['HTTP_REFERER'];

        // if user access leads/inded/ID to prevent redirecting on the same url because will throw 404
        if(!$ref || strpos($ref,'index/'.$id) !== FALSE) {
            redirect(admin_url('leads'));
        }

        redirect($ref);
    }

    public function mark_as_lost($id)
    {
        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($id)) {
            $this->access_denied_ajax();
        }
        $message = '';
        $success = $this->leads_model->mark_as_lost($id);
        if ($success) {
            $message = _l('lead_marked_as_lost');
        }
        echo json_encode(array(
            'success' => $success,
            'message' => $message,
            'leadView'=>$this->_get_lead_data($id),
            'id'=>$id,
        ));
    }

    public function unmark_as_lost($id)
    {
        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($id)) {
            $this->access_denied_ajax();
        }
        $message = '';
        $success = $this->leads_model->unmark_as_lost($id);
        if ($success) {
            $message = _l('lead_unmarked_as_lost');
        }
        echo json_encode(array(
            'success' => $success,
            'message' => $message,
            'leadView'=>$this->_get_lead_data($id),
            'id'=>$id,
        ));
    }

    public function mark_as_junk($id)
    {
        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($id)) {
            $this->access_denied_ajax();
        }
        $message = '';
        $success = $this->leads_model->mark_as_junk($id);
        if ($success) {
            $message = _l('lead_marked_as_junk');
        }
        echo json_encode(array(
            'success' => $success,
            'message' => $message,
            'leadView'=>$this->_get_lead_data($id),
            'id'=>$id,
        ));
    }

    public function unmark_as_junk($id)
    {
        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($id)) {
            $this->access_denied_ajax();
        }
        $message = '';
        $success = $this->leads_model->unmark_as_junk($id);
        if ($success) {
            $message = _l('lead_unmarked_as_junk');
        }
        echo json_encode(array(
            'success' => $success,
            'message' => $message,
            'leadView'=>$this->_get_lead_data($id),
            'id'=>$id,
        ));
    }

    public function add_activity()
    {
        $leadid = $this->input->post('leadid');
        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($leadid)) {
            $this->access_denied_ajax();
        }
        if ($this->input->post()) {
            $message = $this->input->post('activity');
            $aId = $this->leads_model->log_lead_activity($leadid, $message);
            if ($aId) {
                $this->db->where('id', $aId);
                $this->db->update('tblleadactivitylog', array('custom_activity'=>1));
            }
            echo json_encode(array('leadView'=>$this->_get_lead_data($leadid), 'id'=>$leadid));
        }
    }

    public function get_convert_data($id)
    {
        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($id)) {
            $this->access_denied_ajax();
        }
        $data['lead'] = $this->leads_model->get($id);
        $this->load->view('admin/leads/convert_to_customer', $data);
    }

    /**
     * Convert lead to client
     * @since  version 1.0.1
     * @return mixed
     */
    public function convert_to_customer()
    {

        if (!is_staff_member()) {
            access_denied('Lead Convert to Customer');
        }

        if ($this->input->post()) {
            $default_country              = get_option('customer_default_country');
            $data                         = $this->input->post();
            $data['password'] = $this->input->post('password', false);

            $original_lead_email          = $data['original_lead_email'];
            unset($data['original_lead_email']);

            if (isset($data['transfer_notes'])) {
                $notes = $this->misc_model->get_notes($data['leadid'], 'lead');
                unset($data['transfer_notes']);
            }

            if (isset($data['merge_db_fields'])) {
                $merge_db_fields = $data['merge_db_fields'];
                unset($data['merge_db_fields']);
            }

            if (isset($data['merge_db_contact_fields'])) {
                $merge_db_contact_fields = $data['merge_db_contact_fields'];
                unset($data['merge_db_contact_fields']);
            }

            if (isset($data['include_leads_custom_fields'])) {
                $include_leads_custom_fields = $data['include_leads_custom_fields'];
                unset($data['include_leads_custom_fields']);
            }

            if ($data['country'] == '' && $default_country != '') {
                $data['country'] = $default_country;
            }

            $data['billing_street'] = $data['address'];
            $data['billing_city'] = $data['city'];
            $data['billing_state'] = $data['state'];
            $data['billing_zip'] = $data['zip'];
            $data['billing_country'] = $data['country'];

            $data['is_primary'] = 1;
            $id = $this->clients_model->add($data, true);
            if ($id) {
                if (isset($notes)) {
                    foreach ($notes as $note) {
                        $this->db->insert('tblnotes', array(
                            'rel_id'=>$id,
                            'rel_type'=>'customer',
                            'dateadded'=>$note['dateadded'],
                            'addedfrom'=>$note['addedfrom'],
                            'description'=>$note['description'],
                            'date_contacted'=>$note['date_contacted'],
                            ));
                    }
                }
                if (!has_permission('customers', '', 'view') && get_option('auto_assign_customer_admin_after_lead_convert') == 1) {
                    $this->db->insert('tblcustomeradmins', array(
                        'date_assigned' => date('Y-m-d H:i:s'),
                        'customer_id' => $id,
                        'staff_id' => get_staff_user_id(),
                    ));
                }
                $this->leads_model->log_lead_activity($data['leadid'], 'not_lead_activity_converted', false, serialize(array(
                    get_staff_full_name(),
                )));
                $default_status = $this->leads_model->get_status('', array(
                    'isdefault' => 1,
                ));
                $this->db->where('id', $data['leadid']);
                $this->db->update('tblleads', array(
                    'date_converted' => date('Y-m-d H:i:s'),
                    'status' => $default_status[0]['id'],
                    'junk' => 0,
                    'lost' => 0,
                ));
                // Check if lead email is different then client email
                $contact = $this->clients_model->get_contact(get_primary_contact_user_id($id));
                if ($contact->email != $original_lead_email) {
                    if ($original_lead_email != '') {
                        $this->leads_model->log_lead_activity($data['leadid'], 'not_lead_activity_converted_email', false, serialize(array(
                            $original_lead_email,
                            $contact->email,
                        )));
                    }
                }
                if (isset($include_leads_custom_fields)) {
                    foreach ($include_leads_custom_fields as $fieldid => $value) {
                        // checked don't merge
                        if ($value == 5) {
                            continue;
                        }
                        // get the value of this leads custom fiel
                        $this->db->where('relid', $data['leadid']);
                        $this->db->where('fieldto', 'leads');
                        $this->db->where('fieldid', $fieldid);
                        $lead_custom_field_value = $this->db->get('tblcustomfieldsvalues')->row()->value;
                        // Is custom field for contact ot customer
                        if ($value == 1 || $value == 4) {
                            if ($value == 4) {
                                $field_to = 'contacts';
                            } else {
                                $field_to = 'customers';
                            }
                            $this->db->where('id', $fieldid);
                            $field = $this->db->get('tblcustomfields')->row();
                            // check if this field exists for custom fields
                            $this->db->where('fieldto', $field_to);
                            $this->db->where('name', $field->name);
                            $exists               = $this->db->get('tblcustomfields')->row();
                            $copy_custom_field_id = null;
                            if ($exists) {
                                $copy_custom_field_id = $exists->id;
                            } else {
                                // there is no name with the same custom field for leads at the custom side create the custom field now
                                $this->db->insert('tblcustomfields', array(
                                    'fieldto' => $field_to,
                                    'name' => $field->name,
                                    'required' => $field->required,
                                    'type' => $field->type,
                                    'options' => $field->options,
                                    'display_inline' => $field->display_inline,
                                    'field_order' => $field->field_order,
                                    'slug' => slug_it($field_to . '_' . $field->name, array(
                                        'separator' => '_',
                                    )),
                                    'active' => $field->active,
                                    'only_admin' => $field->only_admin,
                                    'show_on_table' => $field->show_on_table,
                                    'bs_column' => $field->bs_column,
                                ));
                                $new_customer_field_id = $this->db->insert_id();
                                if ($new_customer_field_id) {
                                    $copy_custom_field_id = $new_customer_field_id;
                                }
                            }
                            if ($copy_custom_field_id != null) {
                                $insert_to_custom_field_id = $id;
                                if ($value == 4) {
                                    $insert_to_custom_field_id = get_primary_contact_user_id($id);
                                }
                                $this->db->insert('tblcustomfieldsvalues', array(
                                    'relid' => $insert_to_custom_field_id,
                                    'fieldid' => $copy_custom_field_id,
                                    'fieldto' => $field_to,
                                    'value' => $lead_custom_field_value,
                                ));
                            }
                        } elseif ($value == 2) {
                            if (isset($merge_db_fields)) {
                                $db_field = $merge_db_fields[$fieldid];
                                // in case user don't select anything from the db fields
                                if ($db_field == '') {
                                    continue;
                                }
                                if ($db_field == 'country' || $db_field == 'shipping_country' || $db_field == 'billing_country') {
                                    $this->db->where('iso2', $lead_custom_field_value);
                                    $this->db->or_where('short_name', $lead_custom_field_value);
                                    $this->db->or_like('long_name', $lead_custom_field_value);
                                    $country = $this->db->get('tblcountries')->row();
                                    if ($country) {
                                        $lead_custom_field_value = $country->country_id;
                                    } else {
                                        $lead_custom_field_value = 0;
                                    }
                                }
                                $this->db->where('userid', $id);
                                $this->db->update('tblclients', array(
                                    $db_field => $lead_custom_field_value,
                                ));
                            }
                        } elseif ($value == 3) {
                            if (isset($merge_db_contact_fields)) {
                                $db_field = $merge_db_contact_fields[$fieldid];
                                if ($db_field == '') {
                                    continue;
                                }
                                $primary_contact_id = get_primary_contact_user_id($id);
                                $this->db->where('id', $primary_contact_id);
                                $this->db->update('tblcontacts', array(
                                    $db_field => $lead_custom_field_value,
                                ));
                            }
                        }
                    }
                }
                // set the lead to status client in case is not status client
                $this->db->where('isdefault', 1);
                $status_client_id = $this->db->get('tblleadsstatus')->row()->id;
                $this->db->where('id', $data['leadid']);
                $this->db->update('tblleads', array(
                    'status' => $status_client_id,
                ));
                set_alert('success', _l('lead_to_client_base_converted_success'));
                logActivity('Created Lead Client Profile [LeadID: ' . $data['leadid'] . ', ClientID: ' . $id . ']');
                do_action('lead_converted_to_customer', array('lead_id'=>$data['leadid'], 'customer_id'=>$id));
                redirect(admin_url('clients/client/' . $id));
            }
        }
    }

    // Ajax
    /* Used in kanban when dragging */
    public function update_kan_ban_lead_status()
    {
        if ($this->input->post() && $this->input->is_ajax_request()) {
            $this->leads_model->update_lead_status($this->input->post());
        }
    }

    public function update_status_order()
    {
        if ($post_data = $this->input->post()) {
            $this->leads_model->update_status_order($post_data);
        }
    }

    public function add_lead_attachment()
    {
        $id = $this->input->post('id');
        $lastFile = $this->input->post('last_file');

        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($id)) {
            $this->access_denied_ajax();
        }

        handle_lead_attachments($id);
        echo json_encode(array('leadView'=>$lastFile ? $this->_get_lead_data($id) : array(), 'id'=>$id));
    }

    public function add_external_attachment()
    {
        if ($this->input->post()) {
            $this->leads_model->add_attachment_to_database($this->input->post('lead_id'), $this->input->post('files'), $this->input->post('external'));
        }
    }

    public function delete_attachment($id)
    {
        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($id)) {
            $this->access_denied_ajax();
        }
        echo json_encode(array(
            'success' => $this->leads_model->delete_lead_attachment($id),
        ));
    }

    public function delete_note($id)
    {
        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($id)) {
            $this->access_denied_ajax();
        }
        echo json_encode(array(
            'success' => $this->misc_model->delete_note($id),
        ));
    }

    public function update_all_proposal_emails_linked_to_lead($id)
    {
        $success = false;
        $email   = '';
        if ($this->input->post('update')) {
            $this->load->model('proposals_model');

            $this->db->select('email');
            $this->db->where('id', $id);
            $email = $this->db->get('tblleads')->row()->email;

            $proposals     = $this->proposals_model->get('', array(
                'rel_type' => 'lead',
                'rel_id' => $id,
            ));
            $affected_rows = 0;

            foreach ($proposals as $proposal) {
                $this->db->where('id', $proposal['id']);
                $this->db->update('tblproposals', array(
                    'email' => $email,
                ));
                if ($this->db->affected_rows() > 0) {
                    $affected_rows++;
                }
            }

            if ($affected_rows > 0) {
                $success = true;
            }
        }

        echo json_encode(array(
            'success' => $success,
            'message' => _l('proposals_emails_updated', array(
                _l('lead_lowercase'),
                $email,
            )),
        ));
    }

    public function save_form_data()
    {
        $data = $this->input->post();

        // form data should be always sent to the request and never should be empty
        // this code is added to prevent losing the old form in case any errors
        if (!isset($data['formData']) || isset($data['formData']) && !$data['formData']) {
            echo json_encode(array(
                'success' => false,
            ));
            die;
        }
        $this->db->where('id', $data['id']);
        $this->db->update('tblwebtolead', array(
            'form_data' => $data['formData'],
        ));
        if ($this->db->affected_rows() > 0) {
            echo json_encode(array(
                'success' => true,
                'message' => _l('updated_successfully', _l('web_to_lead_form')),
            ));
        } else {
            echo json_encode(array(
                'success' => false,
            ));
        }
    }

    public function form($id = '')
    {
        if (!is_admin()) {
            access_denied('Web To Lead Access');
        }
        if ($this->input->post()) {
            if ($id == '') {
                $data = $this->input->post();
                $id   = $this->leads_model->add_form($data);
                if ($id) {
                    set_alert('success', _l('added_successfully', _l('web_to_lead_form')));
                    redirect(admin_url('leads/form/' . $id));
                }
            } else {
                $success = $this->leads_model->update_form($id, $this->input->post());
                if ($success) {
                    set_alert('success', _l('updated_successfully', _l('web_to_lead_form')));
                }
                redirect(admin_url('leads/form/' . $id));
            }
        }

        $data['formData'] = array();
        $custom_fields    = get_custom_fields('leads', 'type != "link"');

        $cfields          = format_external_form_custom_fields($custom_fields);
        $data['title']    = _l('web_to_lead');

        if ($id != '') {
            $data['form']     = $this->leads_model->get_form(array(
                'id' => $id,
            ));
            $data['title']    = $data['form']->name . ' - ' . _l('web_to_lead_form');
            $data['formData'] = $data['form']->form_data;
        }

        $this->load->model('roles_model');
        $data['roles']    = $this->roles_model->get();
        $data['sources']  = $this->leads_model->get_source();
        $data['statuses'] = $this->leads_model->get_status();

        $data['members'] = $this->staff_model->get('', 1, array(
            'is_not_staff' => 0,
        ));

        $data['languages']           = $this->app->get_available_languages();
        $data['cfields']             = $cfields;
        $data['form_builder_assets'] = true;

        $db_fields = array();
        $fields    = array(
            'name',
            'title',
            'email',
            'phonenumber',
            'company',
            'address',
            'city',
            'state',
            'country',
            'zip',
            'description',
            'website',
        );

        $fields = do_action('lead_form_available_database_fields', $fields);

        $className = 'form-control';

        foreach ($fields as $f) {
            $_field_object = new stdClass();
            $type          = 'text';

            if ($f == 'email') {
                $type = 'email';
            } elseif ($f == 'description' || $f == 'address') {
                $type = 'textarea';
            } elseif ($f == 'country') {
                $type = 'select';
            }

            if ($f == 'name') {
                $label = _l('lead_add_edit_name');
            } elseif ($f == 'email') {
                $label = _l('lead_add_edit_email');
            } elseif ($f == 'phonenumber') {
                $label = _l('lead_add_edit_phonenumber');
            } else {
                $label = _l('lead_' . $f);
            }

            $field_array = array(
                'type' => $type,
                'label' => $label,
                'className' => $className,
                'name' => $f,
            );

            if ($f == 'country') {
                $field_array['values'] = array();
                $countries             = get_all_countries();
                foreach ($countries as $country) {
                    $selected = false;
                    if (get_option('customer_default_country') == $country['country_id']) {
                        $selected = true;
                    }
                    array_push($field_array['values'], array(
                        'label' => $country['short_name'],
                        'value' => (int) $country['country_id'],
                        'selected' => $selected,
                    ));
                }
            }

            if ($f == 'name') {
                $field_array['required'] = true;
            }

            $_field_object->label    = $label;
            $_field_object->name     = $f;
            $_field_object->fields   = array();
            $_field_object->fields[] = $field_array;
            $db_fields[]             = $_field_object;
        }
        $data['bodyclass'] = 'web-to-lead-form';
        $data['db_fields'] = $db_fields;
        $this->load->view('admin/leads/formbuilder', $data);
    }

    public function forms($id = '')
    {
        if (!is_admin()) {
            access_denied('Web To Lead Access');
        }

        if ($this->input->is_ajax_request()) {
            $this->app->get_table_data('web_to_lead');
        }

        $data['title'] = _l('web_to_lead');
        $this->load->view('admin/leads/forms', $data);
    }

    public function delete_form($id)
    {
        if (!is_admin()) {
            access_denied('Web To Lead Access');
        }

        $success = $this->leads_model->delete_form($id);
        if ($success) {
            set_alert('success', _l('deleted', _l('web_to_lead_form')));
        }

        redirect(admin_url('leads/forms'));
    }

    // Sources
    /* Manage leads sources */
    public function sources()
    {
        if (!is_admin()) {
            access_denied('Leads Sources');
        }
        $data['sources'] = $this->leads_model->get_source();
        $data['title']   = 'Leads sources';
        $this->load->view('admin/leads/manage_sources', $data);
    }

    /* Add or update leads sources */
    public function source()
    {
        if (!is_admin() && get_option('staff_members_create_inline_lead_source') == '0') {
            access_denied('Leads Sources');
        }
        if ($this->input->post()) {
            $data = $this->input->post();
            if (!$this->input->post('id')) {
                $inline = isset($data['inline']);
                if (isset($data['inline'])) {
                    unset($data['inline']);
                }

                $id = $this->leads_model->add_source($data);

                if (!$inline) {
                    if ($id) {
                        set_alert('success', _l('added_successfully', _l('lead_source')));
                    }
                } else {
                    echo json_encode(array('success'=>$id ? true : fales, 'id'=>$id));
                }
            } else {
                $id   = $data['id'];
                unset($data['id']);
                $success = $this->leads_model->update_source($data, $id);
                if ($success) {
                    set_alert('success', _l('updated_successfully', _l('lead_source')));
                }
            }
        }
    }

    /* Delete leads source */
    public function delete_source($id)
    {
        if (!is_admin()) {
            access_denied('Delete Lead Source');
        }
        if (!$id) {
            redirect(admin_url('leads/sources'));
        }
        $response = $this->leads_model->delete_source($id);
        if (is_array($response) && isset($response['referenced'])) {
            set_alert('warning', _l('is_referenced', _l('lead_source_lowercase')));
        } elseif ($response == true) {
            set_alert('success', _l('deleted', _l('lead_source')));
        } else {
            set_alert('warning', _l('problem_deleting', _l('lead_source_lowercase')));
        }
        redirect(admin_url('leads/sources'));
    }

    // Statuses
    /* View leads statuses */
    public function statuses()
    {
        if (!is_admin()) {
            access_denied('Leads Statuses');
        }
        $data['statuses'] = $this->leads_model->get_status();
        $data['title']    = 'Leads statuses';
        $this->load->view('admin/leads/manage_statuses', $data);
    }

    /* Add or update leads status */
    public function status()
    {
        if (!is_admin() && get_option('staff_members_create_inline_lead_status') == '0') {
            access_denied('Leads Statuses');
        }
        if ($this->input->post()) {
            $data = $this->input->post();
            if (!$this->input->post('id')) {
                $inline = isset($data['inline']);
                if (isset($data['inline'])) {
                    unset($data['inline']);
                }
                $id = $this->leads_model->add_status($data);
                if (!$inline) {
                    if ($id) {
                        set_alert('success', _l('added_successfully', _l('lead_status')));
                    }
                } else {
                    echo json_encode(array('success'=>$id ? true : fales, 'id'=>$id));
                }
            } else {
                $id   = $data['id'];
                unset($data['id']);
                $success = $this->leads_model->update_status($data, $id);
                if ($success) {
                    set_alert('success', _l('updated_successfully', _l('lead_status')));
                }
            }
        }
    }

    /* Delete leads status from databae */
    public function delete_status($id)
    {
        if (!is_admin()) {
            access_denied('Leads Statuses');
        }
        if (!$id) {
            redirect(admin_url('leads/statuses'));
        }
        $response = $this->leads_model->delete_status($id);
        if (is_array($response) && isset($response['referenced'])) {
            set_alert('warning', _l('is_referenced', _l('lead_status_lowercase')));
        } elseif ($response == true) {
            set_alert('success', _l('deleted', _l('lead_status')));
        } else {
            set_alert('warning', _l('problem_deleting', _l('lead_status_lowercase')));
        }
        redirect(admin_url('leads/statuses'));
    }

    /* Add new lead note */
    public function add_note($rel_id)
    {
        if (!is_staff_member() || !$this->leads_model->staff_can_access_lead($rel_id)) {
            $this->access_denied_ajax();
        }

        if ($this->input->post()) {
            $data = $this->input->post();

            if ($data['contacted_indicator'] == 'yes') {
                $contacted_date         = to_sql_date($data['custom_contact_date'], true);
                $data['date_contacted'] = $contacted_date;
            }

            unset($data['contacted_indicator']);
            unset($data['custom_contact_date']);

            // Causing issues with duplicate ID or if my prefixed file for lead.php is used
            $data['description'] = isset($data['lead_note_description']) ? $data['lead_note_description'] : $data['description'];

            if (isset($data['lead_note_description'])) {
                unset($data['lead_note_description']);
            }

            $note_id = $this->misc_model->add_note($data, 'lead', $rel_id);

            if ($note_id) {
                if (isset($contacted_date)) {
                    $this->db->where('id', $rel_id);
                    $this->db->update('tblleads', array(
                        'lastcontact' => $contacted_date,
                    ));
                    if ($this->db->affected_rows() > 0) {
                        $this->leads_model->log_lead_activity($rel_id, 'not_lead_activity_contacted', false, serialize(array(
                            get_staff_full_name(get_staff_user_id()),
                            _dt($contacted_date),
                        )));
                    }
                }
            }
        }
        echo json_encode(array('leadView'=>$this->_get_lead_data($rel_id), 'id'=>$rel_id));
    }

    public function test_email_integration()
    {
        if (!is_admin()) {
            access_denied('Leads Test Email Integration');
        }

        require_once(APPPATH . 'third_party/php-imap/Imap.php');

        $mail = $this->leads_model->get_email_integration();
        $ps   = $mail->password;
        if (false == $this->encryption->decrypt($ps)) {
            set_alert('danger', _l('failed_to_decrypt_password'));
            redirect(admin_url('leads/email_integration'));
        }
        $mailbox    = $mail->imap_server;
        $username   = $mail->email;
        $password   = $this->encryption->decrypt($ps);
        $encryption = $mail->encryption;
        // open connection
        $imap       = new Imap($mailbox, $username, $password, $encryption);

        if ($imap->isConnected() === false) {
            set_alert('danger', _l('lead_email_connection_not_ok') . '<br /><b>' . $imap->getError() . '</b>');
        } else {
            set_alert('success', _l('lead_email_connection_ok'));
        }

        redirect(admin_url('leads/email_integration'));
    }

    public function email_integration()
    {
        if (!is_admin()) {
            access_denied('Leads Email Intregration');
        }
        if ($this->input->post()) {
            $data = $this->input->post();
            $data['password'] = $this->input->post('password', false);

            if (isset($data['fakeusernameremembered'])) {
                unset($data['fakeusernameremembered']);
            }
            if (isset($data['fakepasswordremembered'])) {
                unset($data['fakepasswordremembered']);
            }

            $success = $this->leads_model->update_email_integration($data);
            if ($success) {
                set_alert('success', _l('leads_email_integration_updated'));
            }
            redirect(admin_url('leads/email_integration'));
        }
        $data['roles']    = $this->roles_model->get();
        $data['sources']  = $this->leads_model->get_source();
        $data['statuses'] = $this->leads_model->get_status();

        $data['members'] = $this->staff_model->get('', 1, array(
            'is_not_staff' => 0,
        ));

        $data['title']   = _l('leads_email_integration');
        $data['mail']    = $this->leads_model->get_email_integration();
        $data['bodyclass']    = 'leads-email-integration';
        $this->load->view('admin/leads/email_integration', $data);
    }

    public function change_status_color()
    {
        if ($this->input->post()) {
            $this->leads_model->change_status_color($this->input->post());
        }
    }

    public function import()
    {
        if (!is_admin() && get_option('allow_non_admin_members_to_import_leads') != '1'){
            access_denied('Leads Import');
        }

        $simulate_data  = array();
        $total_imported = 0;
        if ($this->input->post()) {
            $simulate = $this->input->post('simulate');
            if (isset($_FILES['file_csv']['name']) && $_FILES['file_csv']['name'] != '') {
                // Get the temp file path
                $tmpFilePath = $_FILES['file_csv']['tmp_name'];
                // Make sure we have a filepath
                if (!empty($tmpFilePath) && $tmpFilePath != '') {
                    // Setup our new file path
                    $newFilePath = TEMP_FOLDER . $_FILES['file_csv']['name'];
                    if (!file_exists(TEMP_FOLDER)) {
                        mkdir(TEMP_FOLDER, 777);
                    }
                    if (move_uploaded_file($tmpFilePath, $newFilePath)) {
                        $import_result = true;
                        $fd            = fopen($newFilePath, 'r');
                        $rows          = array();
                        while ($row = fgetcsv($fd)) {
                            $rows[] = $row;
                        }
                        fclose($fd);
                        $data['total_rows_post'] = count($rows);
                        if (count($rows) <= 1) {
                            set_alert('warning', 'Not enought rows for importing');
                            redirect(admin_url('leads/import'));
                        }

                        unset($rows[0]);
                        if ($simulate) {
                            if (count($rows) > 500) {
                                set_alert('warning', 'Recommended splitting the CSV file into smaller files. Our recomendation is 500 row, your CSV file has ' . count($rows));
                            }
                        }
                        $db_temp_fields = $this->db->list_fields('tblleads');
                        array_push($db_temp_fields, 'tags');

                        $db_fields      = array();
                        foreach ($db_temp_fields as $field) {
                            if (in_array($field, $this->not_importable_leads_fields)) {
                                continue;
                            }
                            $db_fields[] = $field;
                        }
                        $custom_fields = get_custom_fields('leads');
                        $_row_simulate = 0;
                        foreach ($rows as $row) {
                            // do for db fields
                            $insert = array();
                            for ($i = 0; $i < count($db_fields); $i++) {
                                // Avoid errors on nema field. is required in database
                                if ($db_fields[$i] == 'name' && $row[$i] == '') {
                                    $row[$i] = '/';
                                } elseif ($db_fields[$i] == 'country') {
                                    if ($row[$i] != '') {
                                        if (!is_numeric($row[$i])) {
                                            $this->db->where('iso2', $row[$i]);
                                            $this->db->or_where('short_name', $row[$i]);
                                            $this->db->or_where('long_name', $row[$i]);
                                            $country = $this->db->get('tblcountries')->row();
                                            if ($country) {
                                                $row[$i] = $country->country_id;
                                            } else {
                                                $row[$i] = 0;
                                            }
                                        }
                                    } else {
                                        $row[$i] = 0;
                                    }
                                }
                                if($row[$i] === 'NULL' || $row[$i] === 'null') {
                                    $row[$i] = '';
                                }
                                $insert[$db_fields[$i]] = $row[$i];
                            }

                            if (count($insert) > 0) {
                                if (isset($insert['email']) && $insert['email'] != '') {
                                    if (total_rows('tblleads', array('email'=>$insert['email'])) > 0) {
                                        continue;
                                    }
                                }
                                $total_imported++;
                                $insert['dateadded']   = date('Y-m-d H:i:s');
                                $insert['addedfrom']   = get_staff_user_id();
                                //   $insert['lastcontact'] = null;
                                $insert['status']      = $this->input->post('status');
                                $insert['source']      = $this->input->post('source');
                                if ($this->input->post('responsible')) {
                                    $insert['assigned'] = $this->input->post('responsible');
                                }
                                if (!$simulate) {
                                    foreach ($insert as $key=>$val) {
                                        $insert[$key] = trim($val);
                                    }
                                    if (isset($insert['tags'])) {
                                        $tags = $insert['tags'];
                                        unset($insert['tags']);
                                    }
                                    $this->db->insert('tblleads', $insert);
                                    $leadid = $this->db->insert_id();
                                } else {
                                    if ($insert['country'] != 0) {
                                        $c = get_country($insert['country']);
                                        if ($c) {
                                            $insert['country'] = $c->short_name;
                                        }
                                    } else {
                                        $insert['country'] = '';
                                    }
                                    $simulate_data[$_row_simulate] = $insert;
                                    $leadid                        = true;
                                }
                                if ($leadid) {
                                    if (!$simulate) {
                                        handle_tags_save($tags, $leadid, 'lead');
                                    }
                                    $insert = array();
                                    foreach ($custom_fields as $field) {
                                        if (!$simulate) {
                                            if ($row[$i] != '' && $row[$i] !== 'NULL' && $row[$i] !== 'null') {
                                                $this->db->insert('tblcustomfieldsvalues', array(
                                                    'relid' => $leadid,
                                                    'fieldid' => $field['id'],
                                                    'value' => trim($row[$i]),
                                                    'fieldto' => 'leads',
                                                ));
                                            }
                                        } else {
                                            $simulate_data[$_row_simulate][$field['name']] = $row[$i];
                                        }
                                        $i++;
                                    }
                                }
                            }
                            $_row_simulate++;
                            if ($simulate && $_row_simulate >= 100) {
                                break;
                            }
                        }
                        unlink($newFilePath);
                    }
                } else {
                    set_alert('warning', _l('import_upload_failed'));
                }
            }
        }
        $data['statuses'] = $this->leads_model->get_status();
        $data['sources']  = $this->leads_model->get_source();

        $data['members'] = $this->staff_model->get('', 1);

        if (count($simulate_data) > 0) {
            $data['simulate'] = $simulate_data;
        }

        if (isset($import_result)) {
            set_alert('success', _l('import_total_imported', $total_imported));
        }

        $data['not_importable'] = $this->not_importable_leads_fields;
        $data['title']          = _l('import');
        $this->load->view('admin/leads/import', $data);
    }

    public function email_exists()
    {
        if ($this->input->post()) {
            // First we need to check if the email is the same
            $leadid = $this->input->post('leadid');

            if ($leadid != '') {
                $this->db->where('id', $leadid);
                $_current_email = $this->db->get('tblleads')->row();
                if ($_current_email->email == $this->input->post('email')) {
                    echo json_encode(true);
                    die();
                }
            }
            $exists = total_rows('tblleads', array(
                'email' => $this->input->post('email'),
            ));
            if ($exists > 0) {
                echo 'false';
            } else {
                echo 'true';
            }
        }
    }

    public function bulk_action()
    {
        if (!is_staff_member()) {
            $this->access_denied_ajax();
        }

        do_action('before_do_bulk_action_for_leads');
        $total_deleted = 0;
        if ($this->input->post()) {
            $ids      = $this->input->post('ids');
            $status   = $this->input->post('status');
            $source   = $this->input->post('source');
            $assigned = $this->input->post('assigned');
            $visibility = $this->input->post('visibility');
            $tags = $this->input->post('tags');
            $last_contact = $this->input->post('last_contact');
            $has_permission_delete = has_permission('leads', '', 'delete');
            if (is_array($ids)) {
                foreach ($ids as $id) {
                    if ($this->input->post('mass_delete')) {
                        if ($has_permission_delete) {
                            if ($this->leads_model->delete($id)) {
                                $total_deleted++;
                            }
                        }
                    } else {
                        if ($status || $source || $assigned || $last_contact || $visibility) {
                            $update = array();
                            if ($status) {
                                // We will use the same function to update the status
                                $this->leads_model->update_lead_status(array(
                                    'status' => $status,
                                    'leadid' => $id,
                                ));
                            }
                            if ($source) {
                                $update['source'] = $source;
                            }
                            if ($assigned) {
                                $update['assigned'] = $assigned;
                            }
                            if ($last_contact) {
                                $last_contact = to_sql_date($last_contact, true);
                                $update['lastcontact'] = $last_contact;
                            }

                            if ($visibility) {
                                if ($visibility == 'public') {
                                    $update['is_public'] = 1;
                                } else {
                                    $update['is_public'] = 0;
                                }
                            }

                            if (count($update) > 0) {
                                $this->db->where('id', $id);
                                $this->db->update('tblleads', $update);
                            }
                        }
                        if ($tags) {
                            handle_tags_save($tags, $id, 'lead');
                        }
                    }
                }
            }
        }
 
        if ($this->input->post('mass_delete')) {
            set_alert('success', _l('total_leads_deleted', $total_deleted));
        }
    }

    private function access_denied_ajax()
    {
        header("HTTP/1.0 404 Not Found");
        echo _l('access_denied');
        die;
    }

    public function get_knowlarity_enquiry(){

        $shiftArray = array();
        $url = knowlarityApiUrl;

        $result = $this->knowlarityCurl($url);
        if(!empty($result)){
            try{
                $knowlarity_enquiry = json_decode($result,true);
                if(!empty($knowlarity_enquiry['objects'])){ 
                        foreach ($knowlarity_enquiry['objects'] as $value) {
                            $shiftArray = $this->storeArray($value);    
                            $descriptionEnquiry = $this->leads_model->get_customfields_details('Description');
                            $audioUrl = $this->leads_model->get_customfields_details('Attachment');
                            $source = $this->leads_model->get_customfields_details('Source');
                            $urgency = $this->leads_model->get_customfields_details('Urgency');
                            $checkinLeads = $this->leads_model->check_knowlarityenquiry_on_leads($shiftArray);
                            if(empty($checkinLeads)){
                                $checkinCustomers = $this->leads_model->check_knowlarityenquiry_on_clients($shiftArray,$source);
                                    if(empty($checkinCustomers)){
                                        $this->addNewLead($shiftArray,$descriptionEnquiry,$audioUrl,$source,$urgency);

                                    }else{
                                        $this->addEnquiryWithCustomer($shiftArray,$checkinCustomers,$descriptionEnquiry,$audioUrl,$source,$urgency);
                                    }

                            }else{
                                $this->addEnquiryWithLead($shiftArray,$descriptionEnquiry,$audioUrl,$source,$urgency);
                                    
                            }
                            
                        }
                $result = array('status' => 1,'message' => 'Success');
                }else{
                    $result = array('status' => 2, 'message' => 'No data found');
                }
            }
            catch(Exception $e){
                $result = array('status' => 0,'message' => $e->getMessage());
            }
            echo json_encode($result);
        }else{
            $result = array('status' => 0,'message' => 'Fail');
            ob_clean();
            echo json_encode($result);
        }
    }


    public function knowlarityCurl($url){


        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");


        $headers = array();
        $headers[] = "Accept: application/json";
        $headers[] = "X-Api-Key:".knowlarityApiKey;
        $headers[] = "Authorization: ".knowlarityAuth;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close ($ch);
        return $result;

    }

    public function storeArray($value){
        $shiftArray = array();
        $shiftArray['status'] = $this->leads_model->get_status_id();
        $shiftArray['source'] = $this->leads_model->get_knowlarity_source_id();
        $shiftArray['phonenumber'] = $value['customer_number'];
        $shiftArray['description'] = 'knowlarity Enquiry answered by our agent number '.$value['agent_number'].' please check audioUrl on enquiry';
        $shiftArray['country'] = 102;
        $shiftArray['url'] = $value['call_recording'];
        $shiftArray['date'] = $value['start_time'];

        return $shiftArray;
    }

    public function addNewLead($shiftArray,$descriptionEnquiry,$audioUrl,$source,$urgency){
        $newleadData = $this->leads_model->add_enquiry_from_knowlarity($shiftArray);
        $isenquiryExist = $this->leads_model->check_knowlarityenquiry_proposals($shiftArray);
            if(empty($isenquiryExist)){

                $newEnquiry = array(
                                    'subject' => 'Knowlarity Enquiry',
                                    'rel_id' => $newleadData,
                                    'rel_type' => 'lead',
                                    'date' => date('Y-m-d H:i:s', strtotime($shiftArray['date'])),
                                    'currency' => 1,
                                    'addedfrom' => 1,
                                    'country' => 102,
                                    'status' => 1,
                                    'phone' => $shiftArray['phonenumber']
                                   );
                $this->proposals_model->add($newEnquiry);
                // Adding description manually here by crm way
                $insertId = $this->leads_model->check_knowlarityenquiry_proposals($shiftArray);
                /*This is to create custom field value*/
                createCustomFieldValue($insertId['id'],$descriptionEnquiry['id'],'proposal',$shiftArray['description']);
                /*This is to create custom field value*/
                createCustomFieldValue($insertId['id'],$audioUrl['id'],'proposal','<a href='.$shiftArray['url'].'>Download</a>');
                /*This is to create custom field value*/
                createCustomFieldValue($insertId['id'],$source['id'],'proposal','knowlarity');
                /*This is to create custom field value*/
                createCustomFieldValue($insertId['id'],$urgency['id'],'proposal','8 hrs');
            
            }
    }

    public function addEnquiryWithCustomer($shiftArray,$checkinCustomers,$descriptionEnquiry,$audioUrl,$source,$urgency){
        
        $isenquiryExist = $this->leads_model->check_knowlarityenquiry_proposals($shiftArray);
        if(empty($isenquiryExist)){

            $customerEnquiry = array('subject' => $shiftArray['title'],
                                     'rel_id' => $checkinCustomers['userid'],
                                     'rel_type' => 'customer',
                                     'date' => date('Y-m-d H:i:s', strtotime($shiftArray['date'])),
                                     'currency' => 1,
                                     'status' => 1,
                                     'country' => 102,
                                     'addedfrom' => 1,
                                     'phone' => $shiftArray['phonenumber']
                                    );
            $this->proposals_model->add($customerEnquiry);
            // Adding description manually here by crm way
            $insertId = $this->leads_model->check_knowlarityenquiry_proposals($shiftArray);
            /*This is to create custom field value*/
            createCustomFieldValue($insertId['id'],$descriptionEnquiry['id'],'proposal',$shiftArray['description']);
            /*This is to create custom field value*/
            createCustomFieldValue($insertId['id'],$audioUrl['id'],'proposal','<a href='.$shiftArray['url'].'>Download</a>');
            /*This is to create custom field value*/
            createCustomFieldValue($insertId['id'],$source['id'],'proposal','knowlarity');
            /*This is to create custom field value*/
            createCustomFieldValue($insertId['id'],$urgency['id'],'proposal','8 hrs');

        }
    }

    public function addEnquiryWithLead($shiftArray,$descriptionEnquiry,$audioUrl,$source,$urgency){
        
        $isenquiryExist = $this->leads_model->check_knowlarityenquiry_proposals($shiftArray);
        if(empty($isenquiryExist)){

            $leadEnquiry = array( 'subject' => $shiftArray['title'],
                                  'rel_id' => $checkinLeads['id'],
                                  'rel_type' => 'lead',
                                  'date' => date('Y-m-d H:i:s', strtotime($shiftArray['date'])),
                                  'currency' => 1,
                                  'status' => 1,
                                  'addedfrom' => 1,
                                  'proposal_to'=> $shiftArray['name'],
                                  'address' => $shiftArray['address'],
                                  'city' => $shiftArray['city'],
                                  'state' => $shiftArray['state'],
                                  'email' => $shiftArray['email'],
                                  'country' => 102,
                                  'phone' => $shiftArray['phonenumber']
                                );
            $this->proposals_model->add($leadEnquiry);   
            // Adding description manually here by crm way
            $insertId = $this->leads_model->check_knowlarity;
            /*This is to create custom field value*/
            createCustomFieldValue($insertId['id'],$descriptionEnquiry['id'],'proposal',$shiftArray['description']);
            /*This is to create custom field value*/
            createCustomFieldValue($insertId['id'],$audioUrl['id'],'proposal','<a href='.$shiftArray['url'].'>Download</a>');
            /*This is to create custom field value*/
            createCustomFieldValue($insertId['id'],$source['id'],'proposal','knowlarity');
            /*This is to create custom field value*/
            createCustomFieldValue($insertId['id'],$urgency['id'],'proposal','8 hrs');
            
        }

    }

    public function commanCurl($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET"); 
        $headers = array(); 
        $headers[] = "Accept: application/json"; 
        $headers[] = "Content-Type: application/json"; 
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); 
        $result = curl_exec($ch); 
        if (curl_errno($ch)) { 
            echo 'Error:' . curl_error($ch); 
        } 
        curl_close ($ch);
        
        return $result;
    }

    public function sdstoreShiftArray($value){
        $url = str_replace('api/', "", apiUrl);
        $shiftArray = array();
        $shiftArray['name'] = !empty($value['user_name']) ? $value['user_name'] : 'Not Available';
        $shiftArray['fakeemailstatus'] = 1;
        $shiftArray['email'] = !empty($value['email_bulk']) ? $value['email_bulk'] : 'sd@email.com';
        $shiftArray['status'] = $this->leads_model->get_status_id();
        $shiftArray['source'] = $this->leads_model->get_sdstore_source_id();
        $shiftArray['phonenumber'] = !empty($value['phone_num']) ? $value['phone_num'] : '';
        $shiftArray['address'] = 'pincode'.$value['pincode'];
        $shiftArray['city'] = '';
        $shiftArray['state'] = '';
        //subject is required field in crm so we are using dummy value for this
        $shiftArray['title'] = !empty($value['product_name']) ? 'Requirement for '.$value['product_name'] : sdBulkEnqtitle;
        //company is required field in crm so we are using dummy value for this
        $shiftArray['company'] = $value['user_name'];
        $shiftArray['country'] = countryCode;
        $qty = !empty($value['enq_qty']) ? 'required quantity is '.$value['enq_qty'] : '';
        $extra = !empty($value['bulk_enquiry_form_id']) ? $qty : '';
        $shiftArray['description'] = $value['message_bulk'].$extra;
        $url = $url.sdBulkEnquiryDocs.$value['bulk_enquiry_form_id'].'/'.$value['file_attached'];
        $attachment = !empty($value['file_attached']) ? $url : '';
        $shiftArray['attachment'] = $attachment;
        $shiftArray['date'] = date('Y-m-d H:i:s');
        $shiftArray['type'] = 0;
        return $shiftArray;
    }

    public function storeShiftArray($value){
        $shiftArray = array();
        //name is mandatory field so we are using dummy value
        $shiftArray['name'] = !empty($value['SENDERNAME']) ? $value['SENDERNAME'] : 'Not Available';
        //email is mandatory field so we are using dummy value 
        $string = str_split('abcdefghijklmnopqrstuvwxyz'.'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.'0123456789!@#$%^&*()'); //any characters
        shuffle($string);
        $rand = '';
        foreach(array_rand($string, 8) as $key) $rand .=$string[$key];
        $name = !empty($value['SENDERNAME']) ? str_replace(' ', '', $value['SENDERNAME']) : '';
        $fakeEmail = !empty($value['SENDERNAME']) ? $name.'@'.$rand.'.com': $rand.'@'.$rand.'.com';
        $shiftArray['fakeemailstatus'] = !empty($value['SENDEREMAIL'])  ? 1  : 0;
        $shiftArray['email'] = !empty($value['SENDEREMAIL']) ? $value['SENDEREMAIL'] : $fakeEmail;
        $shiftArray['status'] = $this->leads_model->get_status_id();
        $shiftArray['source'] = $this->leads_model->get_source_id();
        $shiftArray['phonenumber'] = !empty($value['MOB']) ? $value['MOB'] : '';
        $shiftArray['address'] = !empty($value['ENQ_ADDRESS']) ? $value['ENQ_ADDRESS'] : '';
        $shiftArray['city'] = !empty($value['ENQ_CITY']) ? $value['ENQ_CITY'] : '';
        $shiftArray['state'] = !empty($value['ENQ_STATE']) ? $value['ENQ_STATE'] : '';
        //subject is required field in crm so we are using dummy value for this
        $shiftArray['title'] = !empty($value['SUBJECT']) ? $value['SUBJECT']: 'Subject not available';
        //company is required field in crm so we are using dummy value for this
        $shiftArray['company'] = !empty($value['GLUSR_USR_COMPANYNAME']) ? $value['GLUSR_USR_COMPANYNAME'] : 'Not Available';
        $shiftArray['country'] = 102;
        $shiftArray['description'] = !empty($value['ENQ_MESSAGE']) ? $value['ENQ_MESSAGE'] : '';
        $shiftArray['date'] = !empty($value['DATE_TIME_RE']) ? $value['DATE_TIME_RE'] : date('Y-m-d');
        $shiftArray['type'] = !empty($value['QTYPE']) && $value['QTYPE'] == 'B' ? 1 : 0;
        //[SC-165] Starts
        $shiftArray['org_sender_glusr_id'] = $value['ORG_SENDER_GLUSR_ID'];
        $shiftArray['query_modrefid'] = $value['QUERY_MODREFID'];
        $shiftArray['qtype'] = $value['QTYPE'];
        $shiftArray['date_r'] = $value['DATE_R'];
        //[SC-165] Ends

        return $shiftArray;
    }

    public function addNewIndiamartLead($shiftArray,$descriptionEnquiry,$source,$urgency,$sourcetype, $indiamartApiData = array(), $attachment){
        $newleadData = $this->leads_model->add_enquiry_from_indiamart($shiftArray);    
                    //add enquiry too 
                    // need customize this into one function for code-optimization
        $isenquiryExist = $this->leads_model->check_enquiry_on_proposals($shiftArray);
        if(empty($isenquiryExist)){
            $newEnquiry = array('subject' => $shiftArray['title'],
                                'rel_id' => $newleadData,
                                'rel_type' => 'lead',
                                'date' => date('Y-m-d H:i:s', strtotime($shiftArray['date'])),
                                'currency' => 1,
                                'status' => 1,
                                'addedfrom' => 1,
                                'country' => 102,
                                'proposal_to'=> $shiftArray['name'],
                                'address' => $shiftArray['address'],
                                'city' => $shiftArray['city'],
                                'state' => $shiftArray['state'],
                                'email' => $shiftArray['email'],
                                'phone' => $shiftArray['phonenumber'],
                                'is_buyleads' => $shiftArray['type']
                               );
            $proposalId = $this->proposals_model->add($newEnquiry);
            $indiamartApiDataId = $this->proposals_model->addIndiamartApiData($proposalId, $indiamartApiData);
                        // Adding description manually here by crm way
            if($shiftArray['description'] != ''){
                /*This is to create custom field value*/
                createCustomFieldValue($proposalId,$descriptionEnquiry['id'],'proposal',$shiftArray['description']);
            } 
            /*This is to create custom field value*/
            $sourcetype = ($sourcetype == 'indiamart') ? 'indiamart' : 'sd-store';
            createCustomFieldValue($proposalId,$source['id'],'proposal',$sourcetype);
            /*This is to create custom field value*/
            createCustomFieldValue($proposalId,$urgency['id'],'proposal','8 hrs');
            if(!empty($shiftArray['attachment'])) {
                createCustomFieldValue($proposalId,$attachment['id'],'proposal', '<a href='.$shiftArray['attachment'].'>Download</a>');
            }
        }
    }

    public function addIndiamartEnquiryWithCustomer($shiftArray,$descriptionEnquiry,$checkinCustomers,$source,$urgency,$sourcetype, $indiamartApiData = array(), $attachment){
        $isenquiryExist = $this->leads_model->check_enquiry_on_proposals($shiftArray);
        if(empty($isenquiryExist)){

            $customerEnquiry = array('subject' => $shiftArray['title'],
                                     'rel_id' => $checkinCustomers['userid'],
                                     'rel_type' => 'customer',
                                     'date' => date('Y-m-d H:i:s', strtotime($shiftArray['date'])),
                                     'currency' => 1,
                                     'status' => 1,
                                     'addedfrom' => 1,
                                     'country' => 102,
                                     'proposal_to'=> $shiftArray['name'],
                                     'address' => $shiftArray['address'],
                                     'city' => $shiftArray['city'],
                                     'state' => $shiftArray['state'],
                                     'email' => $shiftArray['email'],
                                     'phone' => $shiftArray['phonenumber'],
                                     'is_buyleads' => $shiftArray['type']
                                    );
            $proposalId = $this->proposals_model->add($customerEnquiry);
            $indiamartApiDataId = $this->proposals_model->addIndiamartApiData($proposalId, $indiamartApiData);
                        // Adding description manually here by crm way
                if($shiftArray['description'] != ''){
                    /*This is to create custom field value*/
                    createCustomFieldValue($proposalId,$descriptionEnquiry['id'],'proposal',$shiftArray['description']);
                }   
                /*This is to create custom field value*/

                $sourcetype = ($sourcetype == 'indiamart') ? 'indiamart' : 'sd-store';
                createCustomFieldValue($proposalId,$source['id'],'proposal',$sourcetype);
                /*This is to create custom field value*/
                createCustomFieldValue($proposalId,$urgency['id'],'proposal','8 hrs');
                if(!empty($shiftArray['attachment'])) {
                    createCustomFieldValue($proposalId,$attachment['id'],'proposal', '<a href='.$shiftArray['attachment'].'>Download</a>');
                }
        }
    }

    public function addIndiamartEnquirywithLead($shiftArray,$descriptionEnquiry,$source,$urgency,$checkinLeads,$sourcetype, $indiamartApiData = array(), $attachment){
        $isenquiryExist = $this->leads_model->check_enquiry_on_proposals($shiftArray);
        if(empty($isenquiryExist)){
                $leadEnquiry = array('subject' => $shiftArray['title'],
                                     'rel_id' => $checkinLeads['id'],
                                     'rel_type' => 'lead',
                                     'date' => date('Y-m-d H:i:s', strtotime($shiftArray['date'])),
                                     'currency' => 1,
                                     'status' => 1,
                                     'addedfrom' => 1,
                                     'country' => 102,
                                     'proposal_to'=> $shiftArray['name'],
                                     'address' => $shiftArray['address'],
                                     'city' => $shiftArray['city'],
                                     'state' => $shiftArray['state'],
                                     'email' => $shiftArray['email'],
                                     'phone' => $shiftArray['phonenumber'],
                                     'is_buyleads' => $shiftArray['type']
                                     );
                $proposalId = $this->proposals_model->add($leadEnquiry);   
                $indiamartApiDataId = $this->proposals_model->addIndiamartApiData($proposalId, $indiamartApiData);
                    // Adding description manually here by crm way
                if($shiftArray['description'] != ''){
                    /*This is to create custom field value*/
                    createCustomFieldValue($proposalId,$descriptionEnquiry['id'],'proposal',$shiftArray['description']);
                }   
                /*This is to create custom field value*/
                $sourcetype = ($sourcetype == 'indiamart') ? 'indiamart' : 'sd-store';
                createCustomFieldValue($proposalId,$source['id'],'proposal',$sourcetype);
                /*This is to create custom field value*/
                createCustomFieldValue($proposalId,$urgency['id'],'proposal','8 hrs');
                if(!empty($shiftArray['attachment'])) {
                    createCustomFieldValue($proposalId,$attachment['id'],'proposal', '<a href='.$shiftArray['attachment'].'>Download</a>');
                }
        }
    }

    public function checkInternetConnection(){
       $connected = fopen("http://www.google.com:80/","r");
       if($connected) return true;
       else return false;
    }

    public function get_sd_store_enquiry(){
        $lastUpdatedDate = $this->proposals_model->getLastUpdatedDate();
        //facing the timestampe issue so we are passing the date only
        $url = !empty($lastUpdatedDate) ? sdstoreApi."'".date("Y-m-d",strtotime($lastUpdatedDate->datecreated))."'" : sdstoreApi."'".date("Y-m-d H:i:s")."'" ;
        $responseData = curl($url,'GET');
        $result = json_decode($responseData['result'],true);

        //here we are checking the golbal bulk enquiry or normal bulk enquiry 
        if(!empty($result)){   
            foreach ($result as $key => $value) {
                $keys = array_keys(array_column($result, 'bulk_enquiry_form_id'),$value['bulk_enquiry_form_id'] );
                 if(!empty($globalEnquiryIds)){    
                    if(!in_array($keys,$globalEnquiryIds)){
                        $globalEnquiryIds[] = count($keys) > 1 ? $keys : '';
                    }
                 }else{
                    $globalEnquiryIds[] = $keys; //
                 }   
            }
            $globalEnquiryIds = array_filter($globalEnquiryIds); //removing empty indexs
            $enquiryKeys= array_reduce($globalEnquiryIds, 'array_merge', array()); // converting into single array from multiple dimensional array
            if($responseData['statusCode'] == successCode || $responseData['statusCode'] == createdCode){
                if(!empty($result)){
                    foreach($globalEnquiryIds as $key => $val){
                        if(is_array($val)){
                            //if its global bulk enquiry we have to add as one enq with products quantity other stuff in description
                            $res = is_array($val) ? $this->addSdstoreGlobalBulkEnquiry($result,$val) : '' ;
                            $globalBulkEnquiry[] = $res;
                        }
                    }
                    
                    foreach($enquiryKeys as $key => $val){
                        unset($result[$val]); //removing the global enquiry indexs from result
                    }
                    //combining the normal enq + global enquiry after converting the two or more enquiry into one enquiry
                    $result = array_values($result);
                    $result = array_merge_recursive($result, $globalBulkEnquiry);
                    
                    foreach($result as $key => $value){
                        $shiftArray = $this->sdstoreShiftArray($value);
                        $res = $this->addEnquiry($shiftArray,'sd-store');
                        logActivity('Enquiry added in crm -'.json_encode($res));
                    }

                    $response = json_encode($res);
                }
                else{
                    $res = array('status' => 2, 'message' => 'success');
                    $response = json_encode($res);
                }
            }else{
                //echo 'Enquiry cannot pulled properly due statusCode'.$result['statusCode'];
                logActivity('Enquiry cannot pulled properly due statusCode'.$responseData['statusCode']);
                $res = array('status' => 0, 'message' => 'Error');
                $response = json_encode($res);
            }
        }
        else{
          $res = array('status' => 2, 'message' => 'success');
          $response = json_encode($res);
        }
        echo $response;
    }

    public function addSdstoreGlobalBulkEnquiry($result,$keys){
        $globalBulkEnquiryFromSdstore = array();
        foreach($keys as $key){
                $productName = !empty($result[$key]['product_name']) ? $result[$key]['product_name'] : 'No Name';
                $productQuantity = !empty($result[$key]['enq_qty']) ? $result[$key]['enq_qty'] : 'N/A';
                $description[] = $result[$key]['message_bulk'].' product name--'.$productName.' and quantity '.$productQuantity." | ";
        }

        $firstKey = $keys[0];
        $url = str_replace('/api', '', apiUrl);
        $globalBulkEnquiryFromSdstore['user_name'] = $result[$firstKey]['user_name'];
        $globalBulkEnquiryFromSdstore['email_bulk'] = $result[$firstKey]['email_bulk'];
        $globalBulkEnquiryFromSdstore['phone_num'] = $result[$firstKey]['phone_num'];
        $globalBulkEnquiryFromSdstore['pincode'] = $result[$firstKey]['pincode'];
        $id = $result[$firstKey]['bulk_enquiry_form_id'];
        $globalBulkEnquiryFromSdstore['bulk_enquiry_form_id'] = $id;
        $globalBulkEnquiryFromSdstore['file_attached'] = $result[$firstKey]['file_attached'];
        $globalBulkEnquiryFromSdstore['message_bulk'] = implode(" ", $description);
        return $globalBulkEnquiryFromSdstore;
    }

    public function get_indiamart_enquiry(){
        $status = $this->checkInternetConnection();
        $shiftArray = array(); //this is to store lead data
        $enquiryValue = array(); // this is to store enquiry data
        $date = date("d-M-Y"); // to get data based on this currentdate from indiamart
        $url = indiamartApiUrl;
        $result = $this->commanCurl($url);
        $indiamartEnquiry = json_decode($result,true); 

        if(is_array($indiamartEnquiry) && !empty($indiamartEnquiry) && !isset($indiamartEnquiry['CODE'])){
            $apiUrl = indiamartPremiumApiUrl;
            $resultData = $this->commanCurl($apiUrl);
            $finalArray = json_decode($resultData,true);
            (is_array($finalArray) && !empty($finalArray) && !isset($finalArray['CODE'])) ?
                $indiamartEnquiry = array_merge($indiamartEnquiry,$finalArray) : '';    

            try{
                foreach($indiamartEnquiry as $value){
                    $shiftArray = $this->storeShiftArray($value);
                    
                    //Passing $value to store returned indiamart api data in 'tblproposals_extra_fields' table
                    $result = $this->addEnquiry($shiftArray,'indiamart', $value);
                }
            }
            catch(Exception $e){
                $result = array('status' => 0,'message' => $e->getMessage());
            }
            echo json_encode($result);
        }else{
            $status = isset($indiamartEnquiry['CODE']) ? $this->errorResponse() : $this->nodataResponse();
            ob_clean();
            echo json_encode($status);
        } 
    }

    public function errorResponse(){
        $result = array('status' => 0, 'message' => 'Server Error or Internet Issue');
        return $result;
    }

    public function nodataResponse(){
        $result = array('status' => 1, 'message' => 'No data found, Already pulled');
        return $result;
    }

    public function addEnquiry($shiftArray,$sourcetype, $indiamartApiData = array()){
        // This for description customly added on crm backend 
        $descriptionEnquiry = $this->leads_model->get_customfields_details('Description');
        //This for status customly added on crm backend (status)
        $source = $this->leads_model->get_customfields_details('Source');
        $urgency = $this->leads_model->get_customfields_details('Urgency');
        $attachment = $this->leads_model->get_customfields_details('Attachment');
        $checkinCustomers = $this->leads_model->check_enquiry_on_clients($shiftArray);
        if(empty($checkinCustomers)){
            $checkinLeads = $this->leads_model->check_enquiry_on_leads($shiftArray);
                if(empty($checkinLeads)){
                    $this->addNewIndiamartLead($shiftArray,$descriptionEnquiry,$source,$urgency,$sourcetype, $indiamartApiData, $attachment);
                }
                else{
                    //need to add enquiry with lead as rel_type 
                    $this->addIndiamartEnquirywithLead($shiftArray,$descriptionEnquiry,$source,$urgency,$checkinLeads,$sourcetype,  $indiamartApiData, $attachment);
                }
        }
        else{
            // need to add enquiry with customer as rel_type and rel_id
            $this->addIndiamartEnquiryWithCustomer($shiftArray,$descriptionEnquiry,$checkinCustomers,$source,$urgency,$sourcetype,  $indiamartApiData, $attachment);
        }
        $result = array('status' => 1, 'message' => 'success');
        return $result;
    }

    public function mailChimpLeadsPush(){
       $leadsData = $this->leads_model->get_leads_data();
        //Mailchimp api credentials
       $apiKey = mailChimpApiKey;
       $listId = mailChimpUniqueKey;

       foreach($leadsData as $data){
             //Mailchimp api url
            $memberId = md5(strtolower($data['email']));
            $dataCenter = substr($apiKey,strpos($apiKey,'-')+1);
            $url = 'https://' . $dataCenter . '.api.mailchimp.com/3.0/lists/' . $listId . '/members/' . $memberId;
             //Member information
            $payload = json_encode([
                                    'email_address' => $data['email'],
                                    'status' => 'subscribed',
                                    'merge_fields' =>[
                                                        'FNAME' => $data['proposal_to'],
                                                        'ADDRESS1' => 'test',
                                                        'PHONE' => $data['phone']
                                                    ]
                                    ]);
            $this->mailChimpCurl($url, $apiKey, $payload, $data);
       }
    }

    public function mailChimpCurl($url, $apiKey, $payload, $data){
        // send a HTTP POST request with curl
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_USERPWD, 'user:' . $apiKey);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            $result = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if($httpCode == 200){
                logActivity('Lead '.$data['email'].' pushed to mailchimp successfully');
            } else {
                logActivity('Lead '.$data['email'].'not pushed to mailchimp due to following error code'.$httpCode);
            }
    }

    function uploadBulk(){
        $filename = time().'-'.$_FILES["File_Upload"]["name"];
        $temp_url = './uploads/leads/'.$filename;
        if (move_uploaded_file($_FILES["File_Upload"]["tmp_name"], $temp_url)) {
            // This for description customly added on crm backend 
            $descriptionEnquiry = $this->leads_model->get_customfields_details('Description');
            //This for status customly added on crm backend (status)
            $source = $this->leads_model->get_customfields_details('Source');
            $urgency = $this->leads_model->get_customfields_details('Urgency');
            //$this->addNewIndiamartLead($shiftArray,$descriptionEnquiry,$source,$urgency);

            $allLeadArray = array();
            $handle = fopen($temp_url,"r");
            $i = 1;
            while (($row = fgetcsv($handle, 10000, ",")) != FALSE){
                if($i > 1){
                    $dateadded = $row[0]?date('Y-m-d H:i:s',strtotime($row[0])):date('Y-m-d H:i:s');
                    $leadRow = array("dateadded" => $dateadded,
                                    "name" => $row[1],
                                    "company" => $row[2],
                                    "title" => $row[3],
                                    "description" => $row[3],
                                    "address" => $row[4],                                    
                                    'country' => 102,
                                    "city" => $row[4],
                                    "email" => $row[5], 
                                    'status' =>  $this->leads_model->get_status_id(),
                                    'source' =>  $this->leads_model->get_source_id(),
                                    'state' => '',
                                    "phonenumber" => $row[6],
                                    'assigned' => $row[7]);

                    array_push($allLeadArray, $leadRow);
                }
                $i++;
            }
            fclose($handle);
            unlink($temp_url);

            foreach ($allLeadArray as $shiftArray) {
                $newleadId = $this->leads_model->add_enquiry_from_indiamart($shiftArray);
                //add enquiry too 
                // need customize this into one function for code-optimization
                $isenquiryExist = $this->leads_model->check_enquiry_on_proposals($shiftArray);
                if(empty($isenquiryExist)){
                    $this->load->model('staff_model');
                    $staff = $this->staff_model->getStaffIdByEmail($shiftArray['assigned']);

                    $newEnquiry = array('subject' => $shiftArray['title'],
                                    'rel_id' => $newleadId,
                                    'rel_type' => 'lead',
                                    'date' => $shiftArray['dateadded'],
                                    'currency' => 1,
                                    'status' => 1,
                                    'addedfrom' => 1,
                                    'assigned' => $staff?$staff->staffid:1,
                                    'country' => 102,
                                    'proposal_to'=> $shiftArray['name'],
                                    'address' => $shiftArray['address'],
                                    'city' => $shiftArray['address'],
                                    'state' => $shiftArray['state'],
                                    'email' => $shiftArray['email'],
                                    'phone' => $shiftArray['phonenumber']
                                   );
                    $proposalId = $this->proposals_model->add($newEnquiry);

                    /*the enquiry make into completed status*/
                    $data = array('status' => 4);
                    $this->db->where('id', $proposalId);
                    $this->db->update('tblproposals', $data);

                    // Adding description manually here by crm way                    
                    if($shiftArray['description'] != ''){
                        /*This is to create custom field value*/
                        createCustomFieldValue($proposalId,$descriptionEnquiry['id'],'proposal',$shiftArray['description']);
                    } 
                    /*This is to create custom field value*/
                    createCustomFieldValue($proposalId,$source['id'],'proposal','indiamart');
                    /*This is to create custom field value*/
                    createCustomFieldValue($proposalId,$urgency['id'],'proposal','8 hrs');
                }
            }
            $result = array("status" => "200", "message" => "response");
        }      
        echo json_encode($result);
    }
}
//note function with camel case are reused function created by jagan, function with ex:test_func_call is main function calling from ajax or model from view crm way.