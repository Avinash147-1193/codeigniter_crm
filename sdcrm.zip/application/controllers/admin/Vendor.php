<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Vendor extends Admin_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('vendors_model');
        $this->load->model('currencies_model');
        $this->load->helper('constant_helper');
        $this->load->helper('common_helper');
    }

    public function index($page = ''){
        if (!has_permission('vendor_list', '', 'view')) {
            access_denied('vendor_list');
        }
        $data['vendors'] = $this->vendors_model->get_all_adhoc_vendors();
        $data['categories'] = $this->vendors_model->get_all_categories();
        $data['page'] = $page;
        $this->load->view('admin/vendor/list', $data);
    }

    public function add(){
        if (!has_permission('vendor_list', '', 'create')) {
            access_denied('vendor_list');
        }
        $data = $this->input->post();
        $result = $this->vendors_model->add_vendor($data);
        if(!empty($result)){
            $response = 1;
        } else{
            $response = 0;
        }
        echo json_encode($response);
    }

    public function uploadBulk(){
      $filename = time().'-'.$_FILES["File_Upload"]["name"];
      $temp_url = './uploads/vendors/'.$filename;
      $result = '';
      if (move_uploaded_file($_FILES["File_Upload"]["tmp_name"], $temp_url)) {
          $handle = fopen($temp_url,"r");
          $i = 1;
          while (($row = fgetcsv($handle, 10000, ",")) != FALSE){
            if($i > 1){
              //NEED TO CHANGE THE CATEGORY BECAUSE NOW ITS MULTIPLE CATEGORY SO WILL HAVE TO PASS CATEGORY ARRAY TO add_vendor FUNCTION
              $vendorRow = array("category" => $row[0],
                                "phone" => $row[1],
                                "firstname" => $row[2],
                                "email" => $row[3],
                                "companyname" => $row[4]);
              $result = $this->vendors_model->add_vendor($vendorRow);
              if(!empty($result)){
                $response = 1;
              }else{
                $response = 0;
              }
            }
            $i++;
          }
          fclose($handle); 
          // Delete uploaded file
          unlink($temp_url);
      } else {
          set_alert('danger', _l('error_uploading_file'));
      }
      echo json_encode($result);
    }

    public function edit($id, $page){
        if (!has_permission('vendor_list', '', 'edit')) {
            access_denied('vendor_list');
        }
        $data['categories'] = $this->vendors_model->get_all_categories();
        $data['vendor'] = $this->vendors_model->get_vendor($id);
        $data['vendor_categories'] = $this->vendors_model->get_vendor_categories($id);
        $data['page'] = $page;
        $this->load->view('admin/vendor/edit',$data);

    }

    public function update($page = ''){
        if (!has_permission('vendor_list', '', 'edit')) {
            access_denied('vendor_list');
        }
        
        if(!empty($this->input->post() )){
          $data = $this->input->post();
          $result = $this->vendors_model->update_vendor($data);
        }else{
          $data['page'] = '';
        }
        $data['page'] = $page;
        $this->load->view('admin/vendor/list', $data);
    }

    public function remove($page = ''){
        if (!has_permission('vendor_list', '', 'delete')) {
            access_denied('vendor_list');
        }
        $id = $_POST['id'];
        $this->index($page);
        if($id != ''){
            $this->vendors_model->remove_vendor($id);
            echo "success";
        }else{
            echo "fail";
        }
    } 

    public function get(){
        // Datatables Variables
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));
          $category = $this->input->get('category');

          $vendors = $this->vendors_model->get_all_adhoc_vendors()->result();

          $data = array();
          $i = 1;

          foreach ($vendors as $key => $vendor) {
            $categories = $this->vendors_model->get_all_categories($vendor->id);
            $mappedtoData = $this->vendors_model->get_status($vendor->id);
            $mappedto = !empty($mappedtoData) ? 'SD-STORE' : 'CRM';
            $commaSeparatedCategory = '';
            foreach ($categories as $key => $category) {
              $commaSeparatedCategory .= $category['category'].', ';
            }
            
            $editBtn = "";
            $deleteBtn = "";
            if (has_permission('vendor_list', '', 'edit')) {
                $editBtn = '<a  onclick="current_page('.$vendor->id.')" class="editor_edit"><span style="cursor:pointer;" class="glyphicon glyphicon-edit"></span></a>';
            }
            if (has_permission('vendor_list', '', 'delete')) {
                $deleteBtn = '<a id="delete" class="editor_remove"><span style="cursor:pointer;" onclick="remove('.$vendor->id.')" class="glyphicon glyphicon-remove" id="delete"></a>';
            }
             $result = array(
                              'vendor' => $i,
                              'name' => $vendor->companyname,
                              'category' => rtrim($commaSeparatedCategory,', '),
                              'phone' => $vendor->phone,
                              'sdentity' => $vendor->sd_entity,
                              'shipmenttype' => $vendor->shipment_type,
                              'mappedto' => $mappedto,
                              'city' => $vendor->city,
                              'action' => $editBtn.'&nbsp;&nbsp;'.$deleteBtn
                            );
             $data[] = $result;
             $i++;
          }

          $output = array(
                 "draw" => $draw,
                 "recordsTotal" => count($vendors),
                 "recordsFiltered" => count($vendors),
                 "data" => $data
            );
          echo json_encode($output);
    }


    public function getVendorsByCategory(){
      $responseArray = array();
      foreach ($this->input->post('category') as $key => $singleCategory) {
        $vendors = $this->vendors_model->get_all_vendors($singleCategory)->result_array();
        if($vendors != null){
          foreach($vendors as $vendor){
            if(!array_key_exists($vendor['id'], $responseArray)){
              $responseArray[$vendor['id']] = array("id" => $vendor['id'], "text" => $vendor['companyname']);
            }
          }
        }
      }
      echo json_encode($responseArray,true);
    }

    public function updatemissingfields(){
      $vendorId = $_POST['vendorId'];
      $category_ids = $_POST['category_ids'];
      unset($_POST['vendorId']);
      unset($_POST['category_ids']);
      $status = $this->vendors_model->update_vendor_by_id($category_ids, $vendorId, $_POST);
      echo json_encode($status);
    }

    public function updatemissingfieldsforsdstore(){
      $url = update_vendor_api.$_POST['vendorId'];
      $data = array('contact_name'=>$_POST['firstname'], 
                    'company'=>$_POST['companyname'],
                    'sd_entity'=>$_POST['sd_entity'],
                    'shipment_type'=>$_POST['shipment_type'],
                    'zipcode'=>$_POST['zip_postal_code'],
                    'address'=>$_POST['address'],
                    'vat_number'=>$_POST['gstin'],
                    'phone'=>$_POST['phone'],
                    'city'=>$_POST['city'],
                    'state'=>$_POST['state']);

      $data_json = json_encode($data);
      $curl = curl_init();
      curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "PUT",
        CURLOPT_POSTFIELDS => $data_json,
        CURLOPT_HTTPHEADER => array(
          "Authorization:".apiToken,
          "Content-Type: application/json"
        ),
      ));
      $response = curl_exec($curl);
      $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
      curl_close($curl);
      if($httpcode == 200 || $httpcode == 304){
        echo json_encode(true);
      }
      else{
        $status = array('statusCode' => $httpcode, 'status' => false);
        echo json_encode($status);
      }
    }
    
}
