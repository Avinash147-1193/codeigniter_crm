<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends Admin_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('dashboard_model');
        $this->load->helper('chart_helper');
    }

    //[SC-130] Commented due to production push
    public function chartFilter(){
        $postData = $this->input->post();
        $date_from = date('Y-m-d', $postData['date_from']/1000);
        $date_to = date('Y-m-d', $postData['date_to']/1000);
        if(isset($postData['staff'])){
            $staff = $postData['staff'];
            if($postData['type'] == 'proposal'){
                $proposals_stacked_data = $this->dashboard_model->pieAndStackedChartData('stacked', 'proposals', $date_from, $date_to, $staff);
                $proposals_pie_data = $this->dashboard_model->pieAndStackedChartData('pie', 'proposals', $date_from, $date_to, $staff);
                echo json_encode(array('proposalStackedData' => $proposals_stacked_data, 'proposalPieData' => getPieChartData($proposals_pie_data)));
            }elseif($postData['type'] == 'quote'){
                $quotes_stacked_data = $this->dashboard_model->pieAndStackedChartData('stacked', 'quotes', $date_from, $date_to, $staff);
                $quotes_pie_data = $this->dashboard_model->pieAndStackedChartData('pie', 'quotes', $date_from, $date_to, $staff);

                //staff margin
                $staff_gross_margin_value = $this->dashboard_model->staffGrossMarginValue($date_from, $date_to, $staff);

                //total margin
                $total_gross_margin_value = $this->dashboard_model->grossMarginValue($date_from, $date_to,'estimates','estimate');

                //combine the result into single object
                $gross_margin_value = (object) array_merge((array) $staff_gross_margin_value, (array) $total_gross_margin_value); // combining two objects

                $gross_margin_value->staffMarginPercentage = isset($gross_margin_value->staffmargin) ? $gross_margin_value->staffmargin : 0.00;

                //calculating the staff margin
                $gross_margin_value->staffmargin = !empty($staff_gross_margin_value) ? ($staff_gross_margin_value->staffgrossmargin/$total_gross_margin_value->sp) * 100 : 0.00;

                echo json_encode(array('quoteStackedData' => $quotes_stacked_data, 'quotesPieData' => getPieChartData($quotes_pie_data), 'grossMarginValue' => $gross_margin_value));
            }elseif($postData['type'] == 'invoice'){
                $inovices_stacked_data = $this->dashboard_model->pieAndStackedChartData('stacked', 'invoices', $date_from, $date_to, $staff);
                $inovices_pie_data = $this->dashboard_model->pieAndStackedChartData('pie', 'invoices', $date_from, $date_to, $staff);

                //staff margin
                $staff_gross_margin_value = $this->dashboard_model->staffOrderGrossMarginValue($date_from, $date_to, $staff);

                //total margin
                $total_gross_margin_value = $this->dashboard_model->grossMarginValue($date_from, $date_to,'invoices','invoice');

                //combine the result into single object
                $gross_margin_value = (object) array_merge((array) $staff_gross_margin_value, (array) $total_gross_margin_value); 

                // combining two objects
                $gross_margin_value->staffMarginPercentage = isset($gross_margin_value->staffmargin) ? $gross_margin_value->staffmargin : 0.00;

                //calculating the staff margin
                $gross_margin_value->staffmargin = !empty($staff_gross_margin_value) ? ($staff_gross_margin_value->staffgrossmargin/$total_gross_margin_value->sp) * 100 : 0 ;


                echo json_encode(array('invoiceStackedData' => $inovices_stacked_data, 'inovicesPieData' => getPieChartData($inovices_pie_data), 'ordersMarginValue' => $gross_margin_value));
            }elseif($postData['type'] == 'task'){
                $tasks_stacked_data = $this->dashboard_model->pieAndStackedChartData('stacked', 'tasks', $date_from, $date_to, $staff);
                $tasks_pie_data = $this->dashboard_model->pieAndStackedChartData('pie', 'tasks', $date_from, $date_to, $staff);

                echo json_encode(array('taskStackedData' => $tasks_stacked_data, 'tasksPieData' => getPieChartData($tasks_pie_data)));
            }elseif($postData['type'] == 'conversion'){
                $all_count = $this->dashboard_model->allCount($date_from, $date_to, $staff);
                echo json_encode($all_count);
            }elseif($postData['type'] == 'top_customers'){
                $customers_data = $this->dashboard_model->top10Customers($date_from, $date_to, $staff);
                echo json_encode($customers_data);
            }
        }else{
            $staff = array();

            $all_count = $this->dashboard_model->allCount($date_from, $date_to, $staff);
            $proposals_stacked_data = $this->dashboard_model->pieAndStackedChartData('stacked', 'proposals', $date_from, $date_to, $staff);
            $quotes_stacked_data = $this->dashboard_model->pieAndStackedChartData('stacked', 'quotes', $date_from, $date_to, $staff);
            $inovices_stacked_data = $this->dashboard_model->pieAndStackedChartData('stacked', 'invoices', $date_from, $date_to, $staff);
            $tasks_stacked_data = $this->dashboard_model->pieAndStackedChartData('stacked', 'tasks', $date_from, $date_to, $staff);
            $proposals_pie_data = $this->dashboard_model->pieAndStackedChartData('pie', 'proposals', $date_from, $date_to, $staff);
            $quotes_pie_data = $this->dashboard_model->pieAndStackedChartData('pie', 'quotes', $date_from, $date_to, $staff);
            $inovices_pie_data = $this->dashboard_model->pieAndStackedChartData('pie', 'invoices', $date_from, $date_to, $staff);
            $tasks_pie_data = $this->dashboard_model->pieAndStackedChartData('pie', 'tasks', $date_from, $date_to, $staff);

            $stacked_data = $this->dashboard_model->stackedData($date_from, $date_to, $staff);
            $customers_data = $this->dashboard_model->top10Customers($date_from, $date_to, $staff);
            $staff_peroformance = $this->dashboard_model->staffPeroformance($date_from, $date_to, $staff);
            /*start of jagan code*/
            //quote margin
            $gross_margin_value = $this->dashboard_model->grossMarginValue($date_from, $date_to,'estimates','estimate');
            //orders margin
            $orders_margin_value = $this->dashboard_model->grossMarginValue($date_from, $date_to,'invoices','invoice');
            /*end of jagan code*/
            echo json_encode(array('allCount' => $all_count, 'stackedData' => $stacked_data['stackedData'], 'staffPeroformanceData' => $staff_peroformance['stackedData'], 'proposalStackedData' => $proposals_stacked_data, 'quotesStackedData' => $quotes_stacked_data, 'invoicesStackedData' => $inovices_stacked_data, 'tasksStackedData' => $tasks_stacked_data, 'proposalPieData' => getPieChartData($proposals_pie_data), 'quotesPieData' => getPieChartData($quotes_pie_data), 'invoicesPieData' => getPieChartData($inovices_pie_data), 'tasksPieData' => getPieChartData($tasks_pie_data), 'customersData' => $customers_data, 'grossMarginValue' => $gross_margin_value, 'ordersMarginValue' => $orders_margin_value));
        }
    }

    /* This is admin dashboard view */
    public function index()
    {
        close_setup_menu();

        $this->load->model('departments_model');
        $this->load->model('todo_model');
        $data['departments']               = $this->departments_model->get();

        $data['todos']                     = $this->todo_model->get_todo_items(0);
        // Only show last 5 finished todo items
        $this->todo_model->setTodosLimit(5);
        $data['todos_finished']            = $this->todo_model->get_todo_items(1);
        $data['upcoming_events_next_week'] = $this->dashboard_model->get_upcoming_events_next_week();
        $data['upcoming_events']           = $this->dashboard_model->get_upcoming_events();
        $data['title']                     = _l('dashboard_string');
        $this->load->model('currencies_model');
        $data['currencies']                           = $this->currencies_model->get();
        $data['base_currency']                        = $this->currencies_model->get_base_currency();
        $data['activity_log']                         = $this->misc_model->get_activity_log();
        // Tickets charts
        $tickets_awaiting_reply_by_status = $this->dashboard_model->tickets_awaiting_reply_by_status();
        $tickets_awaiting_reply_by_department = $this->dashboard_model->tickets_awaiting_reply_by_department();

        $data['tickets_reply_by_status']              = json_encode($tickets_awaiting_reply_by_status);
        $data['tickets_awaiting_reply_by_department'] = json_encode($tickets_awaiting_reply_by_department);

        $data['tickets_reply_by_status_no_json']              = $tickets_awaiting_reply_by_status;
        $data['tickets_awaiting_reply_by_department_no_json'] = $tickets_awaiting_reply_by_department;

        $data['projects_status_stats']                = json_encode($this->dashboard_model->projects_status_stats());
        $data['leads_status_stats']                   = json_encode($this->dashboard_model->leads_status_stats());
        $data['google_ids_calendars']                 = $this->misc_model->get_google_calendar_ids();
        $data['bodyclass']                            = 'home dashboard invoices_total_manual';
        $this->load->model('announcements_model');
        $data['staff_announcements'] = $this->announcements_model->get();
        $data['total_undismissed_announcements'] = $this->announcements_model->get_total_undismissed_announcements();

        $data['goals'] = array();
        if (is_staff_member()) {
            $this->load->model('goals_model');
            $data['goals'] = $this->goals_model->get_staff_goals(get_staff_user_id());
        }

        $this->load->model('projects_model');
        $data['projects_activity'] = $this->projects_model->get_activity('', do_action('projects_activity_dashboard_limit', 20));
        // To load js files
        $data['calendar_assets']   = true;
        $this->load->model('utilities_model');
        $this->load->model('estimates_model');
        $data['estimate_statuses'] = $this->estimates_model->get_statuses();

        $this->load->model('proposals_model');
        $data['proposal_statuses'] = $this->proposals_model->get_statuses();

        $wps_currency = 'undefined';
        if (is_using_multiple_currencies()) {
            $wps_currency = $data['base_currency']->id;
        }
        $data['weekly_payment_stats'] = json_encode($this->dashboard_model->get_weekly_payments_statistics($wps_currency));

        $data['dashboard']             = true;

        $data['user_dashboard_visibility'] = $GLOBALS['current_user']->dashboard_widgets_visibility;

        if($GLOBALS['current_user']->role == 0){
            $staffSql = 'SELECT staffid,CONCAT(firstname," ",lastname) as fullname FROM tblstaff WHERE role IN(3,4)';
            $data['vendorStaffData'] = $this->db->query($staffSql)->result_array();

            $staffSql = 'SELECT staffid,CONCAT(firstname," ",lastname) as fullname FROM tblstaff WHERE role IN(0,1,2)';
            $data['staffData'] = $this->db->query($staffSql)->result_array();
        }elseif($GLOBALS['current_user']->role == 4){
            $staffSql = 'SELECT staffid,CONCAT(firstname," ",lastname) as fullname FROM tblstaff WHERE role IN("'.$GLOBALS['current_user']->role.'", 3)';
            $data['vendorStaffData'] = $this->db->query($staffSql)->result_array();
        }
        $data['staffRole'] = $GLOBALS['current_user']->role;

        if (!$data['user_dashboard_visibility']) {
            $data['user_dashboard_visibility'] = array();
        } else {
            $data['user_dashboard_visibility'] = unserialize($data['user_dashboard_visibility']);
        }
        $data['user_dashboard_visibility'] = json_encode($data['user_dashboard_visibility']);

        $data = do_action('before_dashboard_render', $data);
        $this->load->view('admin/dashboard/dashboard', $data);
    }

    /* Chart weekly payments statistics on home page / ajax */
    public function weekly_payments_statistics($currency)
    {
        if ($this->input->is_ajax_request()) {
            echo json_encode($this->dashboard_model->get_weekly_payments_statistics($currency));
            die();
        }
    }
}
