<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Brands extends Admin_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('brands_model');
        $this->load->helper('download');
        $this->load->model('vendors_model');
    }

    /* Get index page */
    public function index($id = '')
    {
      $this->load->view('admin/brands/list');    
    }

    public function ordersList(){
      $this->load->view('admin/orders/orderlist'); 
    }

    public function getAllsalesAgentOrders(){
      $id = !empty($_POST['salesAgentId']) ? $_POST['salesAgentId'] : $this->session->userdata('staff_user_id');
      $orders = $this->brands_model->get_salesagent_all_unnotified_orders($id);
      echo json_encode($orders);
    }

    public function updateAllsalesAgentOrders(){
      $id = !empty($_POST['salesAgentId']) ? $_POST['salesAgentId'] : $this->session->userdata('staff_user_id');
      $orderId = $_POST['orderId'];
      $res = $this->brands_model->update_salesagent_orders_individually($id, $orderId);
      echo json_encode($res);
    }

    public function updateSalesAgentOrders(){
      $id = !empty($_POST['salesAgentId']) ? $_POST['salesAgentId'] : $this->session->userdata('staff_user_id');;
      $updateOrders = $this->brands_model->update_salesagent_orders($id);
      echo json_encode($updateOrders);
    } 

    public function orders(){
      // Datatables Variables
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));
          $salesAgentId = $this->session->userdata('staff_user_id');
          $orders = $this->brands_model->get_all_orders($salesAgentId);
          $data = array();
          $i = 1;

          foreach ($orders as $key => $order) {
            $invoiceDetails = $this->brands_model->get_invoice_data($order['crm_invoice_id']);
            $url = base_url().'admin/invoices/list_invoices#'.$invoiceDetails->id;
            $piNumber = 'PI-'.$invoiceDetails->number;
            $customerName = $this->brands_model->get_customer_name($order['client_email']);

            $productError = !empty($order['product_error']) ? $order['product_error'] : 'No issue';
            $userError = !empty($order['user_error']) ? $order['user_error'] : 'No issue';
            $orderError = !empty($order['order_error']) ? $order['order_error'] : 'No issue';
                      
            $result = array(
                              'Od' => $i,
                              'PI Number' => '<a target="_blank" href='.$url.'>'.$piNumber.'</a>',
                              'Reference Number' => $order['queue_reference_number'],
                              'Order Id' => !empty($order['sd_store_order_id']) 
                                            ?'<p class="text-success">'.'OD'.$order['sd_store_order_id'] . '</p>' 
                                            : (empty($order['error_response']) 
                                              ? '<p class="text-warning">Processing</p>' 
                                              : '<p class="text-danger">N/A</p>' ),
                              'Order Status' => empty($order['sd_store_order_id']) &&
                                                empty($order['error_response']) 
                                                ? '<p class="label label-warning">Pending</p>' 
                                                :(empty($order['error_response']) 
                                                  ? '<p class="label label-success">Placed</p>'
                                                  : '<p class="label label-danger">Failed</p>'
                                                 ) ,
                              'Order Log' => !empty($order['error_response']) 
                                              ?
                                                '<span class="badge text-danger">products</span>'.' - '.$productError.
                                                '<br><span class="badge text-danger">users</span>'.' - '.$userError.
                                                '<br><span class="badge text-danger">orders</span>'.' - '.$orderError 
                                              : 'N/A',
                              'Customer Email' => $order['client_email'],
                              'Customer Name' => $customerName
                            );
             $data[] = $result;
             $i++;
          }

          $output = array(
                 "draw" => $draw,
                 "recordsTotal" => count($orders),
                 "recordsFiltered" => count($orders),
                 "data" => $data
            );
          echo json_encode($output);
    }

    public function bulkUpload(){
        if(!empty($_FILES['file']['name'])){ 
            $response = $this->bulkUploadAction($_FILES);
            if($response['status'] == 1){
                $importData_arr = $response['importData_arr'];
                $filename = $response['filename'];
                $skip = 0;

                // insert import data
                foreach($importData_arr as $brand){
                    if($skip != 0){
                        $result = $this->brands_model->insert_brand($brand); // need to change this logic
                    }
                    $skip ++;
                }
                if(!empty($result)){
                    // need to change this check logic
                    set_alert('success','successfully uploaded '.$filename);
                } else{
                    set_alert('danger','These data uploaded already');    
                }
                $response = array('status' => 1, 'message' => 'Success');  
            } else{
                set_alert('danger','Something went wrong');
                $response = array('status' => 0, 'message' => 'Error');
            }
        }else{
            set_alert('danger','File upload error');
            $response = array('status' => 0, 'message' => 'Error');
        }
        redirect(base_url('brands')); 
        //$this->load->view('admin/brands/list',$response);
    }

    public function uploadDataFromSheet(){
      if(!empty($_FILES['file']['name'])){ 
            $response = $this->bulkUploadAction($_FILES);
            if($response['status'] == 1){
                $importData_arr = $response['importData_arr'];
                $filename = $response['filename'];
                $skip = 0;

                // insert import data
                foreach($importData_arr as $data){
                    if($skip != 0){
                      if( !empty($data[0]) && !empty($data[1]) && !empty($data[2]) ){
                        $result = $this->brands_model->update_adhocproduct_data_from_sdtore_crm($data); // need to change this logic
                      } else{
                        $result = '';
                      }
                    }
                    $skip ++;
                }
                if($result != 0){
                    // need to change this check logic
                    set_alert('success','successfully uploaded '.$filename);
                } else{
                    set_alert('danger','Some data not found! Updated Partially Check Activity Log');    
                }
                $response = array('status' => 1, 'message' => 'Success');  
            } else{
                set_alert('danger','Something went wrong');
                $response = array('status' => 0, 'message' => 'Error');
            }
      }else{
            set_alert('danger','File upload error');
            $response = array('status' => 0, 'message' => 'Error');
      }
      redirect(base_url('uploadSheet'));
    }

    public function bulkUploadAction(){
      // Set preference 
         $data['upload_path'] = $this->config->item('upload_path'); 
         $data['allowed_types'] = $this->config->item('allowed_types'); 
         $data['max_size'] = $this->config->item('max_size'); // max_size in kb 
         $data['file_name'] = $_FILES['file']['name'];

         // Load upload library 
         $this->load->library('upload',$data); 
 
         // File upload
            if($this->upload->do_upload('file')){ 
                // Get data about the file
                $uploadData = $this->upload->data(); 
                $filename = $uploadData['file_name'];

                // Reading file
                $file = fopen("assets/files/".$filename,"r");
                $tempUrl = './assets/files/'.$filename;
                $i = 0;

                $importData_arr = array();
     
                while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
                   $num = count($filedata );

                   for ($c=0; $c < $num; $c++) {
                      $importData_arr[$i][] = $filedata [$c];
                   }
                   $i++;
                }
                fclose($file);
                // Delete uploaded file
                unlink($tempUrl);
                $response = array('status' => 1, 'importData_arr' => $importData_arr,'filename'=> $filename);
            }
            else {
                $error = $this->upload->display_errors();
                
                $response = array('status' => 0, 'message' => 'Upload Failed');
            }

            return $response;
    }

    public function uploadVendorInvoice(){
      //this code done under immediate fix we need to change the response format
      $invoiceId = $_POST['id'];
      /* Getting file name */
        if(!empty($_FILES['file']['name'])){
          $filename = str_replace(' ','',$_FILES['file']['name']); 
          //$date = date('m-d-Y-h:i:s', time());
          /* Location */
          $location = "uploads/vendor_invoices/".$filename; 
          $uploadOk = 1; 
            
          if($uploadOk == 0){ 
             echo 0; 
          }else{ 
             /* Upload file */
             if(move_uploaded_file($_FILES['file']['tmp_name'], $location)){ 
                
                $filepath = $location;
                //str_replace(' ', '', $filepath);
                $result = $this->brands_model->addFilePath($invoiceId, $filepath);
                if(!empty($result)){
                    $response = array('status' => 1, 'message' =>'success');
                    echo json_encode($response);
                }else {
                  $response = array('status' => 0, 'message' =>'error');
                  echo json_encode($response);
                } 
             }else{ 
                  $response = array('status' => 0, 'message' =>'error');
                  echo json_encode($response);
             } 
          }
        } 
        else {
              $response = array('status' => 0, 'message' => 'error');
              echo json_encode($response);
        } 
    }
    
    public function vendorInvoice(){
        $id = $_POST['invoiceId'];
        $data['result'] = $this->vendors_model->get_invoice_filename($id);
        $view = $this->load->view('admin/invoices/vendor_invoice',$data);
    }

    public function deleteVendorInvoice(){
      $id = $_POST['id'];
      $invoiceId = $_POST['invoiceId'];
      $this->vendors_model->delete_vendor_invoice($id);
      $data['result'] = $this->vendors_model->get_invoice_filename($invoiceId);
      $view = $this->load->view('admin/invoices/vendor_invoice',$data);
    }

    public function remove(){
        //if (!has_permission('vendor_list', '', 'delete')) {
          //  access_denied('vendor_list');
        //}
        $id = $_POST['id'];
        if($id != ''){
            $this->brands_model->remove_brand($id);
            set_alert('success', 'Brand deleted');
            echo "success";
        }else{
            echo "fail";
        }

    }

    public function removeMapping(){
      $vendorId = $_POST['vendorId'];
      $brandId = $_POST['brandId'];
      if($vendorId != '' && $brandId != ''){
        $this->brands_model->remove_brand_vendor_mapping($vendorId, $brandId);
        set_alert('success', 'Vendor Brand Relation Deleted');
        echo "success";
      } else {
        echo "Fail";
      }
    } 

    public function sampleDownload(){
        $filepath = base_url().'uploads/demo.csv';
        $data = file_get_contents($filepath);
        $name = 'brands_sample.csv';
        @ob_end_clean();
        force_download($name, $data);
    }

    public function catalougedProductsUpdate(){
      $this->load->view('admin/invoice_items/catalogueUploadSheet');
    }

    public function sampleBulkMappingUpload(){
        $filepath = base_url().'uploads/sample_bulk_upload.csv';
        $data = file_get_contents($filepath);
        $name = 'bulk_upload_mapping_sample.csv';
        @ob_end_clean();
        force_download($name, $data);
    }

    public function bulkMappingUpload(){
      if(!empty($_FILES['file']['name'])){ 
            $response = $this->bulkUploadAction($_FILES);
            if($response['status'] == 1){
                $importData_arr = $response['importData_arr'];
                $filename = $response['filename'];
                $skip = 0;
                array_shift($importData_arr);
                // insert import data
                foreach($importData_arr as $res){
                  $vendorId = $this->brands_model->get_vendor($res[0]);
                  $brandId = $this->brands_model->get_brand($res[1]);

                    if($skip != 0){
                      if(!empty($vendorId) && !empty($brandId)){
                          $bulkData = array('vendor_id' => $vendorId->id,'brand_id' => !empty($brandId->id) ? $brandId->id : '','vendor_level' => $res[2], 'zone_level' => $res[3], 'state_level' => $res[4]);
                          
                          $result = $this->brands_model->bulk_mapping($bulkData); // need to change this logic
                      }
                      else{
                        logActivity('Bulk mapping failed for the brand'.$res[1]);
                      }
                    }
                  $skip ++;
                }
                if(!empty($result)){
                    // need to change this check logic
                    set_alert('success','successfully uploaded '.$filename);
                } else{
                    set_alert('danger','These data uploaded already');    
                }
                $response = array('status' => 1, 'message' => 'Success');  
            } else{
                set_alert('danger','Something went wrong');
                $response = array('status' => 0, 'message' => 'Error');
            }
        }else{
            set_alert('danger','File upload error');
            $response = array('status' => 0, 'message' => 'Error');
        }
         redirect(base_url('list-brand-vendor'));
      // $this->load->view('admin/brands/brandvendorlist',$response);  
    }

    public function vendorBrands(){

        // Datatables Variables
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));

          $brands = $this->brands_model->get_all_brands();

          $data = array();
          $i = 1;

          foreach ($brands as $key => $brand) {
            $editBtn = "";
            $deleteBtn = "";
            //if (has_permission('vendor_list', '', 'edit')) {
                $editBtn = '<a class="editor_edit"><span style="cursor:pointer;" onclick="edit('.$brand->id.')" class="glyphicon glyphicon-edit"></span></a>';
            //}
            //if (has_permission('vendor_list', '', 'delete')) {
                $deleteBtn = '<a id="delete" class="editor_remove"><span style="cursor:pointer;" onclick="remove('.$brand->id.')" class="glyphicon glyphicon-remove" id="delete"></a>';
            //}
             $result = array(
                              'Brand' => $i,
                              'Brand Name' => $brand->brand_name,
                              'Created At' => $brand->created_at,
                              'Updated At' => $brand->updated_at,
                              'Action' => $editBtn.'&nbsp;&nbsp;'.$deleteBtn
                            );
             $data[] = $result;
             $i++;
          }

          $output = array(
                 "draw" => $draw,
                 "recordsTotal" => count($brands),
                 "recordsFiltered" => count($brands),
                 "data" => $data
            );
          echo json_encode($output);
    }

    public function listBrandVendor(){
      $data['vendors'] = $this->brands_model->get_all_vendors();
      $allBrands = $this->brands_model->get_all_brands();
      $data['brands'] = json_decode(json_encode($allBrands), true); // convert object into array
      $this->load->view('admin/brands/brandvendorlist', $data);
    }

    public function getBrandVendor(){
        // Datatables Variables
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));

          $brandVendorData = $this->brands_model->get_all_brands_vendors_list();
          
          $data = array();
          $i = 1;

          foreach ($brandVendorData as $key => $res) {
            $editBtn = "";
            $deleteBtn = "";
            $brandName = $this->brands_model->get_details($res['brand_id'],'tblbrands');
            //echo "<pre>"; print_r($brandName);
            $vendorDetails = $this->brands_model->get_details($res['vendor_id'],'tblvendor');
            //if (has_permission('vendor_list', '', 'edit')) {
                $editBtn = '<a class="editor_edit"><span style="cursor:pointer;" onclick="edit('.$res['vendor_id'].','.$res['brand_id'].')" class="glyphicon glyphicon-edit"></span></a>';
            //}
            //if (has_permission('vendor_list', '', 'delete')) {
                $deleteBtn = '<a id="delete" class="editor_remove"><span style="cursor:pointer;" onclick="remove('.$res['vendor_id'].','.$res['brand_id'].')" class="glyphicon glyphicon-remove" id="delete"></a>';
            //}
             $result = array(
                              'Brand' => $i,
                              'Brand Name' => $brandName->brand_name,
                              'Vendor Name' => !empty($vendorDetails->companyname) ? $vendorDetails->companyname : '',
                              'Vendor Priority' => $res['vendor_level'],
                              'Location' => !empty($vendorDetails->city) ? $vendorDetails->city.','.$vendorDetails->state:'',
                              'Phone Number' => !empty($vendorDetails->phone) ? $vendorDetails->phone : 'N/A',
                              'Zone Priority' => $res['zone_level'],
                              'State Priority' => $res['state_level'],
                              'Products List' => '<a><span onclick="list('.$res['vendor_id'].')" style="cursor:pointer;" class="glyphicon glyphicon-menu-hamburger"> View</span></a>',
                              'Action' => $editBtn.'&nbsp;&nbsp;'.$deleteBtn
                            );
             $data[] = $result;
             $i++;
          }

          $output = array(
                 "draw" => $draw,
                 "recordsTotal" => count($brandVendorData),
                 "recordsFiltered" => count($brandVendorData),
                 "data" => $data
            );
          echo json_encode($output); 
    }

    public function addMapping(){
      $data = $this->input->post();
      foreach($data['brand'] as $brd){
        $bulkData = array('vendor_id' => $data['vendor'],'brand_id' => $brd,'vendor_level' => $data['vendorpriority'],  'zone_level' => $data['zonepriority'], 'state_level' => $data['statepriority']);
        $result = $this->brands_model->bulk_mapping($bulkData);
      }
      if(!empty($result)){
        set_alert('success', 'Brand Vendor Relationship Added successfully');
        $response = array('status' => 1, 'message' => 'success');
      } 
      else{
        set_alert('danger', 'Something Went Wrong');
        $response = array('status' => 0, 'message' => 'fail');
      }
      echo json_encode($response);
    }


    public function getVendorDetails(){
      $data = $this->input->post();
      
      $getVendorQuery = "SELECT * FROM tblbrand_vendor_mapping WHERE vendor_id ='".$data['vid']."'";
      $getVendorResult = $this->db->query($getVendorQuery)->row_array();

      $getVendorNameQuery = "SELECT * FROM tblvendor WHERE id ='".$data['vid']."'";
      $getVendorNameResult = $this->db->query($getVendorNameQuery)->row_array();
      
      $getBrandQuery = "SELECT * FROM tblbrands WHERE id ='".$data['bid']."'";
      $getBrandResult = $this->db->query($getBrandQuery)->row_array();
      
      $response['vendor'] = $getVendorResult;
      $response['vendor_name'] = $getVendorNameResult;
      $response['brand'] = $getBrandResult;
      echo json_encode($response);
    }

    public function getBrandDetails(){
      $data = $this->input->post();
      
      $getBrandQuery = "SELECT * FROM tblbrands WHERE id ='".$data['bid']."'";
      $getBrandResult = $this->db->query($getBrandQuery)->row_array();

      $response['brand'] = $getBrandResult;
      echo json_encode($response);
    }
    
  
    public function editMapping(){
      $data = $this->input->post();
      
      $updateVendorMappingQuery = "UPDATE tblbrand_vendor_mapping SET state_level ='".$data['statepriority']."', vendor_level ='".$data['vendorpriority']."', zone_level ='".$data['zonepriority']."' WHERE vendor_id = '".$data['vendor_id']."'";
      $result = $this->db->query($updateVendorMappingQuery);

      if(!empty($result)){
        set_alert('success', 'Brand Vendor Relationship updated successfully');
        $response = array('status' => 1, 'message' => 'success');
      } 
      else{
        set_alert('danger', 'Something Went Wrong');
        $response = array('status' => 0, 'message' => 'fail');
      }
      echo json_encode($response);
    }  


    public function editBrand(){
      $data = $this->input->post();
      
      $updateBrandQuery = "UPDATE tblbrands SET brand_name ='".$data['brand']."' WHERE id = '".$data['brand_id']."'";
      $result = $this->db->query($updateBrandQuery);

      if(!empty($result)){
        set_alert('success', 'Brand Vendor Relationship updated successfully');
        $response = array('status' => 1, 'message' => 'success');
      } 
      else{
        set_alert('danger', 'Something Went Wrong');
        $response = array('status' => 0, 'message' => 'fail');
      }
      echo json_encode($response);
    }  

    public function addBrand(){
      $data = $this->input->post();
      
      $addBrandQuery = "INSERT INTO tblbrands (brand_name) VALUES ('".$data['brand']."')";
      $result = $this->db->query($addBrandQuery);

      if(!empty($result)){
        set_alert('success', 'Brand Vendor Relationship updated successfully');
        $response = array('status' => 1, 'message' => 'success');
      } 
      else{
        set_alert('danger', 'Something Went Wrong');
        $response = array('status' => 0, 'message' => 'fail');
      }
      echo json_encode($response);
    }  

    
    public function getVendorProducts(){
      $id = $_GET['id'];
      $data['productslist'] = $this->brands_model->get_vendor_products($id);
      $view = $this->load->view('admin/brands/tabledata',$data);
    }}