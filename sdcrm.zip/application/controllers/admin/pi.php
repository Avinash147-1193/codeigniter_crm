<?php
defined('BASEPATH') or exit('No direct script access allowed');
class pi extends Admin_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('proposals_model');
        $this->load->model('currencies_model');
        $this->load->library('session');
        $this->load->model('estimates_model');
        $this->load->model('clients_model');
        $this->load->model('tasks_model');
        $this->load->model('leads_model');
        $this->load->model('invoice_items_model');
        $this->load->helper('general_helper');
        $this->load->helper('constant_helper');
    }

    public function index($proposal_id = '')
    {
        $this->list_proposals($proposal_id);
    }

    public function pi() {
        $this->load->view('admin/pi/pi');
    }

    public function industry() {
        $this->load->view('admin/pi/industry');
    }

    public function addindustry(){
        $data = $this->input->post();
        $postData = array('name' => $data['industryname'], 'url' => $data['industryurl'],'brandUrl' => $data['brandurl'],'categoryUrl' => $data['categoryurl']);
        $payload = json_encode($postData);
        $url = piApiUrl.'industry';
        $response = $this->commanCurl($url,'POST',$payload);
        if($response['statusCode'] == 200 || $response['statusCode'] == 201){
          set_alert('success', 'Industry Added successfully');
          $result = array('status' => 1, 'message' => 'success');
        } else{
          $result = array('status' => 0, 'message' => 'error');
        }
        echo json_encode($result);
    }

    public function getindustry(){
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));
          /*curl call to get the industry*/  
            $url = piApiUrl.'industry';
            $response = curl($url, 'GET');
            $industry = json_decode($response['result']); //converting the json into php array
          /*end*/
          $data = array();
          $i = 1;

          foreach ($industry as $key => $ind) {
            $editBtn = "";
            $deleteBtn = "";

            $editBtn = '<a class="editor_edit"><span style="cursor:pointer;" onclick=edit("'.$ind->_id.'") class="glyphicon glyphicon-edit"></span></a>';
 
           $deleteBtn = '<a class="editor_remove"><span style="cursor:pointer;" onclick=remove("'.$ind->_id.'") class="glyphicon glyphicon-remove"></a>';

            $result = array(
                              'No' => $i,
                              'Name' => $ind->name,
                              'Url' => $ind->url,
                              'Brand Base Url' => $ind->brandBaseUrl,
                              'Category Base Url' => $ind->categoryBaseUrl,
                              'Action' => $editBtn.'&nbsp;&nbsp;'.$deleteBtn
                            );
             $data[] = $result;
             $i++;
          }

          $output = array(
                 "draw" => $draw,
                 "recordsTotal" => count($industry),
                 "recordsFiltered" => count($industry),
                 "data" => $data
            );
          echo json_encode($output);
    }

    public function remove(){
        $data = $this->input->post();
        $postData = array();
        $payload = json_encode($postData);
        $url = piApiUrl.$data['type'].'/'.$data['id'];
        $response = $this->commanCurl($url,'DELETE',$payload);
        if($response['statusCode'] == 200 || $response['statusCode'] == 201){
          set_alert('success', 'Deleted successfully');
          $result = array('status' => 1, 'message' => 'success');
        } else{
          $result = array('status' => 0, 'message' => 'error');
        }
        echo json_encode($result); 
    }

    public function fetch() {
        $data = $this->input->post();
        $method = $this->input->post('method');
        //we are using this function for both get and update of specific row of industry, brand and category
        if($method == 'PATCH') {
          //This will call when type is brand or category
          if($data['type'] == 'brands' || $data['type'] == 'categories') {
              $postData = array('name' => $data['data'][0], 'urlName' => $data['urlname'], 'baseUrl' => $data['baseurl']);
              $payload = json_encode($postData);
          } else{
            //This will call when type is industry
              $postData = array('name' => $data['data'][0], 'url' => $data['data'][1], 'brandBaseUrl' => $data['data'][2], 'categoryBaseUrl' => $data['data'][3]);
              $payload = json_encode($postData);
          }
        } else{
          $postData = array();
          $payload = json_encode($postData);
        }
        // This will call when user clicks on edit for industry, brand and category it will fetch the record from db
        $url = piApiUrl.$data['type'].'/'.$data['id'];
        $response = $this->commanCurl($url,$method,$payload);

        if($response['statusCode'] == 200 || $response['statusCode'] == 201){
          
          if($method == 'PATCH') {
            set_alert('success', 'Updated successfully');  
          }

          $res = $response['result'];
          $result = array('status' => 1, 'message' => 'success' , 'response' => $res );
        } else{
          $result = array('status' => 0, 'message' => 'error');
        }

        echo json_encode($result);
    }

    public function brand() {
        /*curl call to get the industry*/  
            $url = piApiUrl.'industry';
            $response = curl($url, 'GET');
            $industry = json_decode($response['result']); //converting the json into php array
          /*end*/
        $data['industries'] = $industry;
        $this->load->view('admin/pi/brand', $data);
    }

    public function addbrand() {
        $data = $this->input->post();
        $postData = array('name' => $data['brandname'], 'type' => $data['industry'][0],'urlname' => $data['urlname'],'baseurl' => $data['baseurl']);
        $payload = json_encode($postData);
        $url = piApiUrl.'brands';
        $response = $this->commanCurl($url,'POST',$payload);
        if($response['statusCode'] == 200 || $response['statusCode'] == 201){
          set_alert('success', 'Brand Added successfully');
          $result = array('status' => 1, 'message' => 'success');
        } else{
          $result = array('status' => 0, 'message' => 'error');
        }
        echo json_encode($result);
    }

    public function getbrands(){
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));
          /*curl call to get the industry*/  
            $url = piApiUrl.'brands';
            $response = curl($url, 'GET');
            $brands = json_decode($response['result']); //converting the json into php array
          /*end*/

          $data = array();
          $i = 1;
          foreach ($brands as $key => $brand) {

            $editBtn = '<a  class="editor_edit"><span style="cursor:pointer;" onclick=edit("'.$brand->_id.'") class="glyphicon glyphicon-edit"></span></a>';

           $deleteBtn = '<a id="confirmModal" class="editor_remove"><span style="cursor:pointer;" onclick=remove("'.$brand->_id.'") class="glyphicon glyphicon-remove" id="confirmModal"></a>';

            $result = array(
                              'No' => $i,
                              'Name' => $brand->name,
                              'Industry'=> $brand->businesstype->name,
                              'Url Name' => $brand->urlName,
                              'Brand Url' => $brand->baseUrl,
                              'Action' => $editBtn.'&nbsp;&nbsp;'.$deleteBtn
                            );
             $data[] = $result;
             $i++;
          }

          $output = array(
                 "draw" => $draw,
                 "recordsTotal" => count($brands),
                 "recordsFiltered" => count($brands),
                 "data" => $data
            );
          echo json_encode($output);
    }

    public function products(){
      $this->load->view('admin/pi/products'); 
    }

    public function getproducts(){
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));
          /*curl call to get the industry*/  
            $url = piApiUrl.'products';
            $response = curl($url, 'GET');
            $products = json_decode($response['result']); //converting the json into php array
          /*end*/
          $data = array();
          $i = 1;

          foreach ($products as $key => $product) {
            
            $result = array(
                              'No' => $i,
                              'Product Name' => $product->productName,
                              'Product Link'=> $product->productLink,
                              'Image Link' => isset($product->imageLink) ? $product->imageLink : 'N/A',
                              'Brand' => $product->brand,
                              'Mrp' => isset($product->mrp) ? $product->mrp : 'N/A',
                              'Discount Amount' => isset($product->discountAmount) ? $product->discountAmount : 'N/A',
                              'Discount Percent' => isset($product->discountPercent) ? $product->discountPercent : 'N/A',
                              'Discount Price' => 1234,
                              'Moq' => isset($product->moqUnit) ? $product->moqUnit : 'N/A',
                              'Crawl Time' => $product->createdAt
                            );
             $data[] = $result;
             $i++;
          }

          $output = array(
                 "draw" => $draw,
                 "recordsTotal" => count($products),
                 "recordsFiltered" => count($products),
                 "data" => $data
            );
          echo json_encode($output);
    }

    public function category() {
        /*curl call to get the industry*/  
            $url = piApiUrl.'industry';
            $response = curl($url, 'GET');
            $industry = json_decode($response['result']); //converting the json into php array
          /*end*/
        $data['industries'] = $industry;
        $this->load->view('admin/pi/category', $data);
    }

    public function addcategory(){
        $data = $this->input->post();
        $postData = array('name' => $data['categoryname'], 'type' => $data['industry'][0], 'urlname' => $data['urlname'], 'baseurl' => $data['baseurl']);
        $payload = json_encode($postData);
        $url = piApiUrl.'categories';
        $response = $this->commanCurl($url,'POST',$payload);
        if($response['statusCode'] == 200 || $response['statusCode'] == 201){
          set_alert('success', 'Category Added successfully');
          $result = array('status' => 1, 'message' => 'success');
        } else{
          $result = array('status' => 0, 'message' => 'error');
        }
        echo json_encode($result); 
    }

    public function getcategories(){
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));
          /*curl call to get the industry*/  
            $url = piApiUrl.'categories';
            $response = curl($url, 'GET');
            $categories = json_decode($response['result']); //converting the json into php array
          /*end*/

          $data = array();
          $i = 1;

          foreach ($categories as $key => $category) {

            $editBtn = '<a class="editor_edit"><span style="cursor:pointer;" onclick=edit("'.$category->_id.'") class="glyphicon glyphicon-edit"></span></a>';

           $deleteBtn = '<a class="editor_remove"><span style="cursor:pointer;" onclick=remove("'.$category->_id.'") class="glyphicon glyphicon-remove"></a>';
            $result = array(
                              'No' => $i,
                              'Name' => $category->name,
                              'Industry'=> $category->businesstype->name,
                              'Url Name' => $category->urlName,
                              'Category Url' => $category->baseUrl,
                              'Action' => $editBtn.'&nbsp;&nbsp;'.$deleteBtn
                            );
             $data[] = $result;
             $i++;
          }

          $output = array(
                 "draw" => $draw,
                 "recordsTotal" => count($categories),
                 "recordsFiltered" => count($categories),
                 "data" => $data
            );
          echo json_encode($output);
    }

    public function getData($url){
            $response = curl($url, 'GET');
            $result = json_decode($response['result']);
            return $result;
    }
    public function cron() {
         /*curl call to get the industry*/   //converting the json into php array
          $indUrl = piApiUrl.'industry';
          $industry = $this->getData($indUrl);
            //to get brand
          $brandUrl = piApiUrl.'brands';
          $brands = $this->getData($brandUrl);
            //to get categories
          $catUrl = piApiUrl.'categories';
          $category = $this->getData($catUrl);
          /*end*/
        $data['industries'] = $industry;
        $data['brands'] = $brands;
        $data['catgeory'] = $category;
       
        $this->load->view('admin/pi/cron', $data);
    }

    public function addcron(){
        $data = $this->input->post();

        if($data['type'] == 'brand'){
          foreach($data['brand'] as $brand){
            $postData = array('brand' =>$brand, 
                          'cron' => $data['croncommand'],
                          'type' => $data['type'], 
                          'category' =>'' ,  
                          'active' => $data['status'] == 1 ? true : false
                        );
            $result = $this->addData($postData);
          }
        }

        if($data['type'] == 'category'){
          foreach($data['category'] as $cat){
            $postData = array('brand' =>'', 
                          'cron' => $data['croncommand'],
                          'type' => $data['type'], 
                          'category' => $cat ,  
                          'active' => $data['status'] == 1 ? true : false
                        );
            $result = $this->addData($postData);
        }
        set_alert('success', 'Added successfully');
        echo json_encode($result);
    }
  }

    public function addData($postData){
        $payload = json_encode($postData);
        $url = piApiUrl.'cron';
        $response = $this->commanCurl($url,'POST',$payload);
        if($response['statusCode'] == 200 || $response['statusCode'] == 201){
          $result = array('status' => 1, 'message' => 'success');
        } else{
          $result = array('status' => 0, 'message' => 'error');
        }
          return $result;
    }

    public function getcrons(){
          $draw = intval($this->input->get("draw"));
          $start = intval($this->input->get("start"));
          $length = intval($this->input->get("length"));
          /*curl call to get the industry*/  
            $url = piApiUrl.'cron';
            $response = curl($url, 'GET');
            $crons = json_decode($response['result']); //converting the json into php array
          /*end*/
          $data = array();
          $i = 1;

          foreach ($crons as $key => $cron) {
            $deleteBtn = "";
 
           $deleteBtn = '<a class="editor_remove"><span style="cursor:pointer;" onclick=remove("'.$cron->_id.'") class="glyphicon glyphicon-remove"></a>';

           if(!empty($cron->brand)) {
            $brandUrl = piApiUrl.'brands/'.$cron->brand;
            $brand = curl($brandUrl, 'GET');
            $brandResult = json_decode($brand['result']);
            $label = 'Brand '.$brandResult->name;
            $industryResult = $brandResult->businesstype->name;
           } else {
            $categoryUrl = piApiUrl.'categories/'.$cron->productCategory;
            $category = curl($categoryUrl, 'GET');
            $categoryResult = json_decode($category['result']);
            $label = 'Categrory '.$categoryResult->name;
            $industryResult = $categoryResult->businesstype->name;
           }

            $result = array(
                              'sno' => $i,
                              'croncommand' => $cron->cron,
                              'type' => $cron->type,
                              'industryname' => $industryResult,
                              'schedulefor' => $label,
                              'crawlcount' => $cron->crawlCount,
                              'status' => !empty($cron->active) ? 'Active' : 'Inactive',
                              'action' => '&nbsp;'.$deleteBtn
                            );
             $data[] = $result;
             $i++;
          }
          $output = array( 
                 "draw" => $draw,
                 "recordsTotal" => count($crons),
                 "recordsFiltered" => count($crons),
                 "data" => $data
            );
          echo json_encode($output);
    }

    public function commanCurl($url,$method,$payload){
        /*curl*/
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json') );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close ($ch);
        $responseArray = array('statusCode' => $httpcode,'result' => $result);
        return $responseArray;
    }
}