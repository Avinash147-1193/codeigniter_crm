<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Excel_export extends Admin_controller {
 
    public function __construct()
    {
        parent::__construct();
        $this->load->model('brands_model');
        $this->load->library("excel");
    }


     function index()
     {
        $data["query_data"] = $this->brands_model->fetchQueryData();
        $this->load->view("admin/brands/excel_export_view", $data);
     }

     function sdstoreProductAction() 
     {
        $fromDate = $this->uri->segment(2);
        $toDate = $this->uri->segment(3);
        $object = new PHPExcel();

        $object->setActiveSheetIndex(0);

        $table_columns = array("Sd Team Product Id", "Actual Vendor Child Product Id", "Crm Vendor Id","ProductCode","Tp","Vendor Name","Sdstore Vendor Id", "Sdstore Company Id");

        $column = 0;

        foreach($table_columns as $field)
        {
         $object->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
         $column++;
        }

        $queryData = $this->brands_model->fetchSdstoreQueryData($fromDate,$toDate);

        $excel_row = 2;

        foreach($queryData as $row)
        {
         $object->getActiveSheet()->setCellValueByColumnAndRow(0, $excel_row, $row['sdTeamProductId']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(1, $excel_row, $row['vendorChildProductId']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(2, $excel_row, $row['vendor_id']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(3, $excel_row, $row['productCode']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(4, $excel_row, $row['Tp']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(5, $excel_row, $row['vendor']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(6, $excel_row, $row['sdStoreVendorId']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(7, $excel_row, $row['sdVendorCompanyId']);
         $excel_row++;
        }

        $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Adhoc Product Vendor Data.xls"');
        ob_clean();
        $object_writer->save('php://output');  
    }

     function action()
     {
        $fromDate = $this->uri->segment(2);
        $toDate = $this->uri->segment(3);
        $object = new PHPExcel();

        $object->setActiveSheetIndex(0);

        $table_columns = array("Crm Product Id", "Sdstore Product Id", "Product Name","Model","Brand","Hsn Code","Product Description", "Product Code", "Tp", "GST", "Category", "Vendor Company");

        $column = 0;

        foreach($table_columns as $field)
        {
         $object->getActiveSheet()->setCellValueByColumnAndRow($column, 1, $field);
         $column++;
        }

        $queryData = $this->brands_model->fetchQueryData($fromDate,$toDate);

        $excel_row = 2;

        foreach($queryData as $row)
        {
         $object->getActiveSheet()->setCellValueByColumnAndRow(0, $excel_row, $row['CrmProductId']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(1, $excel_row, $row['SdstoreProductId']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(2, $excel_row, $row['ProductName']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(3, $excel_row, $row['model']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(4, $excel_row, $row['brand']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(5, $excel_row, $row['hsnCode']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(6, $excel_row, $row['productDescription']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(7, $excel_row, $row['ProductCode']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(8, $excel_row, $row['Tp']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(9, $excel_row, $row['GST']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(10, $excel_row, $row['category']);
         $object->getActiveSheet()->setCellValueByColumnAndRow(11, $excel_row, $row['VendorCompany']);
         $excel_row++;
        }

        $object_writer = PHPExcel_IOFactory::createWriter($object, 'Excel5');
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Adhoc Product Vendor Data.xls"');
        ob_clean();
        $object_writer->save('php://output');
       }
}