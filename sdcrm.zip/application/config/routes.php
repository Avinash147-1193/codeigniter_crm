<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|   example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|   http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|   $route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|   $route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|   $route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples: my-controller/index -> my_controller/index
|       my-controller/my-method -> my_controller/my_method
*/


$route['api/enquiry'] = 'api/enquiry_api/enquiry';
$route['api/knowlarityenquiry'] = 'api/enquiry_api/knowlarityenquiry';

//vendor routes
$route['admin/listvendor'] = "admin/vendor";
$route['getvendor'] = "admin/vendor/get";
$route['removevendor/(:num)'] = "admin/vendor/remove/$1";
$route['addvendor'] = "admin/vendor/add";
$route['editvendor/(:num)/(:any)'] = "admin/vendor/edit/$1/$2";
$route['updatevendor/(:any)'] = "admin/vendor/update/$1";
$route['updatemissingfields'] = "admin/vendor/updatemissingfields";

//product vendor mapping routes
$route['admin/product-vendor-mapping'] = "admin/product_vendor_mapping";
$route['mappingdatatable'] = "admin/Product_vendor_mapping/datatable";
$route['admin/getproductvendor'] = "admin/invoice_items/getproductvendor";
$route['admin/addproductvendor'] = "admin/invoice_items/addproductvendor";
$route['admin/editproductvendor'] = "admin/invoice_items/editproductvendor";
$route['admin/checklastupdatedvendor'] = "admin/invoice_items/checklastupdatedvendor";
$route['removeproductvendor'] = "admin/product_vendor_mapping/remove";
$route['admin/getproductvendormapping'] = "admin/product_vendor_mapping/edit";
$route['datalist'] = "admin/invoice_items/datalist";
$route['addmapping'] = "admin/invoice_items/addmapping";
$route['newproductvendormapping'] = "admin/product_vendor_mapping/getproductvendor";
$route['productdatalist'] = "admin/product_vendor_mapping/productdatalist";
$route['assignproductvendor'] = "admin/product_vendor_mapping/assignproductvendor";
$route['editproductvendor'] = "admin/product_vendor_mapping/editproductvendor";
$route['deleteproductvendor'] = "admin/product_vendor_mapping/deleteproductvendor";
$route['updateitemsinpricevendor'] = "admin/tasks/updateItemsPriceVendor";
$route['regretoption'] = "admin/tasks/priceNotAvailable";

//proforma invoice route

$route['addadvanceamount'] = "admin/invoices/record_advance_payment";
$route['placeorder'] = "admin/invoices/placeorder";
$route['updateorder'] = "admin/invoices/updateorder";
$route['getcustomerorderinfo'] = "admin/invoices/getCustomerOrderInfo";
$route['getlineitems'] = "admin/invoices/getTabelData";
$route['getlineitemstock'] = "admin/invoices/get_item_stock";
$route['updatebillingaddress'] = "admin/invoices/updateBillingAddress";

//unassign enquiry routes

$route['admin/unassign'] = "admin/proposals/manage";
$route['assignenquiry'] = "admin/proposals/assignenquiry";

//pi routes

//brand routes
$route['pi'] = "admin/pi/pi";
$route['brand'] = "admin/pi/brand";
$route['addbrand'] = "admin/pi/addbrand";
$route['getbrands'] = "admin/pi/getbrands";
$route['fetchbrand'] = "admin/pi/fetch";
$route['editbrand'] = "admin/pi/fetch";
$route['removebrand'] = "admin/pi/remove";

//cron routes
$route['cron'] = "admin/pi/cron";
$route['addcron'] = "admin/pi/addcron";
$route['getcrons'] = "admin/pi/getcrons";
$route['removecron'] = "admin/pi/remove";

//industry routes
$route['industry'] = "admin/pi/industry";
$route['getindustry'] = "admin/pi/getindustry";
$route['addindustry'] = "admin/pi/addindustry";
$route['fetchindustry'] = "admin/pi/fetch";
$route['editindustry'] = "admin/pi/fetch";
$route['removeindustry'] = "admin/pi/remove";

//category routes
$route['category'] = "admin/pi/category";
$route['addcategory'] = "admin/pi/addcategory";
$route['getcategories'] = "admin/pi/getcategories";
$route['fetchcategory'] = "admin/pi/fetch";
$route['editcategory'] = "admin/pi/fetch";
$route['removecategory'] = "admin/pi/remove";

//
$route['products'] = "admin/pi/products";
$route['getproducts'] = "admin/pi/getproducts";

//assign task routes
$route['admin/assigntask'] = "admin/tasks/assigntask";
$route['admin/assigntask/(:any)'] = "admin/tasks/assigntask/$1";

$route['default_controller'] = 'authentication/admin';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['admin']  = "admin/dashboard";
// Misc controller rewrites
$route['admin/access_denied']  = "admin/misc/access_denied";
$route['admin/not_found']  = "admin/misc/not_found";

// Staff rewrites
$route['admin/profile']  = "admin/staff/profile";
$route['admin/profile/(:num)']  = "admin/staff/profile/$1";
$route['admin/tasks/view/(:any)']  = "admin/tasks/index/$1";

// Items search rewrite
$route['admin/items/search'] = 'admin/invoice_items/search';

/* Clients links and routes */
// // In case if client access directly to url without the arguments redirect to clients url
$route['/']  = "clients";
$route['viewinvoice']  = "clients/viewinvoice";
$route['viewinvoice/(:num)/(:any)']  = "clients/viewinvoice/$1/$2";

$route['viewestimate/(:num)/(:any)']  = "clients/viewestimate/$1/$2";
$route['viewestimate']  = "clients/viewestimate";

$route['viewproposal/(:num)/(:any)']  = "clients/viewproposal/$1/$2";

$route['survey/(:num)/(:any)']  = "clients/survey/$1/$2";
$route['knowledge_base']  = "clients/knowledge_base";
$route['knowledge_base/(:any)']  = "clients/knowledge_base/$1";

$route['knowledge-base']  = "clients/knowledge_base";
$route['knowledge-base/(:any)']  = "clients/knowledge_base/$1";
$route['admin/enquiry'] = "admin/emails/enquiry";

$route['send-product-requirement-request-to-vendor'] = "admin/emails/send_product_requirement_request_to_vendor";
$route['get-task-item-vendor'] = "admin/tasks/getTaskItemVendorList";	
$route['get-task-item-best-price'] = "admin/tasks/getBestPriceForSourcingItems";	

//brands routes
$route['brands'] = "admin/brands/index";
$route['brands/upload'] = "admin/brands/bulkUpload";
$route['getvendorbrands'] = "admin/brands/vendorBrands";
$route['removevendorbrand'] = "admin/brands/remove";
$route['sampleDownload'] = "admin/brands/sampleDownload";

//brand vendor mapping routes
$route['admin/list-brand-vendor'] = "admin/brands/listBrandVendor";
$route['get-brand-vendor'] = "admin/brands/getBrandVendor";
$route['bulkmapping'] = "admin/brands/bulkMappingUpload";
$route['sampleBulkMappingUpload'] = "admin/brands/sampleBulkMappingUpload";
$route['remove-vendor-brand-mapping'] = "admin/brands/removeMapping";
$route['addbrandsmapping'] = "admin/brands/addMapping";
$route['get-vendor-products'] = "admin/brands/getVendorProducts";

$route['editmapping'] = "admin/brands/editMapping";
$route['editbrand'] = "admin/brands/editBrand";
$route['addbrand'] = "admin/brands/addBrand";
$route['get-vendor-details'] = "admin/brands/getVendorDetails";
$route['get-brand-details'] = "admin/brands/getBrandDetails";

//mailchimp realted routes
$route['getgstin'] = "admin/estimates/getGstin";
$route['uploadInvoice'] = "admin/brands/uploadVendorInvoice";
$route['mailChimpPush'] = "admin/pdf_copy/mailchimpPush";
if(file_exists(APPPATH.'config/my_routes.php')){
    include_once(APPPATH.'config/my_routes.php');
}

//vendor-product mapping related routes
$route['viewvendorspopup'] = "admin/proposals/viewvendors";
$route['addproductvendormapping'] = "admin/proposals/addMapping";
$route['checkvendoroldprice'] = "admin/proposals/checkVendorOldPrice";

//adhoc-product-vendor dump routes
$route['orderdump'] = 'admin/excel_export/index';
$route['adhocProductsDumpDownload/(:any)/(:any)'] = 'admin/excel_export/action';
$route['adhocVendorExistingProduct/(:any)/(:any)'] = 'admin/excel_export/sdstoreProductAction';
$route['addaddress'] = "admin/clients/addAddress";
$route['removeaddress'] = "admin/clients/removeAddress";
$route['updateaddress'] = "admin/clients/updateAddress";

$route['admin/uploadSheet'] = "admin/brands/catalougedProductsUpdate";
$route['catalouge/upload'] = "admin/brands/uploadDataFromSheet";

$route['orders'] = "admin/brands/ordersList";
$route['searchorders/(:any)'] = "admin/brands/ordersList";
$route['admin/orders'] = "admin/brands/ordersList";
$route['admin/orders/(:any)'] = "admin/brands/ordersList";
$route['getorders'] = "admin/brands/orders";
$route['orders/webhook'] = "api/webhook_api/orders";

$route['admin/getenquiry/(:any)/(:num)'] = 'admin/proposals/index';